"""Lead-pair graph on V1–V6 chest chain for graph attention refinement."""

from __future__ import annotations

import torch

from src.constants import VIRTUAL_LEAD_PAIRS
from src.lead_space import parse_pair


def build_lead_pair_adjacency(
    n_leads: int = 15,
    self_loop: bool = True,
    endpoint_share: bool = True,
    max_center_gap: int = 1,
) -> torch.Tensor:
    """
    Symmetric adjacency (n_leads, n_leads), float32, with optional self loops.
    Two pairs are connected if they share a chest electrode or center indices differ <= max_center_gap.
    """
    adj = torch.zeros(n_leads, n_leads, dtype=torch.float32)
    centers: list[float] = []
    endpoints: list[set[int]] = []
    for pair in VIRTUAL_LEAD_PAIRS:
        i, j = parse_pair(pair)
        centers.append((i + j) / 2.0)
        endpoints.append({i, j})

    for i in range(n_leads):
        for j in range(n_leads):
            if i == j:
                if self_loop:
                    adj[i, j] = 1.0
                continue
            connected = False
            if endpoint_share and endpoints[i] & endpoints[j]:
                connected = True
            if abs(centers[i] - centers[j]) <= max_center_gap:
                connected = True
            if connected:
                adj[i, j] = 1.0
    return adj


def adjacency_to_attn_mask(adj: torch.Tensor, blocked_value: float = -1e4) -> torch.Tensor:
    """Convert adjacency to additive attention mask (N, N) for nn.MultiheadAttention."""
    mask = torch.zeros_like(adj)
    mask[adj == 0] = blocked_value
    return mask
