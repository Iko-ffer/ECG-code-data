#!/usr/bin/env python3
"""Train Exp4 reconstruction model (GAN-U-Net or CNN baseline)."""

from __future__ import annotations

import argparse
import logging
import math
import shutil
from pathlib import Path

import torch
import torch.nn as nn
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm

from src.constants import LEAD_PAIR_TO_INDEX
from src.data import build_dataloader
from src.constants import VIRTUAL_LEAD_PAIRS
from src.lead_space import HARD_LEADS_V2V5, hard_focused_channel_weights, m15a_channel_weights, non_input_channel_weights
from src.losses.gan_loss import (
    _band_adv_loss,
    _weighted_l1,
    discriminator_loss,
    generator_adv_loss,
    generator_loss,
)
from src.losses.supervised_loss import supervised_reconstruction_loss
from src.losses.wavelet_loss import (
    LowPassFilter1D,
    MorletBank1D,
    high_pass_only,
    wavelet_event_reconstruction_loss,
    wavelet_m20_multiscale_spatial_loss,
    morph_segment_reconstruction_loss,
    wavelet_m15a_reconstruction_loss,
    wavelet_dual_side_gated_loss,
    wavelet_hf_enhanced_gated_loss,
    wavelet_multiscale_gated_loss,
    wavelet_polarity_reconstruction_loss,
    wavelet_reconstruction_loss,
)
from src.reconstruction import (
    generator_forward,
    merge_input_channel,
    non_input_channel_indices,
    skip_input_waveform,
)
from src.metrics import batch_metrics
from src.models import build_model
from src.utils import ensure_dir, get_device, load_config, set_seed


def hard_channel_indices(input_lead: str, input_idx: int) -> list[int]:
    return [
        LEAD_PAIR_TO_INDEX[p]
        for p in HARD_LEADS_V2V5
        if p in LEAD_PAIR_TO_INDEX and LEAD_PAIR_TO_INDEX[p] != input_idx
    ]


def _clip_generator_grads(generator: nn.Module, max_norm: float | None) -> None:
    if max_norm is None or max_norm <= 0:
        return
    torch.nn.utils.clip_grad_norm_(
        [p for p in generator.parameters() if p.requires_grad],
        max_norm,
    )


def _safe_monitor(val_log: dict[str, float], best_metric: str, cfg: dict) -> float:
    monitor = validation_monitor(val_log, best_metric, cfg)
    if math.isfinite(monitor):
        return monitor
    # NaN Pearson (e.g. unstable M7 / wavelet path): fall back to MAE.
    return -val_log["mae_non_input"]


def _ensure_best_checkpoint(ckpt_dir: Path) -> None:
    best_path = ckpt_dir / "best.pt"
    last_path = ckpt_dir / "last.pt"
    if not best_path.is_file() and last_path.is_file():
        shutil.copy2(last_path, best_path)
        logging.info("No best.pt saved; copied last.pt -> best.pt")


def load_pretrained_generator(
    generator: nn.Module,
    ckpt_path: str | Path,
    device: torch.device,
    strict: bool = True,
    skip_key_substrings: list[str] | None = None,
) -> None:
    path = Path(ckpt_path)
    if not path.is_file():
        logging.warning("init checkpoint not found: %s", path)
        return
    ckpt = torch.load(path, map_location=device, weights_only=False)
    state = ckpt.get("generator", ckpt)
    skip = list(skip_key_substrings or [])
    if skip:
        before = len(state)
        state = {k: v for k, v in state.items() if not any(s in k for s in skip)}
        logging.info(
            "Skipped %d init keys matching %s",
            before - len(state),
            skip,
        )
    if strict:
        missing, unexpected = generator.load_state_dict(state, strict=True)
        logging.info(
            "Loaded generator from %s (missing=%d unexpected=%d)",
            path,
            len(missing),
            len(unexpected),
        )
        return
    model_state = generator.state_dict()
    filtered = {
        k: v
        for k, v in state.items()
        if k in model_state and v.shape == model_state[k].shape
    }
    model_state.update(filtered)
    generator.load_state_dict(model_state)
    logging.info(
        "Partial load generator from %s (%d/%d keys matched)",
        path,
        len(filtered),
        len(state),
    )


def load_pretrained_tcn(generator: nn.Module, ckpt_path: str | Path, device: torch.device) -> None:
    """Load M2 (or compatible) TCN weights into generator.tcn submodule."""
    path = Path(ckpt_path)
    if not path.is_file():
        logging.warning("pretrained_tcn not found: %s", path)
        return
    ckpt = torch.load(path, map_location=device, weights_only=False)
    state = ckpt.get("generator", ckpt)
    if not hasattr(generator, "tcn"):
        logging.warning("Generator has no .tcn submodule; skip pretrained_tcn")
        return
    missing, unexpected = generator.tcn.load_state_dict(state, strict=True)
    logging.info(
        "Loaded pretrained TCN from %s (missing=%d unexpected=%d)",
        path,
        len(missing),
        len(unexpected),
    )


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Exp4 virtual lead reconstruction training")
    p.add_argument("--config", type=str, default="configs/default.yaml")
    p.add_argument("--data-root", type=str, default=None, help="Override data.root")
    p.add_argument("--input-lead", type=str, default=None, help="Override data.input_lead")
    p.add_argument("--resume", type=str, default=None, help="Checkpoint path to resume")
    return p.parse_args()


def save_checkpoint(
    path: Path,
    epoch: int,
    generator: nn.Module,
    discriminator: nn.Module | None,
    opt_g: torch.optim.Optimizer,
    opt_d: torch.optim.Optimizer | None,
    best_score: float,
    cfg: dict,
    best_metric_name: str,
) -> None:
    torch.save(
        {
            "epoch": epoch,
            "generator": generator.state_dict(),
            "discriminator": discriminator.state_dict() if discriminator else None,
            "opt_g": opt_g.state_dict(),
            "opt_d": opt_d.state_dict() if opt_d else None,
            "best_score": best_score,
            "best_metric_name": best_metric_name,
            "config": cfg,
        },
        path,
    )


def _finalize_output(
    raw: torch.Tensor,
    x: torch.Tensor,
    input_idx: int,
    input_skip: bool,
    skip_channel_idx: int = 0,
) -> torch.Tensor:
    if input_skip:
        return merge_input_channel(raw, skip_input_waveform(x, skip_channel_idx), input_idx)
    return raw


def _run_generator(
    generator: nn.Module,
    batch: dict,
    x: torch.Tensor,
    input_idx: int,
    input_skip: bool,
    skip_channel_idx: int = 0,
) -> torch.Tensor:
    raw = generator_forward(generator, x, batch)
    return _finalize_output(raw, x, input_idx, input_skip, skip_channel_idx)


def train_one_epoch_gan(
    generator: nn.Module,
    discriminator: nn.Module,
    loader,
    opt_g: torch.optim.Optimizer,
    opt_d: torch.optim.Optimizer,
    device: torch.device,
    lambda_l1: float,
    lambda_adv: float,
    input_idx: int,
    non_input_idx: list[int],
    input_skip: bool,
    epoch: int,
    writer: SummaryWriter | None,
    log_every: int,
    channel_weights: torch.Tensor | None = None,
    band_adv_weights: dict[str, float] | None = None,
    n_critic: int = 1,
    grad_clip_norm: float | None = None,
    skip_channel_idx: int = 0,
) -> dict[str, float]:
    generator.train()
    discriminator.train()
    l1_crit = nn.L1Loss()
    totals = {
        "g_total": 0.0,
        "d_total": 0.0,
        "mae_all": 0.0,
        "pearson_all": 0.0,
        "mae_non_input": 0.0,
        "pearson_non_input": 0.0,
    }
    n = 0

    pbar = tqdm(loader, desc=f"train epoch {epoch}")
    for step, batch in enumerate(pbar, start=1):
        x = batch["input"].to(device)
        y = batch["target"].to(device)

        for _ in range(n_critic):
            opt_d.zero_grad(set_to_none=True)
            with torch.no_grad():
                fake_d = _run_generator(generator, batch, x, input_idx, input_skip, skip_channel_idx)
            pred_real = discriminator(x, y)
            pred_fake = discriminator(x, fake_d.detach())
            adv_w = _disc_adv_sample_weight(discriminator)
            loss_d, d_log = discriminator_loss(
                pred_real, pred_fake, band_adv_weights, sample_weight=adv_w
            )
            loss_d.backward()
            opt_d.step()

        opt_g.zero_grad(set_to_none=True)
        raw = generator_forward(generator, x, batch)
        fake = _finalize_output(raw, x, input_idx, input_skip, skip_channel_idx)
        pred_fake_for_g = discriminator(x, fake)
        adv_w = _disc_adv_sample_weight(discriminator)
        loss_g, g_log = generator_loss(
            pred_fake_for_g,
            y,
            fake,
            lambda_l1=lambda_l1,
            lambda_adv=lambda_adv,
            criterion_l1=l1_crit,
            l1_channel_indices=non_input_idx if input_skip else None,
            channel_weights=channel_weights if input_skip else None,
            band_adv_weights=band_adv_weights,
            sample_weight=adv_w,
        )
        loss_g.backward()
        _clip_generator_grads(generator, grad_clip_norm)
        opt_g.step()

        with torch.no_grad():
            m_all = batch_metrics(fake, y)
            m_ni = batch_metrics(fake, y, channel_indices=non_input_idx)
        totals["g_total"] += g_log["g_total"]
        totals["d_total"] += d_log["d_total"]
        totals["mae_all"] += m_all["mae"]
        totals["pearson_all"] += m_all["pearson_mean"]
        totals["mae_non_input"] += m_ni["mae"]
        totals["pearson_non_input"] += m_ni["pearson_mean"]
        n += 1

        if step % log_every == 0:
            pbar.set_postfix(
                mae_ni=m_ni["mae"],
                pearson_ni=m_ni["pearson_mean"],
            )
            if writer:
                global_step = (epoch - 1) * len(loader) + step
                writer.add_scalar("train/mae_non_input", m_ni["mae"], global_step)
                writer.add_scalar("train/pearson_non_input", m_ni["pearson_mean"], global_step)

    return {k: v / max(n, 1) for k, v in totals.items()}


def train_one_epoch_hf_gan(
    generator: nn.Module,
    discriminator: nn.Module,
    loader,
    opt_g: torch.optim.Optimizer,
    opt_d: torch.optim.Optimizer,
    device: torch.device,
    lowpass: LowPassFilter1D,
    lambda_adv: float,
    lambda_low_l1: float,
    lambda_low_pearson: float,
    lambda_high_l1: float,
    lambda_high_pearson: float,
    lambda_gated: float,
    lambda_deriv: float,
    lambda_high_deriv: float,
    lambda_baseline_hf: float,
    baseline_gate_max: float,
    input_idx: int,
    non_input_idx: list[int],
    input_skip: bool,
    epoch: int,
    writer: SummaryWriter | None,
    log_every: int,
    channel_weights: torch.Tensor | None = None,
    band_adv_weights: dict[str, float] | None = None,
    n_critic: int = 1,
    grad_clip_norm: float | None = None,
    sign_robust_pearson: bool = True,
    gate_min: float = 1.0,
    gate_max: float = 4.0,
    gate_energy_kernel: int = 31,
    skip_channel_idx: int = 0,
) -> dict[str, float]:
    """M30c: HF-enhanced gated reconstruction + lightweight hard-band GAN."""
    generator.train()
    discriminator.train()
    totals = {
        "g_total": 0.0,
        "g_recon": 0.0,
        "g_adv": 0.0,
        "d_total": 0.0,
        "mae_non_input": 0.0,
        "pearson_non_input": 0.0,
    }
    n = 0
    pbar = tqdm(loader, desc=f"train epoch {epoch}")
    for step, batch in enumerate(pbar, start=1):
        x = batch["input"].to(device)
        y = batch["target"].to(device)
        x1 = skip_input_waveform(x, skip_channel_idx)

        for _ in range(n_critic):
            opt_d.zero_grad(set_to_none=True)
            with torch.no_grad():
                fake_d = _run_generator(generator, batch, x, input_idx, input_skip, skip_channel_idx)
            pred_real = discriminator(x, y)
            pred_fake = discriminator(x, fake_d.detach())
            adv_w = _disc_adv_sample_weight(discriminator)
            loss_d, d_log = discriminator_loss(
                pred_real, pred_fake, band_adv_weights, sample_weight=adv_w
            )
            loss_d.backward()
            opt_d.step()

        opt_g.zero_grad(set_to_none=True)
        raw = generator_forward(generator, x, batch)
        fake = _finalize_output(raw, x, input_idx, input_skip, skip_channel_idx)
        pred_fake_for_g = discriminator(x, fake)
        if isinstance(pred_fake_for_g, dict):
            loss_adv = _band_adv_loss(pred_fake_for_g, band_adv_weights)
        else:
            adv_w = _disc_adv_sample_weight(discriminator)
            loss_adv = generator_adv_loss(pred_fake_for_g, band_adv_weights, adv_w)
        loss_recon = wavelet_hf_enhanced_gated_loss(
            fake,
            y,
            x1,
            non_input_idx,
            lowpass,
            lambda_low_l1=lambda_low_l1,
            lambda_low_pearson=lambda_low_pearson,
            lambda_high_l1=lambda_high_l1,
            lambda_high_pearson=lambda_high_pearson,
            lambda_gated=lambda_gated,
            lambda_deriv=lambda_deriv,
            lambda_high_deriv=lambda_high_deriv,
            lambda_baseline_hf=lambda_baseline_hf,
            sign_robust_pearson=sign_robust_pearson,
            channel_weights=channel_weights,
            gate_min=gate_min,
            gate_max=gate_max,
            baseline_gate_max=baseline_gate_max,
            energy_kernel=gate_energy_kernel,
        )
        loss_g = loss_recon + lambda_adv * loss_adv
        loss_g.backward()
        _clip_generator_grads(generator, grad_clip_norm)
        opt_g.step()

        with torch.no_grad():
            m_ni = batch_metrics(fake, y, channel_indices=non_input_idx)
        totals["g_total"] += float(loss_g.item())
        totals["g_recon"] += float(loss_recon.item())
        totals["g_adv"] += float(loss_adv.item())
        totals["d_total"] += d_log["d_total"]
        totals["mae_non_input"] += m_ni["mae"]
        totals["pearson_non_input"] += m_ni["pearson_mean"]
        n += 1
        if step % log_every == 0:
            pbar.set_postfix(pearson_ni=m_ni["pearson_mean"], g_adv=float(loss_adv.item()))
    return {k: v / max(n, 1) for k, v in totals.items()}


def _disc_adv_sample_weight(discriminator: nn.Module) -> torch.Tensor | None:
    if hasattr(discriminator, "adv_sample_weights"):
        return discriminator.adv_sample_weights()
    return None


def _m14_disc_high_pass(
    x: torch.Tensor,
    y: torch.Tensor,
    fake: torch.Tensor,
    lowpass: LowPassFilter1D,
    non_input_idx: list[int],
    discriminator: nn.Module,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Prepare (x_cond, y_real_hp, y_fake_hp) for M14 / wavelet discriminators."""
    from src.models.m14_discriminators import GraphTemporalDiscriminator

    if isinstance(discriminator, GraphTemporalDiscriminator):
        x_hp = high_pass_only(x, lowpass)
        y_hp = high_pass_only(y, lowpass)
        fake_hp = high_pass_only(fake, lowpass)
        return x_hp, y_hp, fake_hp
    y_hp = high_pass_only(y[:, non_input_idx], lowpass)
    fake_hp = high_pass_only(fake[:, non_input_idx], lowpass)
    return x, y_hp, fake_hp


def train_one_epoch_wavelet_gan(
    generator: nn.Module,
    discriminator: nn.Module,
    loader,
    opt_g: torch.optim.Optimizer,
    opt_d: torch.optim.Optimizer,
    device: torch.device,
    lowpass: LowPassFilter1D,
    lambda_l1: float,
    lambda_adv: float,
    lambda_low_l1: float,
    lambda_low_pearson: float,
    lambda_high_mse: float,
    input_idx: int,
    non_input_idx: list[int],
    input_skip: bool,
    epoch: int,
    writer: SummaryWriter | None,
    log_every: int,
    channel_weights: torch.Tensor | None = None,
    n_critic: int = 1,
    grad_clip_norm: float | None = None,
    use_polarity_loss: bool = False,
    sign_robust_pearson: bool = True,
    lambda_high_pearson: float = 8.0,
    lambda_deriv: float = 8.0,
    gan_warmup_epochs: int = 0,
    band_adv_weights: dict[str, float] | None = None,
    skip_channel_idx: int = 0,
) -> dict[str, float]:
    generator.train()
    discriminator.train()
    gan_active = epoch > gan_warmup_epochs
    totals = {
        "g_total": 0.0,
        "d_total": 0.0,
        "mae_all": 0.0,
        "pearson_all": 0.0,
        "mae_non_input": 0.0,
        "pearson_non_input": 0.0,
    }
    n = 0
    pbar = tqdm(loader, desc=f"train epoch {epoch}")
    for step, batch in enumerate(pbar, start=1):
        x = batch["input"].to(device)
        y = batch["target"].to(device)

        if gan_active:
            for _ in range(n_critic):
                opt_d.zero_grad(set_to_none=True)
                with torch.no_grad():
                    fake_d = _run_generator(generator, batch, x, input_idx, input_skip, skip_channel_idx)
                x_d, y_high, fake_high = _m14_disc_high_pass(
                    x, y, fake_d, lowpass, non_input_idx, discriminator
                )
                pred_real = discriminator(x_d, y_high)
                pred_fake = discriminator(x_d, fake_high.detach())
                loss_d, d_log = discriminator_loss(pred_real, pred_fake, band_adv_weights)
                if not torch.isfinite(loss_d):
                    logging.warning("non-finite D loss at epoch %d step %d; skipping", epoch, step)
                    continue
                loss_d.backward()
                torch.nn.utils.clip_grad_norm_(discriminator.parameters(), grad_clip_norm or 1.0)
                opt_d.step()

        opt_g.zero_grad(set_to_none=True)
        raw = generator_forward(generator, x, batch)
        fake = _finalize_output(raw, x, input_idx, input_skip, skip_channel_idx)
        loss_wave = (
            wavelet_polarity_reconstruction_loss(
                fake,
                y,
                non_input_idx,
                lowpass,
                lambda_low_l1=lambda_low_l1,
                lambda_low_pearson=lambda_low_pearson,
                lambda_high_mse=lambda_high_mse,
                lambda_high_pearson=lambda_high_pearson,
                lambda_deriv=lambda_deriv,
                sign_robust_pearson=sign_robust_pearson,
                channel_weights=channel_weights,
            )
            if use_polarity_loss
            else wavelet_reconstruction_loss(
                fake,
                y,
                non_input_idx,
                lowpass,
                lambda_low_l1=lambda_low_l1,
                lambda_low_pearson=lambda_low_pearson,
                lambda_high_mse=lambda_high_mse,
                channel_weights=channel_weights,
            )
        )
        if gan_active:
            x_d, _, fake_high = _m14_disc_high_pass(
                x, y, fake, lowpass, non_input_idx, discriminator
            )
            pred_fake_g = discriminator(x_d, fake_high)
            loss_adv = generator_adv_loss(pred_fake_g, band_adv_weights)
            loss_g = lambda_adv * loss_adv + loss_wave
        else:
            loss_g = loss_wave
            d_log = {"d_total": 0.0}
        if not torch.isfinite(loss_g):
            logging.warning("non-finite G loss at epoch %d step %d; skipping", epoch, step)
            continue
        loss_g.backward()
        _clip_generator_grads(generator, grad_clip_norm)
        if any(
            p.grad is not None and not torch.isfinite(p.grad).all()
            for p in generator.parameters()
        ):
            logging.warning("non-finite G grad at epoch %d step %d; skipping", epoch, step)
            opt_g.zero_grad(set_to_none=True)
            continue
        opt_g.step()

        with torch.no_grad():
            m_ni = batch_metrics(fake, y, channel_indices=non_input_idx)
        totals["g_total"] += float(loss_g.detach())
        totals["d_total"] += d_log.get("d_total", 0.0)
        totals["mae_non_input"] += m_ni["mae"]
        totals["pearson_non_input"] += m_ni["pearson_mean"]
        n += 1
        if step % log_every == 0:
            pbar.set_postfix(mae_ni=m_ni["mae"], pearson_ni=m_ni["pearson_mean"])

    return {k: v / max(n, 1) for k, v in totals.items()}


def train_one_epoch_m25_refine(
    generator: nn.Module,
    discriminator: nn.Module,
    loader,
    opt_g: torch.optim.Optimizer,
    opt_d: torch.optim.Optimizer,
    device: torch.device,
    lowpass: LowPassFilter1D,
    lambda_adv: float,
    lambda_low_l1: float,
    lambda_low_pearson: float,
    lambda_high_l1: float,
    lambda_high_pearson: float,
    lambda_deriv: float,
    input_idx: int,
    non_input_idx: list[int],
    input_skip: bool,
    epoch: int,
    writer: SummaryWriter | None,
    log_every: int,
    channel_weights: torch.Tensor | None = None,
    n_critic: int = 1,
    grad_clip_norm: float | None = None,
    sign_robust_pearson: bool = True,
    use_hf_enhanced_gated_loss: bool = False,
    use_gated_event_loss: bool = False,
    use_dual_side_gated_loss: bool = False,
    lambda_gated: float = 8.0,
    lambda_high_deriv: float = 4.0,
    lambda_baseline_hf: float = 6.0,
    baseline_gate_max: float = 3.0,
    gate_min: float = 1.0,
    gate_max: float = 4.0,
    gate_energy_kernel: int = 31,
    gan_warmup_epochs: int = 0,
    skip_channel_idx: int = 0,
) -> dict[str, float]:
    """
    M25 refine: M15a or gated event loss on full-band output + anatomy-aware PatchGAN (full band, no high-pass).
    """
    generator.train()
    discriminator.train()
    gan_active = epoch > gan_warmup_epochs
    totals = {
        "g_total": 0.0,
        "d_total": 0.0,
        "mae_all": 0.0,
        "pearson_all": 0.0,
        "mae_non_input": 0.0,
        "pearson_non_input": 0.0,
    }
    n = 0
    pbar = tqdm(loader, desc=f"train epoch {epoch}")
    for step, batch in enumerate(pbar, start=1):
        x = batch["input"].to(device)
        y = batch["target"].to(device)

        if gan_active:
            for _ in range(n_critic):
                opt_d.zero_grad(set_to_none=True)
                with torch.no_grad():
                    fake_d = _run_generator(generator, batch, x, input_idx, input_skip, skip_channel_idx)
                pred_real = discriminator(x, y)
                pred_fake = discriminator(x, fake_d.detach())
                loss_d, d_log = discriminator_loss(pred_real, pred_fake)
                if not torch.isfinite(loss_d):
                    logging.warning("non-finite D loss at epoch %d step %d; skipping", epoch, step)
                    continue
                loss_d.backward()
                torch.nn.utils.clip_grad_norm_(discriminator.parameters(), grad_clip_norm or 1.0)
                opt_d.step()

        opt_g.zero_grad(set_to_none=True)
        raw = generator_forward(generator, x, batch)
        fake = _finalize_output(raw, x, input_idx, input_skip, skip_channel_idx)
        x1 = skip_input_waveform(x, skip_channel_idx)
        if use_dual_side_gated_loss and input_skip:
            loss_rec = wavelet_dual_side_gated_loss(
                fake,
                y,
                x1,
                non_input_idx,
                lowpass,
                lambda_low_l1=lambda_low_l1,
                lambda_low_pearson=lambda_low_pearson,
                lambda_high_l1=lambda_high_l1,
                lambda_high_pearson=lambda_high_pearson,
                lambda_gated=lambda_gated,
                lambda_deriv=lambda_deriv,
                sign_robust_pearson=sign_robust_pearson,
                channel_weights=channel_weights,
                gate_min=gate_min,
                gate_max=gate_max,
                energy_kernel=gate_energy_kernel,
            )
        elif use_gated_event_loss and input_skip:
            loss_rec = wavelet_multiscale_gated_loss(
                fake,
                y,
                x1,
                non_input_idx,
                lowpass,
                lambda_low_l1=lambda_low_l1,
                lambda_low_pearson=lambda_low_pearson,
                lambda_high_l1=lambda_high_l1,
                lambda_high_pearson=lambda_high_pearson,
                lambda_gated=lambda_gated,
                lambda_deriv=lambda_deriv,
                sign_robust_pearson=sign_robust_pearson,
                channel_weights=channel_weights,
                gate_min=gate_min,
                gate_max=gate_max,
                energy_kernel=gate_energy_kernel,
            )
        else:
            loss_rec = wavelet_m15a_reconstruction_loss(
                fake,
                y,
                non_input_idx,
                lowpass,
                lambda_low_l1=lambda_low_l1,
                lambda_low_pearson=lambda_low_pearson,
                lambda_high_l1=lambda_high_l1,
                lambda_high_pearson=lambda_high_pearson,
                lambda_deriv=lambda_deriv,
                sign_robust_pearson=sign_robust_pearson,
                channel_weights=channel_weights,
            )
        if gan_active:
            pred_fake_g = discriminator(x, fake)
            loss_adv = generator_adv_loss(pred_fake_g)
            loss_g = lambda_adv * loss_adv + loss_rec
        else:
            loss_g = loss_rec
            d_log = {"d_total": 0.0}
        if not torch.isfinite(loss_g):
            logging.warning("non-finite G loss at epoch %d step %d; skipping", epoch, step)
            continue
        loss_g.backward()
        _clip_generator_grads(generator, grad_clip_norm)
        if any(
            p.grad is not None and not torch.isfinite(p.grad).all()
            for p in generator.parameters()
        ):
            logging.warning("non-finite G grad at epoch %d step %d; skipping", epoch, step)
            opt_g.zero_grad(set_to_none=True)
            continue
        opt_g.step()

        with torch.no_grad():
            m_ni = batch_metrics(fake, y, channel_indices=non_input_idx)
        totals["g_total"] += float(loss_g.detach())
        totals["d_total"] += d_log.get("d_total", 0.0)
        totals["mae_non_input"] += m_ni["mae"]
        totals["pearson_non_input"] += m_ni["pearson_mean"]
        n += 1
        if step % log_every == 0:
            pbar.set_postfix(mae_ni=m_ni["mae"], pearson_ni=m_ni["pearson_mean"])

    return {k: v / max(n, 1) for k, v in totals.items()}


def train_one_epoch_progressive_gan(
    generator: nn.Module,
    discriminator: nn.Module,
    loader,
    opt_g: torch.optim.Optimizer,
    opt_d: torch.optim.Optimizer,
    device: torch.device,
    lowpass: LowPassFilter1D,
    lambda_l1: float,
    lambda_adv: float,
    lambda_high_mse: float,
    input_idx: int,
    non_input_idx: list[int],
    input_skip: bool,
    epoch: int,
    writer: SummaryWriter | None,
    log_every: int,
    channel_weights: torch.Tensor | None = None,
    band_adv_weights: dict[str, float] | None = None,
    n_critic: int = 1,
    grad_clip_norm: float | None = None,
    skip_channel_idx: int = 0,
) -> dict[str, float]:
    """Stage-2 progressive refine: frozen low path, GAN + high-band MSE on full output."""
    generator.train()
    discriminator.train()
    l1_crit = nn.L1Loss()
    totals = {
        "g_total": 0.0,
        "d_total": 0.0,
        "mae_non_input": 0.0,
        "pearson_non_input": 0.0,
    }
    n = 0
    pbar = tqdm(loader, desc=f"train epoch {epoch}")
    for step, batch in enumerate(pbar, start=1):
        x = batch["input"].to(device)
        y = batch["target"].to(device)

        for _ in range(n_critic):
            opt_d.zero_grad(set_to_none=True)
            with torch.no_grad():
                fake_d = _run_generator(generator, batch, x, input_idx, input_skip, skip_channel_idx)
            pred_real = discriminator(x, y)
            pred_fake = discriminator(x, fake_d.detach())
            adv_w = _disc_adv_sample_weight(discriminator)
            loss_d, d_log = discriminator_loss(
                pred_real, pred_fake, band_adv_weights, sample_weight=adv_w
            )
            loss_d.backward()
            opt_d.step()

        opt_g.zero_grad(set_to_none=True)
        raw = generator_forward(generator, x, batch)
        fake = _finalize_output(raw, x, input_idx, input_skip, skip_channel_idx)
        pred_fake_g = discriminator(x, fake)
        adv_w = _disc_adv_sample_weight(discriminator)
        loss_g_adv, g_log = generator_loss(
            pred_fake_g,
            y,
            fake,
            lambda_l1=0.0,
            lambda_adv=lambda_adv,
            criterion_l1=l1_crit,
            l1_channel_indices=non_input_idx if input_skip else None,
            channel_weights=channel_weights if input_skip else None,
            band_adv_weights=band_adv_weights,
            sample_weight=adv_w,
        )
        from src.losses.gan_loss import _weighted_l1

        loss_l1 = _weighted_l1(
            fake[:, non_input_idx],
            y[:, non_input_idx],
            list(range(len(non_input_idx))),
            channel_weights,
        )
        p_high = high_pass_only(fake[:, non_input_idx], lowpass)
        t_high = high_pass_only(y[:, non_input_idx], lowpass)
        diff = p_high - t_high
        if channel_weights is not None:
            w = channel_weights.to(device).view(1, -1, 1)
            loss_high = (diff.pow(2) * w).sum() / w.sum().clamp(min=1e-6) / diff.size(0)
        else:
            loss_high = diff.pow(2).mean()
        loss_g = lambda_l1 * loss_l1 + loss_g_adv + lambda_high_mse * loss_high
        loss_g.backward()
        _clip_generator_grads(generator, grad_clip_norm)
        opt_g.step()

        with torch.no_grad():
            m_ni = batch_metrics(fake, y, channel_indices=non_input_idx)
        totals["g_total"] += float(loss_g.detach())
        totals["d_total"] += d_log["d_total"]
        totals["mae_non_input"] += m_ni["mae"]
        totals["pearson_non_input"] += m_ni["pearson_mean"]
        n += 1
        if step % log_every == 0:
            pbar.set_postfix(mae_ni=m_ni["mae"], pearson_ni=m_ni["pearson_mean"])

    return {k: v / max(n, 1) for k, v in totals.items()}


def freeze_progressive_modules(generator: nn.Module, stage: int) -> None:
    if not hasattr(generator, "low_refiner"):
        return
    if stage == 1:
        for param in generator.high_refiner.parameters():
            param.requires_grad = False
        logging.info("Progressive stage 1: frozen high_refiner")
    elif stage == 2:
        for param in generator.tcn.parameters():
            param.requires_grad = False
        for param in generator.low_refiner.parameters():
            param.requires_grad = False
        logging.info("Progressive stage 2: frozen TCN + low_refiner")


def build_generator_optimizer(generator: nn.Module, cfg: dict) -> torch.optim.Optimizer:
    """Build Adam for generator; optional asymmetric LR param groups."""
    train_cfg = cfg["train"]
    beta1 = float(train_cfg["beta1"])
    beta2 = float(train_cfg["beta2"])
    asymmetric = train_cfg.get("asymmetric_lr")
    if asymmetric:
        high_patterns = asymmetric.get("high_lr_patterns", ["cross_attn"])
        tcn_patterns = asymmetric.get("tcn_lr_patterns", [])
        lr_high = float(asymmetric.get("lr_high", 2e-4))
        lr_low = float(asymmetric.get("lr_low", 1e-5))
        lr_tcn = float(asymmetric.get("lr_tcn", lr_low))
        high_params: list[torch.nn.Parameter] = []
        tcn_params: list[torch.nn.Parameter] = []
        low_params: list[torch.nn.Parameter] = []
        for name, param in generator.named_parameters():
            if not param.requires_grad:
                continue
            if tcn_patterns and any(pat in name for pat in tcn_patterns):
                tcn_params.append(param)
            elif any(pat in name for pat in high_patterns):
                high_params.append(param)
            else:
                low_params.append(param)
        param_groups: list[dict] = []
        if high_params:
            param_groups.append({"params": high_params, "lr": lr_high})
        if tcn_params:
            param_groups.append({"params": tcn_params, "lr": lr_tcn})
        if low_params:
            param_groups.append({"params": low_params, "lr": lr_low})
        logging.info(
            "Asymmetric LR: high=%g (%d) tcn=%g (%d) low=%g (%d) patterns=%s tcn=%s",
            lr_high,
            len(high_params),
            lr_tcn,
            len(tcn_params),
            lr_low,
            len(low_params),
            high_patterns,
            tcn_patterns,
        )
        return torch.optim.Adam(param_groups, betas=(beta1, beta2))
    return torch.optim.Adam(
        [p for p in generator.parameters() if p.requires_grad],
        lr=float(train_cfg["lr_g"]),
        betas=(beta1, beta2),
    )


def apply_config_freeze(generator: nn.Module, cfg: dict) -> None:
    """Freeze by module name patterns from config (curriculum phases)."""
    freeze_all_except = cfg.get("freeze_all_except") or []
    freeze_modules = cfg.get("freeze_modules") or []
    if not freeze_all_except and not freeze_modules:
        return
    if freeze_all_except:
        for param in generator.parameters():
            param.requires_grad = False
        n_train = 0
        for name, param in generator.named_parameters():
            if any(pat in name for pat in freeze_all_except):
                param.requires_grad = True
                n_train += param.numel()
        logging.info(
            "freeze_all_except=%s trainable_params=%d",
            freeze_all_except,
            n_train,
        )
    else:
        for name, param in generator.named_parameters():
            if any(pat in name for pat in freeze_modules):
                param.requires_grad = False
        n_train = sum(p.numel() for p in generator.parameters() if p.requires_grad)
        logging.info("freeze_modules=%s trainable_params=%d", freeze_modules, n_train)


def _phenomenon_sampler(dataset, weights_map: dict[str, float]):
    import torch.utils.data as tud

    from src.data.dataset import VirtualLeadReconstructionDataset

    if not isinstance(dataset, VirtualLeadReconstructionDataset):
        raise TypeError("phenomenon_weights requires VirtualLeadReconstructionDataset")
    weights = [float(weights_map.get(s.key.phenomenon, 1.0)) for s in dataset.samples]
    return tud.WeightedRandomSampler(weights, num_samples=len(weights), replacement=True)


def train_one_epoch_cnn(
    generator: nn.Module,
    loader,
    opt_g: torch.optim.Optimizer,
    device: torch.device,
    input_idx: int,
    non_input_idx: list[int],
    input_skip: bool,
    epoch: int,
    writer: SummaryWriter | None,
    log_every: int,
    channel_weights: torch.Tensor | None = None,
    lambda_l1: float = 100.0,
    lambda_pearson: float = 0.0,
    lowpass: LowPassFilter1D | None = None,
    lambda_low_l1: float = 100.0,
    lambda_low_pearson: float = 10.0,
    lambda_high_mse: float = 10.0,
    use_wavelet_loss: bool = False,
    use_polarity_loss: bool = False,
    use_m15a_loss: bool = False,
    use_hf_enhanced_gated_loss: bool = False,
    use_gated_event_loss: bool = False,
    use_dual_side_gated_loss: bool = False,
    lambda_gated: float = 8.0,
    lambda_high_deriv: float = 4.0,
    lambda_baseline_hf: float = 6.0,
    baseline_gate_max: float = 3.0,
    gate_min: float = 1.0,
    gate_max: float = 4.0,
    gate_energy_kernel: int = 31,
    sign_robust_pearson: bool = True,
    lambda_high_pearson: float = 5.0,
    lambda_high_l1: float = 10.0,
    lambda_deriv: float = 5.0,
    grad_clip_norm: float | None = None,
    use_event_loss: bool = False,
    lambda_event: float = 5.0,
    lambda_sst: float = 0.0,
    morlet: MorletBank1D | None = None,
    use_morph_loss: bool = False,
    lambda_morph_qrs: float = 8.0,
    lambda_morph_st: float = 5.0,
    use_m20_loss: bool = False,
    low_channel_weights: torch.Tensor | None = None,
    high_channel_weights: torch.Tensor | None = None,
    m20_high_band_gain: float = 1.0,
    skip_channel_idx: int = 0,
) -> dict[str, float]:
    generator.train()
    l1_crit = nn.L1Loss()
    totals = {
        "g_total": 0.0,
        "mae_all": 0.0,
        "pearson_all": 0.0,
        "mae_non_input": 0.0,
        "pearson_non_input": 0.0,
    }
    n = 0

    pbar = tqdm(loader, desc=f"train epoch {epoch}")
    for step, batch in enumerate(pbar, start=1):
        x = batch["input"].to(device)
        y = batch["target"].to(device)
        opt_g.zero_grad(set_to_none=True)
        fake = _run_generator(generator, batch, x, input_idx, input_skip, skip_channel_idx)
        x1 = skip_input_waveform(x, skip_channel_idx)
        if use_morph_loss and lowpass is not None and input_skip:
            loss = morph_segment_reconstruction_loss(
                fake,
                y,
                x1,
                non_input_idx,
                lowpass,
                lambda_low_l1=lambda_low_l1,
                lambda_low_pearson=lambda_low_pearson,
                lambda_high_l1=lambda_high_l1,
                lambda_high_pearson=lambda_high_pearson,
                lambda_morph_qrs=lambda_morph_qrs,
                lambda_morph_st=lambda_morph_st,
                sign_robust_pearson=sign_robust_pearson,
                channel_weights=channel_weights,
            )
        elif use_hf_enhanced_gated_loss and lowpass is not None and input_skip:
            loss = wavelet_hf_enhanced_gated_loss(
                fake,
                y,
                x1,
                non_input_idx,
                lowpass,
                lambda_low_l1=lambda_low_l1,
                lambda_low_pearson=lambda_low_pearson,
                lambda_high_l1=lambda_high_l1,
                lambda_high_pearson=lambda_high_pearson,
                lambda_gated=lambda_gated,
                lambda_deriv=lambda_deriv,
                lambda_high_deriv=lambda_high_deriv,
                lambda_baseline_hf=lambda_baseline_hf,
                sign_robust_pearson=sign_robust_pearson,
                channel_weights=channel_weights,
                gate_min=gate_min,
                gate_max=gate_max,
                baseline_gate_max=baseline_gate_max,
                energy_kernel=gate_energy_kernel,
            )
        elif use_dual_side_gated_loss and lowpass is not None and input_skip:
            loss = wavelet_dual_side_gated_loss(
                fake,
                y,
                x1,
                non_input_idx,
                lowpass,
                lambda_low_l1=lambda_low_l1,
                lambda_low_pearson=lambda_low_pearson,
                lambda_high_l1=lambda_high_l1,
                lambda_high_pearson=lambda_high_pearson,
                lambda_gated=lambda_gated,
                lambda_deriv=lambda_deriv,
                sign_robust_pearson=sign_robust_pearson,
                channel_weights=channel_weights,
                gate_min=gate_min,
                gate_max=gate_max,
                energy_kernel=gate_energy_kernel,
            )
        elif use_gated_event_loss and lowpass is not None and input_skip:
            loss = wavelet_multiscale_gated_loss(
                fake,
                y,
                x1,
                non_input_idx,
                lowpass,
                lambda_low_l1=lambda_low_l1,
                lambda_low_pearson=lambda_low_pearson,
                lambda_high_l1=lambda_high_l1,
                lambda_high_pearson=lambda_high_pearson,
                lambda_gated=lambda_gated,
                lambda_deriv=lambda_deriv,
                sign_robust_pearson=sign_robust_pearson,
                channel_weights=channel_weights,
                gate_min=gate_min,
                gate_max=gate_max,
                energy_kernel=gate_energy_kernel,
            )
        elif use_event_loss and lowpass is not None and input_skip:
            loss = wavelet_event_reconstruction_loss(
                fake,
                y,
                non_input_idx,
                lowpass,
                lambda_low_l1=lambda_low_l1,
                lambda_low_pearson=lambda_low_pearson,
                lambda_high_l1=lambda_high_l1,
                lambda_high_pearson=lambda_high_pearson,
                lambda_event=lambda_event,
                lambda_deriv=lambda_deriv,
                sign_robust_pearson=sign_robust_pearson,
                channel_weights=channel_weights,
                morlet=morlet,
                lambda_sst=lambda_sst,
            )
        elif use_m20_loss and lowpass is not None and input_skip:
            loss = wavelet_m20_multiscale_spatial_loss(
                fake,
                y,
                non_input_idx,
                lowpass,
                lambda_low_l1=lambda_low_l1,
                lambda_low_pearson=lambda_low_pearson,
                lambda_high_l1=lambda_high_l1,
                lambda_high_pearson=lambda_high_pearson,
                lambda_deriv=lambda_deriv,
                sign_robust_pearson=sign_robust_pearson,
                low_channel_weights=low_channel_weights,
                high_channel_weights=high_channel_weights,
                high_band_gain=m20_high_band_gain,
            )
        elif use_m15a_loss and lowpass is not None and input_skip:
            loss = wavelet_m15a_reconstruction_loss(
                fake,
                y,
                non_input_idx,
                lowpass,
                lambda_low_l1=lambda_low_l1,
                lambda_low_pearson=lambda_low_pearson,
                lambda_high_l1=lambda_high_l1,
                lambda_high_pearson=lambda_high_pearson,
                lambda_deriv=lambda_deriv,
                sign_robust_pearson=sign_robust_pearson,
                channel_weights=channel_weights,
            )
        elif use_polarity_loss and lowpass is not None and input_skip:
            loss = wavelet_polarity_reconstruction_loss(
                fake,
                y,
                non_input_idx,
                lowpass,
                lambda_low_l1=lambda_low_l1,
                lambda_low_pearson=lambda_low_pearson,
                lambda_high_mse=lambda_high_mse,
                lambda_high_pearson=lambda_high_pearson,
                lambda_deriv=lambda_deriv,
                sign_robust_pearson=sign_robust_pearson,
                channel_weights=channel_weights,
            )
        elif use_wavelet_loss and lowpass is not None and input_skip:
            loss = wavelet_reconstruction_loss(
                fake,
                y,
                non_input_idx,
                lowpass,
                lambda_low_l1=lambda_low_l1,
                lambda_low_pearson=lambda_low_pearson,
                lambda_high_mse=lambda_high_mse,
                channel_weights=channel_weights,
            )
        elif input_skip:
            if lambda_pearson > 0:
                loss = supervised_reconstruction_loss(
                    fake,
                    y,
                    non_input_idx,
                    channel_weights,
                    lambda_l1=lambda_l1,
                    lambda_pearson=lambda_pearson,
                )
            elif channel_weights is not None:
                loss = _weighted_l1(fake, y, non_input_idx, channel_weights)
            else:
                loss = l1_crit(fake[:, non_input_idx], y[:, non_input_idx])
        else:
            loss = l1_crit(fake, y)
        if not torch.isfinite(loss):
            logging.warning("non-finite loss at epoch %d step %d; skipping batch", epoch, step)
            continue
        loss.backward()
        _clip_generator_grads(generator, grad_clip_norm)
        if any(
            p.grad is not None and not torch.isfinite(p.grad).all()
            for p in generator.parameters()
        ):
            logging.warning("non-finite grad at epoch %d step %d; skipping batch", epoch, step)
            opt_g.zero_grad(set_to_none=True)
            continue
        opt_g.step()

        m_all = batch_metrics(fake.detach(), y)
        m_ni = batch_metrics(fake.detach(), y, channel_indices=non_input_idx)
        totals["g_total"] += float(loss.detach())
        totals["mae_all"] += m_all["mae"]
        totals["pearson_all"] += m_all["pearson_mean"]
        totals["mae_non_input"] += m_ni["mae"]
        totals["pearson_non_input"] += m_ni["pearson_mean"]
        n += 1
        if step % log_every == 0 and writer:
            global_step = (epoch - 1) * len(loader) + step
            writer.add_scalar("train/mae_non_input", m_ni["mae"], global_step)

    return {k: v / max(n, 1) for k, v in totals.items()}


@torch.no_grad()
def validate(
    generator: nn.Module,
    loader,
    device: torch.device,
    input_idx: int,
    non_input_idx: list[int],
    input_skip: bool,
    hard_idx: list[int] | None = None,
    skip_channel_idx: int = 0,
    lowpass: LowPassFilter1D | None = None,
) -> dict[str, float]:
    generator.eval()
    totals = {
        "mae_all": 0.0,
        "mse_all": 0.0,
        "pearson_all": 0.0,
        "mae_non_input": 0.0,
        "mse_non_input": 0.0,
        "pearson_non_input": 0.0,
        "pearson_hard": 0.0,
        "mae_hard": 0.0,
        "mae_deriv": 0.0,
        "pearson_highpass": 0.0,
    }
    n = 0
    for batch in tqdm(loader, desc="val"):
        x = batch["input"].to(device)
        y = batch["target"].to(device)
        fake = _run_generator(generator, batch, x, input_idx, input_skip, skip_channel_idx)
        m_all = batch_metrics(fake, y)
        m_ni = batch_metrics(fake, y, channel_indices=non_input_idx)
        totals["mae_all"] += m_all["mae"]
        totals["mse_all"] += m_all["mse"]
        totals["pearson_all"] += m_all["pearson_mean"]
        totals["mae_non_input"] += m_ni["mae"]
        totals["mse_non_input"] += m_ni["mse"]
        totals["pearson_non_input"] += m_ni["pearson_mean"]
        if hard_idx:
            m_h = batch_metrics(fake, y, channel_indices=hard_idx)
            totals["pearson_hard"] += m_h["pearson_mean"]
            totals["mae_hard"] += m_h["mae"]
        p = fake[:, non_input_idx, 1:] - fake[:, non_input_idx, :-1]
        t = y[:, non_input_idx, 1:] - y[:, non_input_idx, :-1]
        totals["mae_deriv"] += float(torch.mean(torch.abs(p - t)).item())
        if lowpass is not None:
            fake_hp = high_pass_only(fake[:, non_input_idx], lowpass)
            y_hp = high_pass_only(y[:, non_input_idx], lowpass)
            m_hp = batch_metrics(fake_hp, y_hp)
            totals["pearson_highpass"] += m_hp["pearson_mean"]
        n += 1
    out = {k: v / max(n, 1) for k, v in totals.items()}
    if not hard_idx:
        out["pearson_hard"] = 0.0
        out["mae_hard"] = 0.0
    if lowpass is None:
        out["pearson_highpass"] = 0.0
    return out


def validation_monitor(val_log: dict[str, float], best_metric: str, cfg: dict) -> float:
    if best_metric == "step1_hf_composite":
        w_p14 = float(cfg["train"].get("metric_w_pearson_14", 0.25))
        w_ph = float(cfg["train"].get("metric_w_pearson_hard", 0.20))
        w_php = float(cfg["train"].get("metric_w_pearson_highpass", 0.30))
        w_mh = float(cfg["train"].get("metric_w_mae_hard", 0.15))
        w_md = float(cfg["train"].get("metric_w_mae_deriv", 0.10))
        ref_hard = float(cfg["train"].get("monitor_ref_mae_hard", 0.340))
        ref_deriv = float(cfg["train"].get("monitor_ref_mae_deriv", 0.033))
        mae_hard_norm = val_log.get("mae_hard", ref_hard) / max(ref_hard, 1e-8)
        mae_deriv_norm = val_log.get("mae_deriv", ref_deriv) / max(ref_deriv, 1e-8)
        return (
            w_p14 * val_log["pearson_non_input"]
            + w_ph * val_log["pearson_hard"]
            + w_php * val_log.get("pearson_highpass", 0.0)
            - w_mh * mae_hard_norm
            - w_md * mae_deriv_norm
        )
    if best_metric == "step1_composite":
        w_p14 = float(cfg["train"].get("metric_w_pearson_14", 0.35))
        w_ph = float(cfg["train"].get("metric_w_pearson_hard", 0.25))
        w_mh = float(cfg["train"].get("metric_w_mae_hard", 0.20))
        w_md = float(cfg["train"].get("metric_w_mae_deriv", 0.20))
        ref_hard = float(cfg["train"].get("monitor_ref_mae_hard", 0.340))
        ref_deriv = float(cfg["train"].get("monitor_ref_mae_deriv", 0.033))
        mae_hard_norm = val_log.get("mae_hard", ref_hard) / max(ref_hard, 1e-8)
        mae_deriv_norm = val_log.get("mae_deriv", ref_deriv) / max(ref_deriv, 1e-8)
        return (
            w_p14 * val_log["pearson_non_input"]
            + w_ph * val_log["pearson_hard"]
            - w_mh * mae_hard_norm
            - w_md * mae_deriv_norm
        )
    if best_metric == "pearson_composite":
        w14 = float(cfg["train"].get("metric_w_14", 0.5))
        wh = float(cfg["train"].get("metric_w_hard", 0.5))
        return w14 * val_log["pearson_non_input"] + wh * val_log["pearson_hard"]
    if best_metric == "pearson_hard":
        return val_log["pearson_hard"]
    if best_metric == "non_input_pearson":
        return val_log["pearson_non_input"]
    return val_log["mae_non_input"]


def is_improved(score: float, best: float, metric_name: str) -> bool:
    if metric_name in (
        "non_input_pearson",
        "pearson_composite",
        "pearson_hard",
        "step1_composite",
        "step1_hf_composite",
    ):
        return score > best
    if metric_name in ("non_input_mae", "mae"):
        return score < best
    return score > best


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    args = parse_args()
    cfg = load_config(args.config)
    if args.data_root:
        cfg["data"]["root"] = args.data_root
    if args.input_lead:
        cfg["data"]["input_lead"] = args.input_lead

    input_lead = cfg["data"]["input_lead"]
    input_idx = LEAD_PAIR_TO_INDEX[input_lead]
    non_input_idx = non_input_channel_indices(15, input_idx)
    hard_idx = hard_channel_indices(input_lead, input_idx)
    input_skip = bool(cfg["model"].get("input_skip", False))
    best_metric = cfg["train"].get("best_metric", "non_input_pearson")
    n_critic = int(cfg["train"].get("n_critic", 1))
    patience = int(cfg["train"].get("early_stop_patience", 0))
    save_every = int(cfg["train"].get("save_every", 5))

    set_seed(int(cfg["train"]["seed"]))
    device = get_device(cfg["train"]["device"])

    data_root = Path(cfg["data"]["root"]).resolve()
    from src.data.dataset import VirtualLeadReconstructionDataset

    delay_lags = cfg["data"].get("delay_lags")
    train_ds = VirtualLeadReconstructionDataset(
        data_root=data_root,
        split=cfg["data"]["split"],
        input_lead=input_lead,
        signal_length=int(cfg["data"]["signal_length"]),
        phenomena=cfg["data"].get("phenomena"),
        labels=cfg["data"].get("labels"),
        dedupe=cfg["data"].get("dedupe_train", True),
        delay_lags=delay_lags,
    )
    skip_channel_idx = train_ds.delay_center_index if delay_lags else 0
    phenomenon_weights = cfg["train"].get("phenomenon_weights")
    train_loader_kwargs = dict(
        batch_size=int(cfg["train"]["batch_size"]),
        num_workers=int(cfg["train"]["num_workers"]),
        pin_memory=True,
        drop_last=True,
    )
    if phenomenon_weights:
        train_loader = torch.utils.data.DataLoader(
            train_ds,
            sampler=_phenomenon_sampler(train_ds, phenomenon_weights),
            **train_loader_kwargs,
        )
    else:
        train_loader = torch.utils.data.DataLoader(train_ds, shuffle=True, **train_loader_kwargs)
    val_loader = build_dataloader(
        data_root,
        split="test",
        batch_size=int(cfg["train"]["batch_size"]),
        num_workers=int(cfg["train"]["num_workers"]),
        input_lead=input_lead,
        signal_length=int(cfg["data"]["signal_length"]),
        phenomena=cfg["data"].get("phenomena"),
        labels=cfg["data"].get("labels"),
        shuffle=False,
        dedupe=cfg["data"].get("dedupe_test", False),
        delay_lags=delay_lags,
    )

    channel_weights: torch.Tensor | None = None
    low_channel_weights: torch.Tensor | None = None
    high_channel_weights: torch.Tensor | None = None
    if cfg["train"].get("m20_loss", False):
        high_channel_weights = m15a_channel_weights(
            input_lead,
            input_idx,
            hard_scale=float(cfg["train"].get("m20_hard_scale", 3.0)),
            far_scale=float(cfg["train"].get("m20_far_scale", 3.0)),
            mid_scale=float(cfg["train"].get("m20_mid_scale", 1.5)),
            near_scale=float(cfg["train"].get("m20_near_scale", 1.0)),
        )
        if not cfg["train"].get("m20_low_spatial_weights", False):
            low_channel_weights = None
        else:
            low_channel_weights = m15a_channel_weights(
                input_lead,
                input_idx,
                hard_scale=float(cfg["train"].get("m20_low_hard_scale", 1.5)),
                far_scale=float(cfg["train"].get("m20_low_far_scale", 1.5)),
                mid_scale=float(cfg["train"].get("m20_low_mid_scale", 1.0)),
                near_scale=float(cfg["train"].get("m20_low_near_scale", 1.0)),
            )
    elif cfg["train"].get("m15a_spatial_weights", False):
        channel_weights = m15a_channel_weights(
            input_lead,
            input_idx,
            hard_scale=float(cfg["train"].get("m15a_hard_scale", 3.0)),
            far_scale=float(cfg["train"].get("m15a_far_scale", 2.5)),
            mid_scale=float(cfg["train"].get("m15a_mid_scale", 1.5)),
            near_scale=float(cfg["train"].get("m15a_near_scale", 1.0)),
        )
    elif cfg["model"].get("hard_loss_weights", False):
        channel_weights = hard_focused_channel_weights(
            input_lead,
            input_idx,
            hard_scale=float(cfg["model"].get("hard_weight_scale", 3.0)),
        )
    elif cfg["model"].get("channel_loss_weights", False):
        channel_weights = non_input_channel_weights(
            input_lead,
            input_idx,
            scale=float(cfg["model"].get("weight_scale", 1.0)),
        )

    band_adv_weights: dict[str, float] | None = cfg["train"].get("adv_band_weights")

    generator, discriminator = build_model(
        cfg["model"],
        input_lead=input_lead,
        device=device,
        delay_center_index=skip_channel_idx,
    )
    generator = generator.to(device)

    progressive_stage = int(cfg["model"].get("progressive_stage", 0))
    use_wavelet_loss = bool(cfg["train"].get("wavelet_loss", False))
    use_polarity_loss = bool(cfg["train"].get("polarity_loss", False))
    use_m15a_loss = bool(cfg["train"].get("m15a_loss", False))
    use_hf_enhanced_gated_loss = bool(cfg["train"].get("hf_enhanced_gated_loss", False))
    use_gated_event_loss = bool(cfg["train"].get("gated_event_loss", False))
    use_dual_side_gated_loss = bool(cfg["train"].get("dual_side_gated_loss", False))
    lambda_high_deriv = float(cfg["train"].get("lambda_high_deriv", 4.0))
    lambda_baseline_hf = float(cfg["train"].get("lambda_baseline_hf", 6.0))
    baseline_gate_max = float(cfg["train"].get("baseline_gate_max", 3.0))
    lambda_gated = float(cfg["train"].get("lambda_gated", 8.0))
    gate_min = float(cfg["train"].get("gate_min", 1.0))
    gate_max = float(cfg["train"].get("gate_max", 4.0))
    gate_energy_kernel = int(cfg["train"].get("gate_energy_kernel", 31))
    use_event_loss = bool(cfg["train"].get("event_loss", False))
    use_morph_loss = bool(cfg["train"].get("morph_loss", False))
    use_m20_loss = bool(cfg["train"].get("m20_loss", False))
    m20_high_band_gain = float(cfg["train"].get("m20_high_band_gain", 1.0))
    lowpass: LowPassFilter1D | None = None
    morlet: MorletBank1D | None = None
    if (
        use_wavelet_loss
        or use_polarity_loss
        or use_m15a_loss
        or use_hf_enhanced_gated_loss
        or use_gated_event_loss
        or use_dual_side_gated_loss
        or use_m20_loss
        or use_event_loss
        or use_morph_loss
        or cfg["model"].get("discriminator_type")
        in (
            "wavelet_high",
            "spatio_temporal_2d",
            "graph_temporal",
            "multi_scale",
            "anatomy_aware_temporal",
        )
    ):
        lowpass = LowPassFilter1D(int(cfg["train"].get("wavelet_kernel", 31))).to(device)
    if progressive_stage == 2 or cfg["train"].get("progressive_high_gan", False):
        if hasattr(generator, "lowpass"):
            lowpass = generator.lowpass.to(device)
        elif lowpass is None:
            lowpass = LowPassFilter1D(int(cfg["train"].get("wavelet_kernel", 31))).to(device)
    if float(cfg["train"].get("lambda_sst", 0.0)) > 0:
        morlet = MorletBank1D(tuple(cfg["train"].get("sst_kernels", [7, 15, 31]))).to(device)
    pretrained_tcn = cfg["model"].get("pretrained_tcn")
    if pretrained_tcn:
        load_pretrained_tcn(generator, pretrained_tcn, device)

    init_ckpt = cfg["model"].get("init_from_checkpoint")
    if init_ckpt and not args.resume:
        init_strict = bool(cfg["model"].get("init_strict", True))
        skip_keys = cfg["model"].get("init_skip_key_substrings") or []
        load_pretrained_generator(
            generator,
            init_ckpt,
            device,
            strict=init_strict,
            skip_key_substrings=list(skip_keys),
        )

    freeze_tcn = bool(cfg["model"].get("freeze_tcn", False))
    if freeze_tcn and hasattr(generator, "tcn"):
        for param in generator.tcn.parameters():
            param.requires_grad = False
        logging.info("Frozen TCN backbone (train refine head only)")

    apply_config_freeze(generator, cfg.get("model", {}))

    if progressive_stage in (1, 2):
        freeze_progressive_modules(generator, progressive_stage)

    if discriminator:
        discriminator = discriminator.to(device)

    opt_g = build_generator_optimizer(generator, cfg)
    opt_d = None
    opt_gl = None
    if discriminator:
        opt_d = torch.optim.Adam(
            discriminator.parameters(),
            lr=float(cfg["train"]["lr_d"]),
            betas=(float(cfg["train"]["beta1"]), float(cfg["train"]["beta2"])),
        )
    if (
        discriminator is not None
        and cfg["model"].get("discriminator_type") == "ekgan_per_lead_unet"
        and hasattr(generator, "label_ae")
    ):
        opt_gl = torch.optim.Adam(
            generator.label_ae.parameters(),
            lr=float(cfg["train"].get("lr_gl", cfg["train"]["lr_g"])),
            betas=(float(cfg["train"]["beta1"]), float(cfg["train"]["beta2"])),
        )

    ckpt_dir = ensure_dir(cfg["train"]["checkpoint_dir"])
    log_dir = ensure_dir(cfg["train"]["log_dir"])
    writer = SummaryWriter(log_dir=str(log_dir))

    start_epoch = 1
    best_score = (
        float("-inf")
        if best_metric
        in ("non_input_pearson", "pearson_composite", "pearson_hard", "step1_composite", "step1_hf_composite")
        else float("inf")
    )
    epochs_no_improve = 0

    if args.resume:
        ckpt = torch.load(args.resume, map_location=device)
        generator.load_state_dict(ckpt["generator"])
        if discriminator and ckpt.get("discriminator"):
            discriminator.load_state_dict(ckpt["discriminator"])
        opt_g.load_state_dict(ckpt["opt_g"])
        if opt_d and ckpt.get("opt_d"):
            opt_d.load_state_dict(ckpt["opt_d"])
        start_epoch = int(ckpt["epoch"]) + 1
        best_score = float(ckpt.get("best_score", ckpt.get("best_mae", best_score)))

    epochs = int(cfg["train"]["epochs"])
    _M14_WAVELET_DISC = ("wavelet_high", "spatio_temporal_2d", "graph_temporal", "multi_scale")
    hf_gan_refine = (
        discriminator is not None
        and opt_d is not None
        and lowpass is not None
        and use_hf_enhanced_gated_loss
    )
    anatomy_gan_refine = (
        discriminator is not None
        and opt_d is not None
        and lowpass is not None
        and cfg["model"].get("discriminator_type") == "anatomy_aware_temporal"
    )
    ekgan_refine = (
        discriminator is not None
        and opt_d is not None
        and lowpass is not None
        and cfg["model"].get("discriminator_type") == "ekgan_per_lead_unet"
    )
    wavelet_gan = (
        discriminator is not None
        and cfg["model"].get("discriminator_type") in _M14_WAVELET_DISC
    )
    progressive_gan = (
        discriminator is not None
        and opt_d is not None
        and lowpass is not None
        and bool(cfg["train"].get("progressive_high_gan", False))
    )
    grad_clip_norm = cfg["train"].get("grad_clip_norm", 1.0)
    if grad_clip_norm is not None:
        grad_clip_norm = float(grad_clip_norm)

    for epoch in range(start_epoch, epochs + 1):
        if progressive_gan:
            train_log = train_one_epoch_progressive_gan(
                generator,
                discriminator,
                train_loader,
                opt_g,
                opt_d,
                device,
                lowpass,
                float(cfg["train"].get("lambda_l1", 100.0)),
                float(cfg["train"]["lambda_adv"]),
                float(cfg["train"].get("lambda_high_mse", 10.0)),
                input_idx,
                non_input_idx,
                input_skip,
                epoch,
                writer,
                int(cfg["train"]["log_every"]),
                channel_weights,
                band_adv_weights,
                n_critic,
                grad_clip_norm,
                skip_channel_idx,
            )
        elif ekgan_refine:
            from src.train_ekgan import train_one_epoch_m27_ekgan

            train_log = train_one_epoch_m27_ekgan(
                generator,
                discriminator,
                train_loader,
                opt_g,
                opt_d,
                opt_gl,
                device,
                lowpass,
                float(cfg["train"]["lambda_adv"]),
                float(cfg["train"].get("lambda_latent", 1.0)),
                float(cfg["train"].get("lambda_label_id", 10.0)),
                float(cfg["train"].get("lambda_low_l1", 100.0)),
                float(cfg["train"].get("lambda_low_pearson", 5.0)),
                float(cfg["train"].get("lambda_high_l1", 10.0)),
                float(cfg["train"].get("lambda_high_pearson", 8.0)),
                lambda_gated,
                float(cfg["train"].get("lambda_deriv", 2.0)),
                input_idx,
                non_input_idx,
                input_skip,
                epoch,
                writer,
                int(cfg["train"]["log_every"]),
                channel_weights,
                n_critic,
                grad_clip_norm,
                bool(cfg["train"].get("sign_robust_pearson", True)),
                gate_min,
                gate_max,
                gate_energy_kernel,
                int(cfg["train"].get("gan_warmup_epochs", 5)),
                skip_channel_idx,
            )
        elif hf_gan_refine:
            train_log = train_one_epoch_hf_gan(
                generator,
                discriminator,
                train_loader,
                opt_g,
                opt_d,
                device,
                lowpass,
                float(cfg["train"]["lambda_adv"]),
                float(cfg["train"].get("lambda_low_l1", 100.0)),
                float(cfg["train"].get("lambda_low_pearson", 5.0)),
                float(cfg["train"].get("lambda_high_l1", 30.0)),
                float(cfg["train"].get("lambda_high_pearson", 20.0)),
                lambda_gated,
                float(cfg["train"].get("lambda_deriv", 6.0)),
                lambda_high_deriv,
                lambda_baseline_hf,
                baseline_gate_max,
                input_idx,
                non_input_idx,
                input_skip,
                epoch,
                writer,
                int(cfg["train"]["log_every"]),
                channel_weights,
                band_adv_weights,
                n_critic,
                grad_clip_norm,
                bool(cfg["train"].get("sign_robust_pearson", True)),
                gate_min,
                gate_max,
                gate_energy_kernel,
                skip_channel_idx,
            )
        elif anatomy_gan_refine:
            train_log = train_one_epoch_m25_refine(
                generator,
                discriminator,
                train_loader,
                opt_g,
                opt_d,
                device,
                lowpass,
                float(cfg["train"]["lambda_adv"]),
                float(cfg["train"].get("lambda_low_l1", 100.0)),
                float(cfg["train"].get("lambda_low_pearson", 5.0)),
                float(cfg["train"].get("lambda_high_l1", 10.0)),
                float(cfg["train"].get("lambda_high_pearson", 8.0)),
                float(cfg["train"].get("lambda_deriv", 2.0)),
                input_idx,
                non_input_idx,
                input_skip,
                epoch,
                writer,
                int(cfg["train"]["log_every"]),
                channel_weights,
                n_critic,
                grad_clip_norm,
                bool(cfg["train"].get("sign_robust_pearson", True)),
                use_gated_event_loss,
                use_dual_side_gated_loss,
                lambda_gated,
                gate_min,
                gate_max,
                gate_energy_kernel,
                int(cfg["train"].get("gan_warmup_epochs", 0)),
                skip_channel_idx,
            )
        elif wavelet_gan and opt_d and lowpass is not None:
            train_log = train_one_epoch_wavelet_gan(
                generator,
                discriminator,
                train_loader,
                opt_g,
                opt_d,
                device,
                lowpass,
                float(cfg["train"].get("lambda_l1", 100.0)),
                float(cfg["train"]["lambda_adv"]),
                float(cfg["train"].get("lambda_low_l1", 100.0)),
                float(cfg["train"].get("lambda_low_pearson", 10.0)),
                float(cfg["train"].get("lambda_high_mse", 10.0)),
                input_idx,
                non_input_idx,
                input_skip,
                epoch,
                writer,
                int(cfg["train"]["log_every"]),
                channel_weights,
                n_critic,
                grad_clip_norm,
                use_polarity_loss,
                bool(cfg["train"].get("sign_robust_pearson", True)),
                float(cfg["train"].get("lambda_high_pearson", 8.0)),
                float(cfg["train"].get("lambda_deriv", 8.0)),
                int(cfg["train"].get("gan_warmup_epochs", 0)),
                band_adv_weights,
                skip_channel_idx,
            )
        elif discriminator is not None and opt_d is not None:
            train_log = train_one_epoch_gan(
                generator,
                discriminator,
                train_loader,
                opt_g,
                opt_d,
                device,
                float(cfg["train"].get("lambda_l1", 100.0)),
                float(cfg["train"]["lambda_adv"]),
                input_idx,
                non_input_idx,
                input_skip,
                epoch,
                writer,
                int(cfg["train"]["log_every"]),
                channel_weights,
                band_adv_weights,
                n_critic,
                grad_clip_norm,
                skip_channel_idx,
            )
        else:
            train_log = train_one_epoch_cnn(
                generator,
                train_loader,
                opt_g,
                device,
                input_idx,
                non_input_idx,
                input_skip,
                epoch,
                writer,
                int(cfg["train"]["log_every"]),
                channel_weights,
                float(cfg["train"].get("lambda_l1", 100.0)),
                float(cfg["train"].get("lambda_pearson", 0.0)),
                lowpass,
                float(cfg["train"].get("lambda_low_l1", 100.0)),
                float(cfg["train"].get("lambda_low_pearson", 10.0)),
                float(cfg["train"].get("lambda_high_mse", 10.0)),
                use_wavelet_loss,
                use_polarity_loss,
                use_m15a_loss,
                use_hf_enhanced_gated_loss,
                use_gated_event_loss,
                use_dual_side_gated_loss,
                lambda_gated,
                lambda_high_deriv,
                lambda_baseline_hf,
                baseline_gate_max,
                gate_min,
                gate_max,
                gate_energy_kernel,
                bool(cfg["train"].get("sign_robust_pearson", True)),
                float(cfg["train"].get("lambda_high_pearson", 5.0)),
                float(cfg["train"].get("lambda_high_l1", 10.0)),
                float(cfg["train"].get("lambda_deriv", 5.0)),
                grad_clip_norm,
                use_event_loss,
                float(cfg["train"].get("lambda_event", 5.0)),
                float(cfg["train"].get("lambda_sst", 0.0)),
                morlet,
                use_morph_loss,
                float(cfg["train"].get("lambda_morph_qrs", 8.0)),
                float(cfg["train"].get("lambda_morph_st", 5.0)),
                use_m20_loss,
                low_channel_weights,
                high_channel_weights,
                m20_high_band_gain,
                skip_channel_idx,
            )

        val_log = validate(
            generator,
            val_loader,
            device,
            input_idx,
            non_input_idx,
            input_skip,
            hard_idx,
            skip_channel_idx,
            lowpass,
        )
        monitor = _safe_monitor(val_log, best_metric, cfg)
        print(
            f"epoch {epoch} train_pearson_ni={train_log['pearson_non_input']:.4f} "
            f"val_pearson_ni={val_log['pearson_non_input']:.4f} "
            f"val_pearson_hard={val_log['pearson_hard']:.4f} "
            f"val_pearson_hp={val_log.get('pearson_highpass', 0.0):.4f} "
            f"val_mae_ni={val_log['mae_non_input']:.4f} "
            f"val_mae_hard={val_log['mae_hard']:.4f} val_mae_deriv={val_log['mae_deriv']:.4f} "
            f"monitor={monitor:.4f}"
        )

        if writer:
            writer.add_scalar("val/pearson_non_input", val_log["pearson_non_input"], epoch)
            writer.add_scalar("val/mae_non_input", val_log["mae_non_input"], epoch)
            writer.add_scalar("val/pearson_all", val_log["pearson_all"], epoch)

        save_checkpoint(
            ckpt_dir / "last.pt",
            epoch,
            generator,
            discriminator,
            opt_g,
            opt_d,
            best_score,
            cfg,
            best_metric,
        )

        if is_improved(monitor, best_score, best_metric):
            best_score = monitor
            epochs_no_improve = 0
            save_checkpoint(
                ckpt_dir / "best.pt",
                epoch,
                generator,
                discriminator,
                opt_g,
                opt_d,
                best_score,
                cfg,
                best_metric,
            )
            print(f"  saved best ({best_metric}={best_score:.6f})")
        else:
            epochs_no_improve += 1
            print(f"  no improvement ({epochs_no_improve}/{patience})")

        if save_every > 0 and epoch % save_every == 0:
            save_checkpoint(
                ckpt_dir / f"epoch_{epoch}.pt",
                epoch,
                generator,
                discriminator,
                opt_g,
                opt_d,
                best_score,
                cfg,
                best_metric,
            )

        if patience > 0 and epochs_no_improve >= patience:
            print(f"Early stopping at epoch {epoch} (patience={patience})")
            break

    _ensure_best_checkpoint(ckpt_dir)
    writer.close()


if __name__ == "__main__":
    main()
