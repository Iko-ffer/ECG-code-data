"""GAN + L1 losses for virtual lead reconstruction."""

from __future__ import annotations

import torch
import torch.nn as nn


def _lsgan_targets(pred: torch.Tensor, is_real: bool) -> torch.Tensor:
    return torch.ones_like(pred) if is_real else torch.zeros_like(pred)


def _weighted_l1(
    recon: torch.Tensor,
    target: torch.Tensor,
    channel_indices: list[int],
    channel_weights: torch.Tensor | None,
) -> torch.Tensor:
    pred = recon[:, channel_indices]
    tgt = target[:, channel_indices]
    err = (pred - tgt).abs()
    if channel_weights is None:
        return err.mean()
    w = channel_weights.to(recon.device).view(1, -1, 1)
    return (err * w).sum() / w.sum().clamp(min=1e-6) / err.size(0)


def _band_adv_loss(
    pred_fake: dict[str, torch.Tensor],
    band_weights: dict[str, float] | None,
) -> torch.Tensor:
    device = next(iter(pred_fake.values())).device
    if not pred_fake:
        return torch.tensor(0.0, device=device)
    total = torch.tensor(0.0, device=device)
    wsum = 0.0
    for band, pred in pred_fake.items():
        w = float(band_weights.get(band, 1.0)) if band_weights else 1.0
        total = total + w * nn.functional.mse_loss(pred, _lsgan_targets(pred, True))
        wsum += w
    return total / max(wsum, 1e-6)


def generator_loss(
    pred_fake: torch.Tensor | dict[str, torch.Tensor],
    target: torch.Tensor,
    recon: torch.Tensor,
    lambda_l1: float = 100.0,
    lambda_adv: float = 1.0,
    criterion_l1: nn.Module | None = None,
    l1_channel_indices: list[int] | None = None,
    channel_weights: torch.Tensor | None = None,
    band_adv_weights: dict[str, float] | None = None,
    sample_weight: torch.Tensor | None = None,
) -> tuple[torch.Tensor, dict[str, float]]:
    if isinstance(pred_fake, dict):
        loss_adv = _band_adv_loss(pred_fake, band_adv_weights)
    else:
        loss_adv = generator_adv_loss(pred_fake, band_adv_weights, sample_weight)

    if l1_channel_indices is None:
        if channel_weights is not None:
            raise ValueError("channel_weights requires l1_channel_indices")
        if criterion_l1 is None:
            criterion_l1 = nn.L1Loss()
        loss_l1 = criterion_l1(recon, target)
    else:
        loss_l1 = _weighted_l1(recon, target, l1_channel_indices, channel_weights)

    loss = lambda_adv * loss_adv + lambda_l1 * loss_l1
    return loss, {
        "g_adv": float(loss_adv.detach()),
        "g_l1": float(loss_l1.detach()),
        "g_total": float(loss.detach()),
    }


def _weighted_mse(pred: torch.Tensor, target: torch.Tensor, weight: torch.Tensor | None) -> torch.Tensor:
    err = (pred - target).pow(2)
    if weight is None:
        return err.mean()
    w = weight
    if w.shape[-1] != pred.shape[-1]:
        w = torch.nn.functional.interpolate(w, size=pred.shape[-1], mode="linear", align_corners=False)
    return (err * w).sum() / w.sum().clamp(min=1e-6)


def discriminator_loss(
    pred_real: torch.Tensor | dict[str, torch.Tensor],
    pred_fake: torch.Tensor | dict[str, torch.Tensor],
    band_adv_weights: dict[str, float] | None = None,
    sample_weight: torch.Tensor | None = None,
) -> tuple[torch.Tensor, dict[str, float]]:
    if isinstance(pred_real, dict):
        loss = torch.tensor(0.0, device=next(iter(pred_real.values())).device)
        wsum = 0.0
        for band in pred_real:
            lr = pred_real[band]
            lf = pred_fake[band]
            w = float(band_adv_weights.get(band, 1.0)) if band_adv_weights else 1.0
            loss_real = nn.functional.mse_loss(lr, _lsgan_targets(lr, True))
            loss_fake = nn.functional.mse_loss(lf, _lsgan_targets(lf, False))
            loss = loss + w * 0.5 * (loss_real + loss_fake)
            wsum += w
        loss = loss / max(wsum, 1e-6)
        return loss, {"d_total": float(loss.detach())}

    tgt_real = _lsgan_targets(pred_real, True)
    tgt_fake = _lsgan_targets(pred_fake, False)
    loss_real = _weighted_mse(pred_real, tgt_real, sample_weight)
    loss_fake = _weighted_mse(pred_fake, tgt_fake, sample_weight)
    loss = 0.5 * (loss_real + loss_fake)
    return loss, {
        "d_real": float(loss_real.detach()),
        "d_fake": float(loss_fake.detach()),
        "d_total": float(loss.detach()),
    }


def generator_adv_loss(
    pred_fake: torch.Tensor | dict[str, torch.Tensor],
    band_adv_weights: dict[str, float] | None = None,
    sample_weight: torch.Tensor | None = None,
) -> torch.Tensor:
    if isinstance(pred_fake, dict):
        loss = torch.tensor(0.0, device=next(iter(pred_fake.values())).device)
        wsum = 0.0
        for band, pred in pred_fake.items():
            w = float(band_adv_weights.get(band, 1.0)) if band_adv_weights else 1.0
            loss = loss + w * _weighted_mse(pred, _lsgan_targets(pred, True), sample_weight)
            wsum += w
        return loss / max(wsum, 1e-6)
    return _weighted_mse(pred_fake, _lsgan_targets(pred_fake, True), sample_weight)
