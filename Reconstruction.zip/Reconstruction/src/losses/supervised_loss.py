"""Supervised reconstruction losses (L1, Pearson)."""

from __future__ import annotations

import torch


def batch_pearson_cosines(
    pred: torch.Tensor,
    target: torch.Tensor,
    channel_indices: list[int],
    eps: float = 1e-6,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Per-element Pearson cosines and validity mask.
    Returns cos (B, C_sel), valid (B, C_sel).
    """
    p = pred[:, channel_indices]
    t = target[:, channel_indices]
    p = p - p.mean(dim=-1, keepdim=True)
    t = t - t.mean(dim=-1, keepdim=True)
    num = (p * t).sum(dim=-1)
    p_var = (p * p).sum(dim=-1)
    t_var = (t * t).sum(dim=-1)
    valid = (p_var > eps) & (t_var > eps)
    den = torch.sqrt(p_var * t_var).clamp(min=eps)
    cos = torch.where(valid, (num / den).clamp(-1.0, 1.0), torch.zeros_like(num))
    return cos, valid


def _aggregate_pearson(
    cos: torch.Tensor,
    valid: torch.Tensor,
    channel_weights: torch.Tensor | None,
) -> torch.Tensor:
    if not valid.any():
        return cos.sum() * 0.0
    if channel_weights is None:
        return cos.sum() / valid.float().sum().clamp(min=1.0)
    w = channel_weights.to(cos.device).view(1, -1)
    w_sum = (w * valid.float()).sum().clamp(min=1.0)
    return (cos * w).sum() / w_sum


def batch_pearson_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    channel_indices: list[int],
    channel_weights: torch.Tensor | None = None,
    eps: float = 1e-6,
) -> torch.Tensor:
    """
    Differentiable 1 - mean(Pearson) over batch and selected channels.
    pred/target: (B, C, L)
    """
    cos, valid = batch_pearson_cosines(pred, target, channel_indices, eps=eps)
    if not valid.any():
        return pred.sum() * 0.0 + 1.0
    pearson_mean = _aggregate_pearson(cos, valid, channel_weights)
    return 1.0 - pearson_mean


def batch_sign_robust_pearson_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    channel_indices: list[int],
    channel_weights: torch.Tensor | None = None,
    eps: float = 1e-6,
) -> torch.Tensor:
    """
    1 - mean(max(corr(pred, target), corr(-pred, target))).
    Allows each pair channel to flip polarity without a chest intermediate.
    """
    cos_pos, valid = batch_pearson_cosines(pred, target, channel_indices, eps=eps)
    cos_neg, _ = batch_pearson_cosines(-pred, target, channel_indices, eps=eps)
    if not valid.any():
        return pred.sum() * 0.0 + 1.0
    cos = torch.where(valid, torch.maximum(cos_pos, cos_neg), torch.zeros_like(cos_pos))
    pearson_mean = _aggregate_pearson(cos, valid, channel_weights)
    return 1.0 - pearson_mean


def supervised_reconstruction_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    channel_indices: list[int],
    channel_weights: torch.Tensor | None = None,
    lambda_l1: float = 100.0,
    lambda_pearson: float = 10.0,
) -> torch.Tensor:
    from src.losses.gan_loss import _weighted_l1

    loss_l1 = _weighted_l1(pred, target, channel_indices, channel_weights)
    loss_p = batch_pearson_loss(pred, target, channel_indices, channel_weights)
    return lambda_l1 * loss_l1 + lambda_pearson * loss_p
