from .gan_loss import discriminator_loss, generator_loss

__all__ = ["generator_loss", "discriminator_loss"]
