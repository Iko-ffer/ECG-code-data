"""Time-frequency style decoupling: low-pass envelope + high-frequency residual."""

from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.losses.supervised_loss import batch_pearson_loss, batch_sign_robust_pearson_loss


class LowPassFilter1D(nn.Module):
    """Fixed Gaussian low-pass (differentiable)."""

    def __init__(self, kernel_size: int = 31) -> None:
        super().__init__()
        if kernel_size % 2 == 0:
            kernel_size += 1
        sigma = kernel_size / 6.0
        t = torch.arange(kernel_size, dtype=torch.float32) - kernel_size // 2
        g = torch.exp(-0.5 * (t / sigma) ** 2)
        g = g / g.sum()
        self.kernel_size = kernel_size
        self.register_buffer("weight", g.view(1, 1, -1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, length = x.shape
        w = self.weight.expand(c, 1, self.kernel_size)
        pad = self.kernel_size // 2
        return F.conv1d(x, w, padding=pad, groups=c)


def decompose_low_high(x: torch.Tensor, lowpass: LowPassFilter1D) -> tuple[torch.Tensor, torch.Tensor]:
    low = lowpass(x)
    high = x - low
    return low, high


def wavelet_reconstruction_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    channel_indices: list[int],
    lowpass: LowPassFilter1D,
    lambda_low_l1: float = 100.0,
    lambda_low_pearson: float = 10.0,
    lambda_high_mse: float = 10.0,
    channel_weights: torch.Tensor | None = None,
) -> torch.Tensor:
    """
    Low band: L1 + (1 - Pearson); high band: MSE.
    pred/target: (B, C, L)
    """
    p = pred[:, channel_indices]
    t = target[:, channel_indices]
    p_low, p_high = decompose_low_high(p, lowpass)
    t_low, t_high = decompose_low_high(t, lowpass)

    from src.losses.gan_loss import _weighted_l1

    loss_low_l1 = _weighted_l1(p_low, t_low, list(range(p_low.shape[1])), channel_weights)
    loss_low_p = batch_pearson_loss(p_low, t_low, list(range(p_low.shape[1])), channel_weights)
    diff = p_high - t_high
    if channel_weights is not None:
        w = channel_weights.to(pred.device).view(1, -1, 1)
        loss_high = (diff.pow(2) * w).sum() / w.sum().clamp(min=1e-6) / diff.size(0)
    else:
        loss_high = diff.pow(2).mean()

    return (
        lambda_low_l1 * loss_low_l1
        + lambda_low_pearson * loss_low_p
        + lambda_high_mse * loss_high
    )


def high_pass_only(x: torch.Tensor, lowpass: LowPassFilter1D) -> torch.Tensor:
    return x - lowpass(x)


def _derivative_l1(
    pred: torch.Tensor,
    target: torch.Tensor,
    channel_weights: torch.Tensor | None,
) -> torch.Tensor:
    dp = pred[:, :, 1:] - pred[:, :, :-1]
    dt = target[:, :, 1:] - target[:, :, :-1]
    err = (dp - dt).abs()
    if channel_weights is None:
        return err.mean()
    w = channel_weights.to(pred.device).view(1, -1, 1)
    return (err * w).sum() / w.sum().clamp(min=1e-6) / err.size(0)


def wavelet_polarity_reconstruction_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    channel_indices: list[int],
    lowpass: LowPassFilter1D,
    lambda_low_l1: float = 100.0,
    lambda_low_pearson: float = 10.0,
    lambda_high_mse: float = 10.0,
    lambda_high_pearson: float = 5.0,
    lambda_deriv: float = 5.0,
    sign_robust_pearson: bool = True,
    channel_weights: torch.Tensor | None = None,
    sample_weights: torch.Tensor | None = None,
) -> torch.Tensor:
    """
    M14: wavelet decoupling + sign-robust Pearson + high-band morphology (deriv).
    Stays in 15-pair space; no chest intermediate.
    """
    p = pred[:, channel_indices]
    t = target[:, channel_indices]
    p_low, p_high = decompose_low_high(p, lowpass)
    t_low, t_high = decompose_low_high(t, lowpass)

    from src.losses.gan_loss import _weighted_l1

    pearson_fn = batch_sign_robust_pearson_loss if sign_robust_pearson else batch_pearson_loss

    loss_low_l1 = _weighted_l1(p_low, t_low, list(range(p_low.shape[1])), channel_weights)
    loss_low_p = pearson_fn(p_low, t_low, list(range(p_low.shape[1])), channel_weights)

    diff = p_high - t_high
    if channel_weights is not None:
        w = channel_weights.to(pred.device).view(1, -1, 1)
        loss_high = (diff.pow(2) * w).sum() / w.sum().clamp(min=1e-6) / diff.size(0)
    else:
        loss_high = diff.pow(2).mean()
    loss_high_p = pearson_fn(p_high, t_high, list(range(p_high.shape[1])), channel_weights)
    loss_deriv = _derivative_l1(p_high, t_high, channel_weights)

    loss = (
        lambda_low_l1 * loss_low_l1
        + lambda_low_pearson * loss_low_p
        + lambda_high_mse * loss_high
        + lambda_high_pearson * loss_high_p
        + lambda_deriv * loss_deriv
    )
    if sample_weights is not None:
        sw = sample_weights.to(pred.device).view(-1).mean().clamp(min=1e-6)
        loss = loss * sw
    return loss


def wavelet_m15a_reconstruction_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    channel_indices: list[int],
    lowpass: LowPassFilter1D,
    lambda_low_l1: float = 100.0,
    lambda_low_pearson: float = 5.0,
    lambda_high_l1: float = 10.0,
    lambda_high_pearson: float = 8.0,
    lambda_deriv: float = 0.0,
    sign_robust_pearson: bool = True,
    channel_weights: torch.Tensor | None = None,
) -> torch.Tensor:
    """
    M15a: low band L1 + Pearson; high band L1 + sign-robust Pearson (no MSE).
    Optional full-band derivative L1 (matches Step-1 mae_deriv).
    """
    p = pred[:, channel_indices]
    t = target[:, channel_indices]
    p_low, p_high = decompose_low_high(p, lowpass)
    t_low, t_high = decompose_low_high(t, lowpass)

    from src.losses.gan_loss import _weighted_l1

    pearson_fn = batch_sign_robust_pearson_loss if sign_robust_pearson else batch_pearson_loss

    loss_low_l1 = _weighted_l1(p_low, t_low, list(range(p_low.shape[1])), channel_weights)
    loss_low_p = pearson_fn(p_low, t_low, list(range(p_low.shape[1])), channel_weights)
    loss_high_l1 = _weighted_l1(p_high, t_high, list(range(p_high.shape[1])), channel_weights)
    loss_high_p = pearson_fn(p_high, t_high, list(range(p_high.shape[1])), channel_weights)

    loss = (
        lambda_low_l1 * loss_low_l1
        + lambda_low_pearson * loss_low_p
        + lambda_high_l1 * loss_high_l1
        + lambda_high_pearson * loss_high_p
    )
    if lambda_deriv > 0:
        loss = loss + lambda_deriv * _derivative_l1(p, t, channel_weights)
    return loss


def wavelet_m20_multiscale_spatial_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    channel_indices: list[int],
    lowpass: LowPassFilter1D,
    lambda_low_l1: float = 100.0,
    lambda_low_pearson: float = 5.0,
    lambda_high_l1: float = 10.0,
    lambda_high_pearson: float = 8.0,
    lambda_deriv: float = 0.0,
    sign_robust_pearson: bool = True,
    low_channel_weights: torch.Tensor | None = None,
    high_channel_weights: torch.Tensor | None = None,
    high_band_gain: float = 1.0,
) -> torch.Tensor:
    """
    M20: M15a wavelet decoupling with separate spatial weights on low vs high bands.
    Low band uses uniform (or mild) weights; high band uses M13ab/M15a spatial matrix
    (hard/far up-weighted) to press capacity toward difficult leads.
    """
    p = pred[:, channel_indices]
    t = target[:, channel_indices]
    p_low, p_high = decompose_low_high(p, lowpass)
    t_low, t_high = decompose_low_high(t, lowpass)

    from src.losses.gan_loss import _weighted_l1

    pearson_fn = batch_sign_robust_pearson_loss if sign_robust_pearson else batch_pearson_loss
    w_low = low_channel_weights
    w_high = high_channel_weights if high_channel_weights is not None else low_channel_weights

    loss_low_l1 = _weighted_l1(p_low, t_low, list(range(p_low.shape[1])), w_low)
    loss_low_p = pearson_fn(p_low, t_low, list(range(p_low.shape[1])), w_low)
    loss_high_l1 = _weighted_l1(p_high, t_high, list(range(p_high.shape[1])), w_high)
    loss_high_p = pearson_fn(p_high, t_high, list(range(p_high.shape[1])), w_high)

    hg = float(high_band_gain)
    loss = (
        lambda_low_l1 * loss_low_l1
        + lambda_low_pearson * loss_low_p
        + hg * lambda_high_l1 * loss_high_l1
        + hg * lambda_high_pearson * loss_high_p
    )
    if lambda_deriv > 0:
        loss = loss + lambda_deriv * _derivative_l1(p, t, w_high)
    return loss


class MorletBank1D(nn.Module):
    """Fixed multi-scale band-pass (SST-lite) for morphology emphasis."""

    def __init__(self, kernel_sizes: tuple[int, ...] = (7, 15, 31)) -> None:
        super().__init__()
        weights = []
        for k in kernel_sizes:
            if k % 2 == 0:
                k += 1
            t = torch.arange(k, dtype=torch.float32) - k // 2
            g = torch.exp(-0.5 * (t / (k / 6.0)) ** 2)
            w = g * torch.cos(2.0 * math.pi * t / max(k / 4.0, 1.0))
            w = w / (w.abs().sum() + 1e-8)
            weights.append(w.view(1, 1, -1))
        self.kernel_sizes = kernel_sizes
        for i, w in enumerate(weights):
            self.register_buffer(f"w{i}", w)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        outs = []
        for i, k in enumerate(self.kernel_sizes):
            if k % 2 == 0:
                k += 1
            pad = k // 2
            w = getattr(self, f"w{i}").expand(x.shape[1], 1, k)
            outs.append(F.conv1d(x, w, padding=pad, groups=x.shape[1]))
        return torch.stack(outs, dim=2).mean(dim=2)


def _event_mask_from_target(target: torch.Tensor, energy_kernel: int = 31, percentile: float = 0.85) -> torch.Tensor:
    """Differentiable-ish soft mask from target energy (B, C, L)."""
    dx = target[:, :, 1:] - target[:, :, :-1]
    dx = F.pad(dx, (0, 1), mode="replicate").abs()
    pad = energy_kernel // 2
    energy = F.avg_pool1d(dx, kernel_size=energy_kernel, stride=1, padding=pad)
    flat = energy.reshape(energy.shape[0], -1)
    thresh = torch.quantile(flat, percentile, dim=1, keepdim=True).unsqueeze(-1)
    return torch.sigmoid((energy - thresh) / (thresh.abs() + 1e-6))


def wavelet_event_reconstruction_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    channel_indices: list[int],
    lowpass: LowPassFilter1D,
    lambda_low_l1: float = 100.0,
    lambda_low_pearson: float = 5.0,
    lambda_high_l1: float = 10.0,
    lambda_high_pearson: float = 8.0,
    lambda_event: float = 5.0,
    lambda_deriv: float = 0.0,
    sign_robust_pearson: bool = True,
    channel_weights: torch.Tensor | None = None,
    morlet: MorletBank1D | None = None,
    lambda_sst: float = 0.0,
) -> torch.Tensor:
    """M15a base + event-region L1 up-weight + optional SST-lite band."""
    base = wavelet_m15a_reconstruction_loss(
        pred,
        target,
        channel_indices,
        lowpass,
        lambda_low_l1=lambda_low_l1,
        lambda_low_pearson=lambda_low_pearson,
        lambda_high_l1=lambda_high_l1,
        lambda_high_pearson=lambda_high_pearson,
        lambda_deriv=lambda_deriv,
        sign_robust_pearson=sign_robust_pearson,
        channel_weights=channel_weights,
    )
    if lambda_event <= 0:
        event_term = pred.new_tensor(0.0)
    else:
        p = pred[:, channel_indices]
        t = target[:, channel_indices]
        mask = _event_mask_from_target(t).detach()
        err = (p - t).abs()
        if channel_weights is not None:
            w = channel_weights.to(pred.device).view(1, -1, 1)
            event_term = (err * mask * w).sum() / (mask * w).sum().clamp(min=1e-6) / err.size(0)
        else:
            event_term = (err * mask).sum() / mask.sum().clamp(min=1e-6) / err.size(0)
    sst_term = pred.new_tensor(0.0)
    if lambda_sst > 0 and morlet is not None:
        p = pred[:, channel_indices]
        t = target[:, channel_indices]
        sst_term = F.l1_loss(morlet(p), morlet(t))
    return base + lambda_event * event_term + lambda_sst * sst_term


def morph_segment_reconstruction_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    x_input: torch.Tensor,
    channel_indices: list[int],
    lowpass: LowPassFilter1D,
    lambda_low_l1: float = 100.0,
    lambda_low_pearson: float = 5.0,
    lambda_high_l1: float = 10.0,
    lambda_high_pearson: float = 8.0,
    lambda_morph_qrs: float = 8.0,
    lambda_morph_st: float = 5.0,
    sign_robust_pearson: bool = True,
    channel_weights: torch.Tensor | None = None,
) -> torch.Tensor:
    """D1: M15a base + extra QRS/ST band L1 using input-lead event masks."""
    from src.ecg_masks import EcgEventMasker

    base = wavelet_m15a_reconstruction_loss(
        pred,
        target,
        channel_indices,
        lowpass,
        lambda_low_l1=lambda_low_l1,
        lambda_low_pearson=lambda_low_pearson,
        lambda_high_l1=lambda_high_l1,
        lambda_high_pearson=lambda_high_pearson,
        sign_robust_pearson=sign_robust_pearson,
        channel_weights=channel_weights,
    )
    if lambda_morph_qrs <= 0 and lambda_morph_st <= 0:
        return base
    masker = EcgEventMasker()
    m_qrs, m_st = masker(x_input)
    p = pred[:, channel_indices]
    t = target[:, channel_indices]
    err = (p - t).abs()
    if channel_weights is not None:
        w = channel_weights.to(pred.device).view(1, -1, 1)
        err = err * w
    qrs_term = (err * m_qrs).sum() / m_qrs.sum().clamp(min=1e-6) / err.size(0)
    st_term = (err * m_st).sum() / m_st.sum().clamp(min=1e-6) / err.size(0)
    return base + lambda_morph_qrs * qrs_term + lambda_morph_st * st_term


def dynamic_event_gate_from_input(
    x_input: torch.Tensor,
    energy_kernel: int = 31,
    gate_min: float = 1.0,
    gate_max: float = 4.0,
) -> torch.Tensor:
    """
    Input-lead soft event gate in [gate_min, gate_max] from |d/dt| energy.
    x_input: (B, 1, L) -> (B, 1, L), detached for stable weighting.
    """
    dx = x_input[:, :, 1:] - x_input[:, :, :-1]
    dx = F.pad(dx, (0, 1), mode="replicate").abs()
    pad = energy_kernel // 2
    energy = F.avg_pool1d(dx, kernel_size=energy_kernel, stride=1, padding=pad)
    flat = energy.reshape(energy.shape[0], -1)
    lo = flat.min(dim=1, keepdim=True).values.unsqueeze(-1)
    hi = flat.max(dim=1, keepdim=True).values.unsqueeze(-1)
    norm = (energy - lo) / (hi - lo).clamp(min=1e-6)
    return gate_min + (gate_max - gate_min) * norm


def dynamic_event_gate_dual_side(
    x_input: torch.Tensor,
    target: torch.Tensor,
    channel_indices: list[int],
    energy_kernel: int = 31,
    gate_min: float = 1.0,
    gate_max: float = 8.0,
) -> torch.Tensor:
    """
    Cross-gated event mask: input x target per-channel |d/dt| energy.
    Returns (B, len(channel_indices), L) in [gate_min, gate_max], detached.
    """
    def _energy(w: torch.Tensor) -> torch.Tensor:
        dx = w[:, :, 1:] - w[:, :, :-1]
        dx = F.pad(dx, (0, 1), mode="replicate").abs()
        pad = energy_kernel // 2
        return F.avg_pool1d(dx, kernel_size=energy_kernel, stride=1, padding=pad)

    e_in = _energy(x_input)
    e_tgt = _energy(target[:, channel_indices])
    cross = e_in * e_tgt
    flat = cross.reshape(cross.shape[0], -1)
    lo = flat.min(dim=1, keepdim=True).values.view(-1, 1, 1)
    hi = flat.max(dim=1, keepdim=True).values.view(-1, 1, 1)
    norm = (cross - lo) / (hi - lo).clamp(min=1e-6)
    return gate_min + (gate_max - gate_min) * norm


def wavelet_dual_side_gated_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    x_input: torch.Tensor,
    channel_indices: list[int],
    lowpass: LowPassFilter1D,
    lambda_low_l1: float = 100.0,
    lambda_low_pearson: float = 5.0,
    lambda_high_l1: float = 10.0,
    lambda_high_pearson: float = 8.0,
    lambda_gated: float = 16.0,
    lambda_deriv: float = 2.0,
    sign_robust_pearson: bool = True,
    channel_weights: torch.Tensor | None = None,
    gate_min: float = 1.0,
    gate_max: float = 8.0,
    energy_kernel: int = 31,
) -> torch.Tensor:
    """M25-Full P1: M15a base + input x target dual-side dynamic gate on L1."""
    base = wavelet_m15a_reconstruction_loss(
        pred,
        target,
        channel_indices,
        lowpass,
        lambda_low_l1=lambda_low_l1,
        lambda_low_pearson=lambda_low_pearson,
        lambda_high_l1=lambda_high_l1,
        lambda_high_pearson=lambda_high_pearson,
        lambda_deriv=lambda_deriv,
        sign_robust_pearson=sign_robust_pearson,
        channel_weights=channel_weights,
    )
    if lambda_gated <= 0:
        return base
    gate = dynamic_event_gate_dual_side(
        x_input,
        target,
        channel_indices,
        energy_kernel=energy_kernel,
        gate_min=gate_min,
        gate_max=gate_max,
    ).detach()
    p = pred[:, channel_indices]
    t = target[:, channel_indices]
    err = (p - t).abs()
    if channel_weights is not None:
        w = channel_weights.to(pred.device).view(1, -1, 1)
        err = err * w
        gate = gate * w
    gated = (err * gate).sum() / gate.sum().clamp(min=1e-6) / err.size(0)
    return base + lambda_gated * gated


def wavelet_multiscale_gated_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    x_input: torch.Tensor,
    channel_indices: list[int],
    lowpass: LowPassFilter1D,
    lambda_low_l1: float = 100.0,
    lambda_low_pearson: float = 5.0,
    lambda_high_l1: float = 10.0,
    lambda_high_pearson: float = 8.0,
    lambda_gated: float = 8.0,
    lambda_deriv: float = 2.0,
    sign_robust_pearson: bool = True,
    channel_weights: torch.Tensor | None = None,
    gate_min: float = 1.0,
    gate_max: float = 4.0,
    energy_kernel: int = 31,
) -> torch.Tensor:
    """M25-Opt3: M15a base + input-derivative dynamic gate on L1 (targets 1.91x event ratio)."""
    base = wavelet_m15a_reconstruction_loss(
        pred,
        target,
        channel_indices,
        lowpass,
        lambda_low_l1=lambda_low_l1,
        lambda_low_pearson=lambda_low_pearson,
        lambda_high_l1=lambda_high_l1,
        lambda_high_pearson=lambda_high_pearson,
        lambda_deriv=lambda_deriv,
        sign_robust_pearson=sign_robust_pearson,
        channel_weights=channel_weights,
    )
    if lambda_gated <= 0:
        return base
    gate = dynamic_event_gate_from_input(
        x_input, energy_kernel=energy_kernel, gate_min=gate_min, gate_max=gate_max
    ).detach()
    p = pred[:, channel_indices]
    t = target[:, channel_indices]
    err = (p - t).abs()
    g = gate.expand(-1, err.shape[1], -1)
    if channel_weights is not None:
        w = channel_weights.to(pred.device).view(1, -1, 1)
        err = err * w
        g = g * w
    gated = (err * g).sum() / g.sum().clamp(min=1e-6) / err.size(0)
    return base + lambda_gated * gated


def dynamic_baseline_hf_gate(
    x_input: torch.Tensor,
    energy_kernel: int = 31,
    gate_min: float = 1.0,
    gate_max: float = 3.0,
) -> torch.Tensor:
    """Inverse event gate: up-weight inter-beat / low-|d/dt| regions for HF texture."""
    event = dynamic_event_gate_from_input(
        x_input, energy_kernel=energy_kernel, gate_min=gate_min, gate_max=gate_max
    ).detach()
    inv = gate_min + gate_max - event
    return inv.clamp(min=gate_min)


def wavelet_hf_enhanced_gated_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    x_input: torch.Tensor,
    channel_indices: list[int],
    lowpass: LowPassFilter1D,
    lambda_low_l1: float = 100.0,
    lambda_low_pearson: float = 5.0,
    lambda_high_l1: float = 30.0,
    lambda_high_pearson: float = 20.0,
    lambda_gated: float = 10.0,
    lambda_deriv: float = 6.0,
    lambda_high_deriv: float = 4.0,
    lambda_baseline_hf: float = 6.0,
    sign_robust_pearson: bool = True,
    channel_weights: torch.Tensor | None = None,
    gate_min: float = 1.0,
    gate_max: float = 4.0,
    baseline_gate_max: float = 3.0,
    energy_kernel: int = 31,
) -> torch.Tensor:
    """
    M29 HF强化: M15a + event gate + high-band derivative + baseline HF gate.
    Targets fine inter-beat texture without dropping M25c event emphasis.
    """
    base = wavelet_m15a_reconstruction_loss(
        pred,
        target,
        channel_indices,
        lowpass,
        lambda_low_l1=lambda_low_l1,
        lambda_low_pearson=lambda_low_pearson,
        lambda_high_l1=lambda_high_l1,
        lambda_high_pearson=lambda_high_pearson,
        lambda_deriv=lambda_deriv,
        sign_robust_pearson=sign_robust_pearson,
        channel_weights=channel_weights,
    )
    p = pred[:, channel_indices]
    t = target[:, channel_indices]
    _, p_high = decompose_low_high(p, lowpass)
    _, t_high = decompose_low_high(t, lowpass)
    loss = base + lambda_high_deriv * _derivative_l1(p_high, t_high, channel_weights)

    gate = dynamic_event_gate_from_input(
        x_input, energy_kernel=energy_kernel, gate_min=gate_min, gate_max=gate_max
    ).detach()
    err = (p - t).abs()
    g = gate.expand(-1, err.shape[1], -1)
    if channel_weights is not None:
        w = channel_weights.to(pred.device).view(1, -1, 1)
        err = err * w
        g = g * w
    gated = (err * g).sum() / g.sum().clamp(min=1e-6) / err.size(0)
    loss = loss + lambda_gated * gated

    if lambda_baseline_hf > 0:
        b_gate = dynamic_baseline_hf_gate(
            x_input,
            energy_kernel=energy_kernel,
            gate_min=gate_min,
            gate_max=baseline_gate_max,
        )
        err_hp = (p_high - t_high).abs()
        bg = b_gate.expand(-1, err_hp.shape[1], -1)
        if channel_weights is not None:
            w = channel_weights.to(pred.device).view(1, -1, 1)
            err_hp = err_hp * w
            bg = bg * w
        baseline_hf = (err_hp * bg).sum() / bg.sum().clamp(min=1e-6) / err_hp.size(0)
        loss = loss + lambda_baseline_hf * baseline_hf
    return loss
