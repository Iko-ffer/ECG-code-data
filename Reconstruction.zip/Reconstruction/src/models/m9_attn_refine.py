"""M9-Attn: Attention U-Net refine replacing or paralleling M24 ODE delta."""

from __future__ import annotations

import torch
import torch.nn as nn

from src.constants import LEAD_PAIR_TO_INDEX, PHENOMENA
from src.models.attention_unet_refine import AttentionLeadRefinerUNet1D
from src.models.m24_performer_stgcn_ode import (
    PerformerMacroEncoder,
    STGCNLatentODEDecoder,
)
from src.models.m25_full_model import STGCNLatentODEDecoderFull
from src.models.tcn_unet_refine import _channel_residual_scales


PHENOMENON_TO_ID: dict[str, int] = {p: i for i, p in enumerate(PHENOMENA)}


class TCNAttnUNetRefine(nn.Module):
    """M9a-Attn: frozen TCN coarse + Attention U-Net residual (no ODE / Performer)."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        refine_base: int = 32,
        refine_depth: int = 3,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
    ) -> None:
        super().__init__()
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.refiner = AttentionLeadRefinerUNet1D(
            out_channels, out_channels, refine_base, refine_depth
        )
        scales = _channel_residual_scales(
            out_channels, input_lead, residual_scale, residual_scale_hard, residual_scale_rest
        )
        self.register_buffer("channel_scale", scales.view(1, out_channels, 1))
        self.input_idx = LEAD_PAIR_TO_INDEX[input_lead]

    def forward(self, x: torch.Tensor, phen_id: torch.Tensor | None = None) -> torch.Tensor:
        del phen_id
        y0 = self.tcn(x)
        return y0 + self.channel_scale * self.refiner(y0)


class TCNPerformerAttnUNetReplaceRefine(nn.Module):
    """M9-Attn replace: Performer encoder + Attention U-Net delta (ODE removed)."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
        num_phenomena: int = 5,
        film_embed_dim: int = 32,
        performer_dim: int = 128,
        performer_heads: int = 4,
        performer_layers: int = 4,
        performer_downsample: int = 4,
        refine_base: int = 32,
        refine_depth: int = 3,
    ) -> None:
        super().__init__()
        from src.models.film import PhenomenonEmbedding
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.encoder = PerformerMacroEncoder(
            n_leads=out_channels,
            dim=performer_dim,
            n_heads=performer_heads,
            n_layers=performer_layers,
            downsample=performer_downsample,
        )
        self.phen_embed = PhenomenonEmbedding(num_phenomena, film_embed_dim)
        self.film_embed_dim = film_embed_dim
        self.fuse = nn.Conv1d(out_channels + performer_dim, out_channels, kernel_size=1)
        self.refiner = AttentionLeadRefinerUNet1D(
            out_channels, out_channels, refine_base, refine_depth
        )
        scales = _channel_residual_scales(
            out_channels, input_lead, residual_scale, residual_scale_hard, residual_scale_rest
        )
        self.register_buffer("channel_scale", scales.view(1, out_channels, 1))
        self.input_idx = LEAD_PAIR_TO_INDEX[input_lead]

    def forward(self, x: torch.Tensor, phen_id: torch.Tensor | None = None) -> torch.Tensor:
        y0 = self.tcn(x)
        enc = self.encoder(y0)
        fused = self.fuse(torch.cat([y0, enc], dim=1))
        delta = self.refiner(fused)
        return y0 + self.channel_scale * delta


class TCNPerformerODEAttnParallelRefine(nn.Module):
    """M9-Attn parallel: M24 ODE delta + parallel Attention U-Net delta on fused features."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
        num_phenomena: int = 5,
        film_embed_dim: int = 32,
        performer_dim: int = 128,
        performer_heads: int = 4,
        performer_layers: int = 4,
        performer_downsample: int = 4,
        ode_latent_dim: int = 64,
        ode_steps: int = 4,
        ode_kernel: int = 7,
        refine_base: int = 32,
        refine_depth: int = 3,
        attn_residual_scale: float | None = None,
    ) -> None:
        super().__init__()
        from src.models.film import PhenomenonEmbedding
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.encoder = PerformerMacroEncoder(
            n_leads=out_channels,
            dim=performer_dim,
            n_heads=performer_heads,
            n_layers=performer_layers,
            downsample=performer_downsample,
        )
        self.phen_embed = PhenomenonEmbedding(num_phenomena, film_embed_dim)
        self.film_embed_dim = film_embed_dim
        self.ode_decoder = STGCNLatentODEDecoder(
            n_leads=out_channels,
            enc_dim=performer_dim,
            latent_dim=ode_latent_dim,
            cond_dim=film_embed_dim,
            n_steps=ode_steps,
            ode_kernel=ode_kernel,
        )
        self.fuse = nn.Conv1d(out_channels + performer_dim, out_channels, kernel_size=1)
        self.attn_refiner = AttentionLeadRefinerUNet1D(
            out_channels, out_channels, refine_base, refine_depth
        )
        ode_scales = _channel_residual_scales(
            out_channels, input_lead, residual_scale, residual_scale_hard, residual_scale_rest
        )
        attn_scale = float(attn_residual_scale if attn_residual_scale is not None else residual_scale)
        attn_scales = _channel_residual_scales(
            out_channels, input_lead, attn_scale, residual_scale_hard, residual_scale_rest
        )
        self.register_buffer("ode_channel_scale", ode_scales.view(1, out_channels, 1))
        self.register_buffer("attn_channel_scale", attn_scales.view(1, out_channels, 1))
        self.input_idx = LEAD_PAIR_TO_INDEX[input_lead]

    def forward(self, x: torch.Tensor, phen_id: torch.Tensor | None = None) -> torch.Tensor:
        y0 = self.tcn(x)
        enc = self.encoder(y0)
        if phen_id is None:
            cond = torch.zeros(x.shape[0], self.film_embed_dim, device=x.device)
        else:
            cond = self.phen_embed(phen_id)
        delta_ode = self.ode_decoder(enc, y0, cond)
        fused = self.fuse(torch.cat([y0, enc], dim=1))
        delta_attn = self.attn_refiner(fused)
        return (
            y0
            + self.ode_channel_scale * delta_ode
            + self.attn_channel_scale * delta_attn
        )


class TCNPerformerODEAttnParallelFullRefine(TCNPerformerODEAttnParallelRefine):
    """
    M29: M9c parallel (ODE + Attn-UNet) with M26 in-flow anatomical cross-attn ODE decoder.
    zero_init_gate keeps init behaviour near M9c; cross-attn trains via asymmetric LR.
    """

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
        num_phenomena: int = 5,
        film_embed_dim: int = 32,
        performer_dim: int = 128,
        performer_heads: int = 4,
        performer_layers: int = 4,
        performer_downsample: int = 4,
        ode_latent_dim: int = 64,
        ode_steps: int = 4,
        ode_kernel: int = 7,
        refine_base: int = 32,
        refine_depth: int = 3,
        attn_residual_scale: float | None = None,
        cross_attn_heads: int = 4,
        cross_attn_scale: float = 0.1,
        zero_init_gate: bool = True,
    ) -> None:
        super().__init__(
            in_channels=in_channels,
            out_channels=out_channels,
            base_channels=base_channels,
            depth=depth,
            residual_scale=residual_scale,
            residual_scale_hard=residual_scale_hard,
            residual_scale_rest=residual_scale_rest,
            input_lead=input_lead,
            num_phenomena=num_phenomena,
            film_embed_dim=film_embed_dim,
            performer_dim=performer_dim,
            performer_heads=performer_heads,
            performer_layers=performer_layers,
            performer_downsample=performer_downsample,
            ode_latent_dim=ode_latent_dim,
            ode_steps=ode_steps,
            ode_kernel=ode_kernel,
            refine_base=refine_base,
            refine_depth=refine_depth,
            attn_residual_scale=attn_residual_scale,
        )
        self.ode_decoder = STGCNLatentODEDecoderFull(
            n_leads=out_channels,
            enc_dim=performer_dim,
            latent_dim=ode_latent_dim,
            cond_dim=film_embed_dim,
            n_steps=ode_steps,
            ode_kernel=ode_kernel,
            cross_attn_heads=cross_attn_heads,
            input_lead=input_lead,
            cross_attn_scale=cross_attn_scale,
            zero_init_gate=zero_init_gate,
        )


class UNetPerformerODEAttnParallelFullRefine(TCNPerformerODEAttnParallelFullRefine):
    """M30b: U-Net coarse generator + M29-Full parallel refine (TCN replaced)."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
        num_phenomena: int = 5,
        film_embed_dim: int = 32,
        performer_dim: int = 128,
        performer_heads: int = 4,
        performer_layers: int = 4,
        performer_downsample: int = 4,
        ode_latent_dim: int = 64,
        ode_steps: int = 4,
        ode_kernel: int = 7,
        refine_base: int = 32,
        refine_depth: int = 3,
        attn_residual_scale: float | None = None,
        cross_attn_heads: int = 4,
        cross_attn_scale: float = 0.1,
        zero_init_gate: bool = True,
    ) -> None:
        super().__init__(
            in_channels=in_channels,
            out_channels=out_channels,
            base_channels=base_channels,
            depth=depth,
            residual_scale=residual_scale,
            residual_scale_hard=residual_scale_hard,
            residual_scale_rest=residual_scale_rest,
            input_lead=input_lead,
            num_phenomena=num_phenomena,
            film_embed_dim=film_embed_dim,
            performer_dim=performer_dim,
            performer_heads=performer_heads,
            performer_layers=performer_layers,
            performer_downsample=performer_downsample,
            ode_latent_dim=ode_latent_dim,
            ode_steps=ode_steps,
            ode_kernel=ode_kernel,
            refine_base=refine_base,
            refine_depth=refine_depth,
            attn_residual_scale=attn_residual_scale,
            cross_attn_heads=cross_attn_heads,
            cross_attn_scale=cross_attn_scale,
            zero_init_gate=zero_init_gate,
        )
        from src.models.unet_1d import GeneratorUNet1D

        self.tcn = GeneratorUNet1D(in_channels, out_channels, base_channels, depth)
