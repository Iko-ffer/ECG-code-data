"""1D PatchGAN discriminator."""

from __future__ import annotations

import torch
import torch.nn as nn


class PatchDiscriminator1D(nn.Module):
    """Classifies local temporal patches as real/fake (LSGAN targets)."""

    def __init__(self, in_channels: int = 16, base_channels: int = 64) -> None:
        super().__init__()
        # Input: concat(input_lead, target_or_fake) -> 1 + 15 = 16 channels
        layers: list[nn.Module] = []
        ch = base_channels
        in_ch = in_channels
        for i in range(4):
            out_ch = min(ch * (2**i), 512)
            layers += [
                nn.Conv1d(in_ch, out_ch, kernel_size=4, stride=2, padding=1, bias=False),
                nn.BatchNorm1d(out_ch),
                nn.LeakyReLU(0.2, inplace=True),
            ]
            in_ch = out_ch
        layers.append(nn.Conv1d(in_ch, 1, kernel_size=4, stride=1, padding=1))
        self.net = nn.Sequential(*layers)

    def forward(self, x_cond: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """
        x_cond: (B, 1, L) input lead
        y:      (B, 15, L) real or generated targets
        """
        x = torch.cat([x_cond, y], dim=1)
        return self.net(x)
