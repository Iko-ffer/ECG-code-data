"""Spatially banded PatchGAN: near / mid / far lead groups."""

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from src.constants import VIRTUAL_LEAD_PAIRS
from src.lead_space import band_channel_indices, hard_band_channel_indices
from src.models.patchgan import PatchDiscriminator1D


class SpatialBandedPatchDiscriminator(nn.Module):
    """
    Three discriminators over lead-distance bands (near, mid, far).
    Each sees concat(input, subset of 15 target channels).
    """

    def __init__(
        self,
        input_lead: str,
        in_input_channels: int = 1,
        base_channels: int = 64,
    ) -> None:
        super().__init__()
        self.bands = band_channel_indices(input_lead)
        self.discriminators = nn.ModuleDict()
        for band, idx in self.bands.items():
            if not idx:
                continue
            in_ch = in_input_channels + len(idx)
            self.discriminators[band] = PatchDiscriminator1D(
                in_channels=in_ch,
                base_channels=base_channels,
            )

    def forward(self, x_cond: torch.Tensor, y: torch.Tensor) -> dict[str, torch.Tensor]:
        out: dict[str, torch.Tensor] = {}
        for band, idx in self.bands.items():
            if band not in self.discriminators:
                continue
            y_band = y[:, idx]
            out[band] = self.discriminators[band](x_cond, y_band)
        return out

    @property
    def band_indices(self) -> dict[str, list[int]]:
        return self.bands


class HardBandedPatchDiscriminator(nn.Module):
    """
    Task-oriented PatchGAN: hard lead pairs vs the rest (M5b / M9b).
    """

    def __init__(
        self,
        input_lead: str,
        in_input_channels: int = 1,
        base_channels: int = 64,
    ) -> None:
        super().__init__()
        self.bands = hard_band_channel_indices(input_lead)
        self.discriminators = nn.ModuleDict()
        for band, idx in self.bands.items():
            if not idx:
                continue
            in_ch = in_input_channels + len(idx)
            self.discriminators[band] = PatchDiscriminator1D(
                in_channels=in_ch,
                base_channels=base_channels,
            )

    def forward(self, x_cond: torch.Tensor, y: torch.Tensor) -> dict[str, torch.Tensor]:
        out: dict[str, torch.Tensor] = {}
        for band, idx in self.bands.items():
            if band not in self.discriminators:
                continue
            out[band] = self.discriminators[band](x_cond, y[:, idx])
        return out

    @property
    def band_indices(self) -> dict[str, list[int]]:
        return self.bands


class PerHardLeadPatchDiscriminator(nn.Module):
    """One PatchGAN per hard lead pair (M9b-v3)."""

    def __init__(
        self,
        input_lead: str,
        in_input_channels: int = 1,
        base_channels: int = 32,
    ) -> None:
        super().__init__()
        bands = hard_band_channel_indices(input_lead)
        self.lead_indices: dict[str, int] = {}
        self.discriminators = nn.ModuleDict()
        for idx in bands.get("hard", []):
            lead = VIRTUAL_LEAD_PAIRS[idx]
            key = lead.replace("-", "_")
            self.lead_indices[key] = idx
            self.discriminators[key] = PatchDiscriminator1D(
                in_channels=in_input_channels + 1,
                base_channels=base_channels,
            )

    def forward(self, x_cond: torch.Tensor, y: torch.Tensor) -> dict[str, torch.Tensor]:
        out: dict[str, torch.Tensor] = {}
        for key, idx in self.lead_indices.items():
            out[key] = self.discriminators[key](x_cond, y[:, idx : idx + 1])
        return out

    @property
    def band_indices(self) -> dict[str, list[int]]:
        return {k: [v] for k, v in self.lead_indices.items()}


def is_banded_discriminator(d: Any) -> bool:
    from src.models.ecg_discriminators import is_banded_ecg_discriminator

    return isinstance(
        d,
        (SpatialBandedPatchDiscriminator, HardBandedPatchDiscriminator, PerHardLeadPatchDiscriminator),
    ) or is_banded_ecg_discriminator(d)


def is_spatial_discriminator(d: Any) -> bool:
    return isinstance(d, SpatialBandedPatchDiscriminator)
