"""Two-stage decoder: predict 6 chest leads, then analytic 15 pairwise diffs."""

from __future__ import annotations

import torch.nn as nn

from src.lead_space import diffs_from_chest
from src.models.unet_1d import GeneratorUNet1D


class ChestTwoStageDecoder(nn.Module):
    """
    Stage 1: U-Net maps input virtual pair -> 6 chest leads (V1..V6).
    Stage 2: analytic pairwise differences -> 15 virtual lead channels.
    """

    def __init__(
        self,
        in_channels: int = 1,
        base_channels: int = 64,
        depth: int = 4,
        backbone: str = "unet",
    ) -> None:
        super().__init__()
        if backbone != "unet":
            raise ValueError(f"Unsupported chest backbone: {backbone}")
        self.chest_net = GeneratorUNet1D(
            in_channels=in_channels,
            out_channels=6,
            base_channels=base_channels,
            depth=depth,
        )

    def forward(self, x):
        chest = self.chest_net(x)
        return diffs_from_chest(chest)
