"""Feature-wise Linear Modulation (FiLM) for phenomenon / lead conditioning."""

from __future__ import annotations

import torch
import torch.nn as nn


class PhenomenonEmbedding(nn.Module):
    """Map phenomenon id (0..K-1) to a global conditioning vector."""

    def __init__(self, num_phenomena: int = 5, embed_dim: int = 32) -> None:
        super().__init__()
        self.table = nn.Embedding(num_phenomena, embed_dim)
        self.proj = nn.Sequential(
            nn.Linear(embed_dim, embed_dim),
            nn.SiLU(),
            nn.Linear(embed_dim, embed_dim),
        )

    def forward(self, phen_id: torch.Tensor) -> torch.Tensor:
        """phen_id: (B,) long -> (B, embed_dim)."""
        return self.proj(self.table(phen_id))


class FiLM1d(nn.Module):
    """Apply per-channel gamma/beta to (B, C, L) from cond (B, cond_dim)."""

    def __init__(self, cond_dim: int, num_channels: int) -> None:
        super().__init__()
        self.to_gamma = nn.Linear(cond_dim, num_channels)
        self.to_beta = nn.Linear(cond_dim, num_channels)
        nn.init.zeros_(self.to_gamma.weight)
        nn.init.ones_(self.to_gamma.bias)
        nn.init.zeros_(self.to_beta.weight)
        nn.init.zeros_(self.to_beta.bias)

    def forward(self, h: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        gamma = self.to_gamma(cond).unsqueeze(-1)
        beta = self.to_beta(cond).unsqueeze(-1)
        return gamma * h + beta
