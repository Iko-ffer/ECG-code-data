"""M21: Beat-weak latent ODE refiner with per-channel soft phase and phenomenon FiLM."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.constants import LEAD_PAIR_TO_INDEX, PHENOMENA
from src.models.film import PhenomenonEmbedding
from src.models.tcn_unet_refine import _channel_residual_scales


PHENOMENON_TO_ID: dict[str, int] = {p: i for i, p in enumerate(PHENOMENA)}


def soft_per_channel_phase(y: torch.Tensor, energy_kernel: int = 31) -> torch.Tensor:
    """
    Differentiable soft phase field from per-channel energy (no input-lead QRS).
    y: (B, C, L) -> (B, 1, L) shared phase proxy averaged over channels.
    """
    dx = y[:, :, 1:] - y[:, :, :-1]
    dx = F.pad(dx, (0, 1), mode="replicate").abs()
    pad = energy_kernel // 2
    energy = F.avg_pool1d(dx, kernel_size=energy_kernel, stride=1, padding=pad)
    phase = energy.cumsum(dim=-1)
    phase = phase / phase[:, :, -1:].clamp(min=1e-6)
    return phase.mean(dim=1, keepdim=True)


class ODEFunc1d(nn.Module):
    """Shared dynamics f(h, tau, cond) for latent ODE integration."""

    def __init__(self, dim: int, cond_dim: int, hidden: int = 128) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(dim + cond_dim + 1, hidden, kernel_size=3, padding=1),
            nn.SiLU(),
            nn.Conv1d(hidden, hidden, kernel_size=3, padding=1),
            nn.SiLU(),
            nn.Conv1d(hidden, dim, kernel_size=1),
        )
        nn.init.zeros_(self.net[-1].weight)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, h: torch.Tensor, tau: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        b, _, length = h.shape
        cond_exp = cond.unsqueeze(-1).expand(b, cond.shape[1], length)
        tau_exp = tau.expand(b, 1, length)
        return self.net(torch.cat([h, cond_exp, tau_exp], dim=1))


class LatentODEBeatRefiner(nn.Module):
    """
    Encode coarse y0, integrate latent ODE over soft phase tau, per-channel decode.
    """

    def __init__(
        self,
        n_leads: int = 15,
        latent_dim: int = 64,
        cond_dim: int = 32,
        n_steps: int = 4,
        energy_kernel: int = 31,
    ) -> None:
        super().__init__()
        self.n_steps = n_steps
        self.encoder = nn.Conv1d(n_leads, latent_dim, kernel_size=7, padding=3)
        self.ode_func = ODEFunc1d(latent_dim, cond_dim)
        self.channel_heads = nn.ModuleList(
            [nn.Conv1d(latent_dim, 1, kernel_size=7, padding=3) for _ in range(n_leads)]
        )
        for head in self.channel_heads:
            nn.init.zeros_(head.weight)
            nn.init.zeros_(head.bias)
        self.energy_kernel = energy_kernel

    def forward(self, y0: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        tau = soft_per_channel_phase(y0, self.energy_kernel)
        h = self.encoder(y0)
        dt = 1.0 / float(self.n_steps)
        for step in range(self.n_steps):
            t_scalar = (step + 0.5) * dt
            t_field = torch.full_like(tau, t_scalar)
            dh = self.ode_func(h, t_field + tau, cond)
            h = h + dt * dh
        deltas = [head(h) for head in self.channel_heads]
        return torch.cat(deltas, dim=1)


class TCNLatentODERefine(nn.Module):
    """M21: frozen TCN coarse + beat-weak latent ODE refiner with phenomenon embedding."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
        num_phenomena: int = 5,
        film_embed_dim: int = 32,
        ode_latent_dim: int = 64,
        ode_steps: int = 4,
    ) -> None:
        super().__init__()
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.phen_embed = PhenomenonEmbedding(num_phenomena, film_embed_dim)
        self.film_embed_dim = film_embed_dim
        self.refiner = LatentODEBeatRefiner(
            n_leads=out_channels,
            latent_dim=ode_latent_dim,
            cond_dim=film_embed_dim,
            n_steps=ode_steps,
        )
        scales = _channel_residual_scales(
            out_channels, input_lead, residual_scale, residual_scale_hard, residual_scale_rest
        )
        self.register_buffer("channel_scale", scales.view(1, out_channels, 1))
        self.input_idx = LEAD_PAIR_TO_INDEX[input_lead]

    def forward(self, x: torch.Tensor, phen_id: torch.Tensor | None = None) -> torch.Tensor:
        y0 = self.tcn(x)
        if phen_id is None:
            cond = torch.zeros(x.shape[0], self.film_embed_dim, device=x.device)
        else:
            cond = self.phen_embed(phen_id)
        delta = self.refiner(y0, cond)
        return y0 + self.channel_scale * delta
