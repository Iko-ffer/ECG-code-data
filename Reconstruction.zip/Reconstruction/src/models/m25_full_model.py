"""M25-Full: decoder-side anatomical cross-attn inside ODE dynamics + M24 backbone."""

from __future__ import annotations

import torch
import torch.nn as nn

from src.constants import LEAD_PAIR_TO_INDEX
from src.models.film import PhenomenonEmbedding
from src.models.m24_performer_stgcn_ode import (
    PHENOMENON_TO_ID,
    PerformerMacroEncoder,
    STGCNODEDynamics,
    soft_per_channel_phase,
)
from src.models.spatial_coord import AnatomicalSpatialEmbedding
from src.models.tcn_unet_refine import _channel_residual_scales


class M25FullAnatomicalCrossAttn(nn.Module):
    """
    Target-conditioned modulation inside ODE flow.
    Query: per-lead latent h_ode + spatial embedding at each timestep.
    Key/Value: Performer encoder context at the same timestep (no encoder bridge cut).
    """

    def __init__(
        self,
        hidden_dim: int = 64,
        enc_dim: int = 128,
        n_leads: int = 15,
        n_heads: int = 4,
        input_lead: str = "V2-V5",
        residual_scale: float = 0.1,
        zero_init_gate: bool = False,
    ) -> None:
        super().__init__()
        self.n_leads = n_leads
        self.residual_scale = residual_scale
        self.zero_init_gate = zero_init_gate
        self.spatial_emb = AnatomicalSpatialEmbedding(n_leads, hidden_dim, input_lead)
        self.enc_proj = nn.Conv1d(enc_dim, hidden_dim, kernel_size=1, bias=False)
        self.attn = nn.MultiheadAttention(hidden_dim, n_heads, batch_first=True)
        self.out_proj = nn.Linear(hidden_dim, hidden_dim)
        nn.init.zeros_(self.out_proj.weight)
        nn.init.zeros_(self.out_proj.bias)
        if zero_init_gate:
            self.residual_gate = nn.Parameter(torch.zeros(1))

    def forward(self, h_ode: torch.Tensor, enc: torch.Tensor) -> torch.Tensor:
        b, n_leads, dim, length = h_ode.shape
        enc_kv = self.enc_proj(enc).permute(0, 2, 1)
        spatial = self.spatial_emb().unsqueeze(0)
        q = h_ode.permute(0, 3, 1, 2).reshape(b * length, n_leads, dim)
        q = q + spatial.expand(b * length, -1, -1)
        kv = enc_kv.reshape(b * length, 1, dim)
        attn_out, _ = self.attn(q, kv, kv)
        mod = self.out_proj(attn_out).view(b, length, n_leads, dim).permute(0, 2, 3, 1)
        if self.zero_init_gate:
            return self.residual_gate * mod
        return self.residual_scale * mod


class STGCNODEDynamicsWithCrossAttn(nn.Module):
    """ST-GCN dh/dt + optional decoder-side anatomical cross-attention modulation."""

    def __init__(
        self,
        dim: int,
        enc_dim: int,
        n_leads: int = 15,
        kernel: int = 7,
        cross_attn_heads: int = 4,
        input_lead: str = "V2-V5",
        cross_attn_scale: float = 0.1,
        zero_init_gate: bool = False,
    ) -> None:
        super().__init__()
        self.base = STGCNODEDynamics(dim, n_leads, kernel=kernel)
        self.cross_attn = M25FullAnatomicalCrossAttn(
            hidden_dim=dim,
            enc_dim=enc_dim,
            n_leads=n_leads,
            n_heads=cross_attn_heads,
            input_lead=input_lead,
            residual_scale=cross_attn_scale,
            zero_init_gate=zero_init_gate,
        )

    def forward(self, h: torch.Tensor, enc: torch.Tensor) -> torch.Tensor:
        return self.base(h) + self.cross_attn(h, enc)


class STGCNLatentODEDecoderFull(nn.Module):
    """M25-Full decoder: ODE steps receive Performer enc for in-flow cross-attention."""

    def __init__(
        self,
        n_leads: int = 15,
        enc_dim: int = 128,
        latent_dim: int = 64,
        cond_dim: int = 32,
        n_steps: int = 4,
        energy_kernel: int = 31,
        ode_kernel: int = 7,
        cross_attn_heads: int = 4,
        input_lead: str = "V2-V5",
        cross_attn_scale: float = 0.1,
        zero_init_gate: bool = False,
    ) -> None:
        super().__init__()
        self.n_leads = n_leads
        self.n_steps = n_steps
        self.energy_kernel = energy_kernel
        self.lead_embed = nn.Conv1d(1, latent_dim, kernel_size=7, padding=3)
        self.ctx_fuse = nn.Conv1d(enc_dim + cond_dim + 1, latent_dim, kernel_size=1)
        self.ode_func = STGCNODEDynamicsWithCrossAttn(
            dim=latent_dim,
            enc_dim=enc_dim,
            n_leads=n_leads,
            kernel=ode_kernel,
            cross_attn_heads=cross_attn_heads,
            input_lead=input_lead,
            cross_attn_scale=cross_attn_scale,
            zero_init_gate=zero_init_gate,
        )
        self.decode = nn.Conv1d(latent_dim, 1, kernel_size=7, padding=3)
        nn.init.zeros_(self.decode.weight)
        nn.init.zeros_(self.decode.bias)

    def forward(self, enc: torch.Tensor, y0: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        b, _, length = y0.shape
        tau = soft_per_channel_phase(y0, self.energy_kernel)
        cond_exp = cond.unsqueeze(-1).expand(b, cond.shape[1], length)
        ctx = self.ctx_fuse(torch.cat([enc, cond_exp, tau.expand(b, 1, length)], dim=1))
        h = self.lead_embed(y0.reshape(b * self.n_leads, 1, length))
        h = h.reshape(b, self.n_leads, -1, length) + ctx.unsqueeze(1)
        dt = 1.0 / float(self.n_steps)
        for _ in range(self.n_steps):
            h = h + dt * self.ode_func(h, enc)
        delta = self.decode(h.reshape(b * self.n_leads, h.shape[2], length))
        return delta.reshape(b, self.n_leads, length)


class TCNPerformerM25FullRefine(nn.Module):
    """M25-Full: M24 Performer encoder (unmodified path) + ODE decoder with in-flow cross-attn."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
        num_phenomena: int = 5,
        film_embed_dim: int = 32,
        performer_dim: int = 128,
        performer_heads: int = 4,
        performer_layers: int = 4,
        performer_downsample: int = 4,
        ode_latent_dim: int = 64,
        ode_steps: int = 4,
        ode_kernel: int = 7,
        cross_attn_heads: int = 4,
        cross_attn_scale: float = 0.1,
        zero_init_gate: bool = False,
    ) -> None:
        super().__init__()
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.encoder = PerformerMacroEncoder(
            n_leads=out_channels,
            dim=performer_dim,
            n_heads=performer_heads,
            n_layers=performer_layers,
            downsample=performer_downsample,
        )
        self.phen_embed = PhenomenonEmbedding(num_phenomena, film_embed_dim)
        self.film_embed_dim = film_embed_dim
        self.decoder = STGCNLatentODEDecoderFull(
            n_leads=out_channels,
            enc_dim=performer_dim,
            latent_dim=ode_latent_dim,
            cond_dim=film_embed_dim,
            n_steps=ode_steps,
            ode_kernel=ode_kernel,
            cross_attn_heads=cross_attn_heads,
            input_lead=input_lead,
            cross_attn_scale=cross_attn_scale,
            zero_init_gate=zero_init_gate,
        )
        scales = _channel_residual_scales(
            out_channels, input_lead, residual_scale, residual_scale_hard, residual_scale_rest
        )
        self.register_buffer("channel_scale", scales.view(1, out_channels, 1))
        self.input_idx = LEAD_PAIR_TO_INDEX[input_lead]

    def forward(self, x: torch.Tensor, phen_id: torch.Tensor | None = None) -> torch.Tensor:
        y0 = self.tcn(x)
        enc = self.encoder(y0)
        if phen_id is None:
            cond = torch.zeros(x.shape[0], self.film_embed_dim, device=x.device)
        else:
            cond = self.phen_embed(phen_id)
        delta = self.decoder(enc, y0, cond)
        return y0 + self.channel_scale * delta
