"""Simple 1D CNN encoder-decoder baseline (non-GAN)."""

from __future__ import annotations

import torch
import torch.nn as nn


class CNNAutoEncoder(nn.Module):
    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
    ) -> None:
        super().__init__()
        enc: list[nn.Module] = []
        dec: list[nn.Module] = []
        ch = base_channels
        prev = in_channels
        length_layers = depth

        for _ in range(length_layers):
            enc += [
                nn.Conv1d(prev, ch, kernel_size=7, stride=2, padding=3, bias=False),
                nn.BatchNorm1d(ch),
                nn.ReLU(inplace=True),
            ]
            prev = ch
            ch = min(ch * 2, 512)

        for _ in range(length_layers):
            dec += [
                nn.ConvTranspose1d(prev, ch // 2, kernel_size=4, stride=2, padding=1, bias=False),
                nn.BatchNorm1d(ch // 2),
                nn.ReLU(inplace=True),
            ]
            prev = ch // 2
            ch = ch // 2

        self.encoder = nn.Sequential(*enc)
        self.decoder = nn.Sequential(*dec)
        self.head = nn.Conv1d(prev, out_channels, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.encoder(x)
        h = self.decoder(h)
        if h.shape[-1] != x.shape[-1]:
            diff = x.shape[-1] - h.shape[-1]
            h = nn.functional.pad(h, (diff // 2, diff - diff // 2))
        return self.head(h)
