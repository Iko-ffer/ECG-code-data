"""M24: Performer macro encoder + ST-GCN parameterized Neural ODE dynamics decoder."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.constants import LEAD_PAIR_TO_INDEX, PHENOMENA
from src.models.film import PhenomenonEmbedding
from src.models.m21_bw_ode import soft_per_channel_phase
from src.models.m22_performer import PerformerBlock1d
from src.models.m23_st_gcn import GraphConv1d
from src.models.tcn_unet_refine import _channel_residual_scales


PHENOMENON_TO_ID: dict[str, int] = {p: i for i, p in enumerate(PHENOMENA)}


class PerformerMacroEncoder(nn.Module):
    """
    Temporal macro encoder: coarse 15-lead waveform -> context features (B, D, L).
    Downsampled linear-attention stack; no residual delta head.
    """

    def __init__(
        self,
        n_leads: int = 15,
        dim: int = 128,
        n_heads: int = 4,
        n_layers: int = 4,
        downsample: int = 4,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.downsample = downsample
        self.in_proj = nn.Conv1d(n_leads, dim, kernel_size=7, padding=3)
        self.down = nn.Conv1d(dim, dim, kernel_size=7, stride=downsample, padding=3)
        self.blocks = nn.ModuleList(
            [PerformerBlock1d(dim, n_heads, dropout=dropout) for _ in range(n_layers)]
        )
        self.up = nn.ConvTranspose1d(dim, dim, kernel_size=downsample, stride=downsample)
        self.out_norm = nn.GroupNorm(min(8, dim), dim)

    def forward(self, y0: torch.Tensor) -> torch.Tensor:
        length = y0.shape[-1]
        h = self.in_proj(y0)
        h = self.down(h)
        for block in self.blocks:
            h = block(h)
        h = self.up(h)
        if h.shape[-1] != length:
            diff = length - h.shape[-1]
            h = F.pad(h, (0, max(0, diff)))
            h = h[..., :length]
        return self.out_norm(h)


class STGCNODEDynamics(nn.Module):
    """ST-GCN parameterized dynamics f(h) -> dh/dt on (B, N, D, L)."""

    def __init__(self, dim: int, n_leads: int = 15, kernel: int = 7) -> None:
        super().__init__()
        pad = kernel // 2
        self.temporal = nn.Conv1d(dim, dim, kernel_size=kernel, padding=pad)
        self.graph = GraphConv1d(dim, n_leads)
        self.out = nn.Conv1d(dim, dim, kernel_size=1)
        self.norm = nn.GroupNorm(min(8, dim), dim)
        self.act = nn.SiLU()
        nn.init.zeros_(self.out.weight)
        nn.init.zeros_(self.out.bias)

    def forward(self, h: torch.Tensor) -> torch.Tensor:
        b, n, d, length = h.shape
        x = h.reshape(b * n, d, length)
        x = self.act(self.temporal(x))
        x = x.reshape(b, n, d, length)
        x = self.act(self.graph(x))
        x = self.norm(self.out(x.reshape(b * n, d, length)))
        return x.reshape(b, n, d, length)


class STGCNLatentODEDecoder(nn.Module):
    """
    Decoder: Performer context + coarse y0 -> per-lead latent, integrate ST-GCN ODE, decode delta.
    Uses soft per-channel phase (no QRS mask).
    """

    def __init__(
        self,
        n_leads: int = 15,
        enc_dim: int = 128,
        latent_dim: int = 64,
        cond_dim: int = 32,
        n_steps: int = 4,
        energy_kernel: int = 31,
        ode_kernel: int = 7,
    ) -> None:
        super().__init__()
        self.n_leads = n_leads
        self.n_steps = n_steps
        self.energy_kernel = energy_kernel
        self.lead_embed = nn.Conv1d(1, latent_dim, kernel_size=7, padding=3)
        self.ctx_fuse = nn.Conv1d(enc_dim + cond_dim + 1, latent_dim, kernel_size=1)
        self.ode_func = STGCNODEDynamics(latent_dim, n_leads, kernel=ode_kernel)
        self.decode = nn.Conv1d(latent_dim, 1, kernel_size=7, padding=3)
        nn.init.zeros_(self.decode.weight)
        nn.init.zeros_(self.decode.bias)

    def forward(self, enc: torch.Tensor, y0: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        b, _, length = y0.shape
        tau = soft_per_channel_phase(y0, self.energy_kernel)
        cond_exp = cond.unsqueeze(-1).expand(b, cond.shape[1], length)
        ctx = self.ctx_fuse(torch.cat([enc, cond_exp, tau.expand(b, 1, length)], dim=1))
        h = self.lead_embed(y0.reshape(b * self.n_leads, 1, length))
        h = h.reshape(b, self.n_leads, -1, length) + ctx.unsqueeze(1)
        dt = 1.0 / float(self.n_steps)
        for _ in range(self.n_steps):
            h = h + dt * self.ode_func(h)
        delta = self.decode(h.reshape(b * self.n_leads, h.shape[2], length))
        return delta.reshape(b, self.n_leads, length)


class TCNPerformerSTGCNODERefine(nn.Module):
    """M24: TCN coarse -> Performer encoder -> ST-GCN Neural ODE decoder."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
        num_phenomena: int = 5,
        film_embed_dim: int = 32,
        performer_dim: int = 128,
        performer_heads: int = 4,
        performer_layers: int = 4,
        performer_downsample: int = 4,
        ode_latent_dim: int = 64,
        ode_steps: int = 4,
        ode_kernel: int = 7,
    ) -> None:
        super().__init__()
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.encoder = PerformerMacroEncoder(
            n_leads=out_channels,
            dim=performer_dim,
            n_heads=performer_heads,
            n_layers=performer_layers,
            downsample=performer_downsample,
        )
        self.phen_embed = PhenomenonEmbedding(num_phenomena, film_embed_dim)
        self.film_embed_dim = film_embed_dim
        self.decoder = STGCNLatentODEDecoder(
            n_leads=out_channels,
            enc_dim=performer_dim,
            latent_dim=ode_latent_dim,
            cond_dim=film_embed_dim,
            n_steps=ode_steps,
            ode_kernel=ode_kernel,
        )
        scales = _channel_residual_scales(
            out_channels, input_lead, residual_scale, residual_scale_hard, residual_scale_rest
        )
        self.register_buffer("channel_scale", scales.view(1, out_channels, 1))
        self.input_idx = LEAD_PAIR_TO_INDEX[input_lead]

    def forward(self, x: torch.Tensor, phen_id: torch.Tensor | None = None) -> torch.Tensor:
        y0 = self.tcn(x)
        enc = self.encoder(y0)
        if phen_id is None:
            cond = torch.zeros(x.shape[0], self.film_embed_dim, device=x.device)
        else:
            cond = self.phen_embed(phen_id)
        delta = self.decoder(enc, y0, cond)
        return y0 + self.channel_scale * delta
