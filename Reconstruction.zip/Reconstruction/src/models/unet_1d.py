"""1D U-Net generator (reference-inspired for ECG lead synthesis)."""

from __future__ import annotations

import torch
import torch.nn as nn


class ConvBlock1D(nn.Module):
    def __init__(self, in_ch: int, out_ch: int, k: int = 7, dropout: float = 0.0) -> None:
        super().__init__()
        padding = k // 2
        layers: list[nn.Module] = [
            nn.Conv1d(in_ch, out_ch, kernel_size=k, padding=padding, bias=False),
            nn.BatchNorm1d(out_ch),
            nn.LeakyReLU(0.2, inplace=True),
        ]
        if dropout > 0:
            layers.append(nn.Dropout(dropout))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class GeneratorUNet1D(nn.Module):
    """
    Maps (B, 1, L) single virtual lead -> (B, out_channels, L) full virtual lead space.

    Architecture follows a standard 1D U-Net used in ECG GAN literature
    (Seo et al., 2022; similar to image-to-image translation U-Nets).
    """

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
    ) -> None:
        super().__init__()
        self.depth = depth
        ch = base_channels

        self.downs = nn.ModuleList()
        prev = in_channels
        for i in range(depth):
            out_ch = ch * (2**i)
            self.downs.append(ConvBlock1D(prev, out_ch))
            prev = out_ch
        self.pool = nn.MaxPool1d(2)

        self.bottleneck = ConvBlock1D(prev, prev * 2, dropout=0.5)

        self.ups = nn.ModuleList()
        self.up_convs = nn.ModuleList()
        dec_prev = prev * 2
        for i in reversed(range(depth)):
            skip_ch = ch * (2**i)
            self.ups.append(nn.ConvTranspose1d(dec_prev, skip_ch, kernel_size=2, stride=2))
            self.up_convs.append(ConvBlock1D(skip_ch * 2, skip_ch))
            dec_prev = skip_ch

        self.head = nn.Conv1d(dec_prev, out_channels, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        skips: list[torch.Tensor] = []
        h = x
        for block in self.downs:
            h = block(h)
            skips.append(h)
            h = self.pool(h)

        h = self.bottleneck(h)

        for up, conv, skip in zip(self.ups, self.up_convs, reversed(skips)):
            h = up(h)
            if h.shape[-1] != skip.shape[-1]:
                diff = skip.shape[-1] - h.shape[-1]
                h = nn.functional.pad(h, (diff // 2, diff - diff // 2))
            h = torch.cat([h, skip], dim=1)
            h = conv(h)

        return self.head(h)
