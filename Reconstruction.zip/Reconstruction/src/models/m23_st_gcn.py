"""M23: Spatio-temporal GCN refiner with anatomical lead-pair graph on TCN coarse output."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.constants import LEAD_PAIR_TO_INDEX
from src.lead_graph import build_lead_pair_adjacency
from src.models.tcn_unet_refine import _channel_residual_scales


class GraphConv1d(nn.Module):
    """Lead-wise graph mixing: (B, N, D, L) with fixed anatomical adjacency."""

    def __init__(self, dim: int, n_leads: int = 15) -> None:
        super().__init__()
        adj = build_lead_pair_adjacency(n_leads=n_leads)
        self.register_buffer("adj", adj)
        deg = adj.sum(dim=-1, keepdim=True).clamp(min=1.0)
        self.register_buffer("norm_adj", adj / deg)
        self.lin = nn.Conv1d(dim, dim, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, N, D, L)
        b, n, d, length = x.shape
        x_flat = x.permute(0, 3, 1, 2).reshape(b * length, n, d)
        agg = torch.matmul(self.norm_adj, x_flat)
        agg = agg.reshape(b, length, n, d).permute(0, 2, 3, 1)
        return self.lin(agg.reshape(b * n, d, length)).reshape(b, n, d, length)


class STGCNBlock(nn.Module):
    """Temporal conv -> graph conv -> temporal conv with residual."""

    def __init__(self, dim: int, n_leads: int = 15, kernel: int = 7) -> None:
        super().__init__()
        pad = kernel // 2
        self.temporal1 = nn.Conv1d(dim, dim, kernel_size=kernel, padding=pad)
        self.graph = GraphConv1d(dim, n_leads)
        self.temporal2 = nn.Conv1d(dim, dim, kernel_size=kernel, padding=pad)
        self.norm = nn.GroupNorm(min(8, dim), dim)
        self.act = nn.SiLU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, N, D, L)
        b, n, d, length = x.shape
        residual = x
        h = x.reshape(b * n, d, length)
        h = self.act(self.temporal1(h))
        h = h.reshape(b, n, d, length)
        h = self.act(self.graph(h))
        h = h.reshape(b * n, d, length)
        h = self.temporal2(h)
        h = self.norm(h)
        h = h.reshape(b, n, d, length)
        return self.act(h + residual)


class STGCNRefiner(nn.Module):
    """Per-lead embedding + ST-GCN blocks + per-lead decode."""

    def __init__(
        self,
        n_leads: int = 15,
        hidden: int = 64,
        n_blocks: int = 3,
        kernel: int = 7,
    ) -> None:
        super().__init__()
        self.n_leads = n_leads
        self.embed = nn.Conv1d(1, hidden, kernel_size=kernel, padding=kernel // 2)
        self.blocks = nn.ModuleList([STGCNBlock(hidden, n_leads, kernel) for _ in range(n_blocks)])
        self.decode = nn.Conv1d(hidden, 1, kernel_size=kernel, padding=kernel // 2)
        nn.init.zeros_(self.decode.weight)
        nn.init.zeros_(self.decode.bias)

    def forward(self, y0: torch.Tensor) -> torch.Tensor:
        b, n, length = y0.shape
        h = self.embed(y0.reshape(b * n, 1, length))
        h = h.reshape(b, n, -1, length)
        for block in self.blocks:
            h = block(h)
        delta = self.decode(h.reshape(b * n, h.shape[2], length)).reshape(b, n, length)
        return delta


class TCNSTGCNRefine(nn.Module):
    """M23: TCN coarse + anatomical ST-GCN refiner."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
        stgcn_hidden: int = 64,
        stgcn_blocks: int = 3,
    ) -> None:
        super().__init__()
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.refiner = STGCNRefiner(
            n_leads=out_channels,
            hidden=stgcn_hidden,
            n_blocks=stgcn_blocks,
        )
        scales = _channel_residual_scales(
            out_channels, input_lead, residual_scale, residual_scale_hard, residual_scale_rest
        )
        self.register_buffer("channel_scale", scales.view(1, out_channels, 1))
        self.input_idx = LEAD_PAIR_TO_INDEX[input_lead]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y0 = self.tcn(x)
        delta = self.refiner(y0)
        return y0 + self.channel_scale * delta
