"""Lead-graph residual refinement on top of TCN coarse reconstruction."""

from __future__ import annotations

import torch
import torch.nn as nn

from src.lead_graph import adjacency_to_attn_mask, build_lead_pair_adjacency


class GraphAttentionBlock(nn.Module):
    def __init__(self, dim: int, n_heads: int = 4, dropout: float = 0.1) -> None:
        super().__init__()
        self.attn = nn.MultiheadAttention(
            dim,
            n_heads,
            dropout=dropout,
            batch_first=True,
        )
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.ff = nn.Sequential(
            nn.Linear(dim, dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim * 2, dim),
        )

    def forward(self, x: torch.Tensor, attn_mask: torch.Tensor) -> torch.Tensor:
        y, _ = self.attn(x, x, x, attn_mask=attn_mask)
        x = self.norm1(x + y)
        x = self.norm2(x + self.ff(x))
        return x


class LeadGraphRefiner(nn.Module):
    """
    Refine coarse (B, 15, L) waveforms with graph attention over lead pairs + temporal decode.
    Output: y0 + delta (residual).
    """

    def __init__(
        self,
        n_leads: int = 15,
        hidden: int = 64,
        n_heads: int = 4,
        n_layers: int = 2,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.n_leads = n_leads
        adj = build_lead_pair_adjacency(n_leads=n_leads)
        self.register_buffer("adj", adj)
        self.register_buffer("attn_mask", adjacency_to_attn_mask(adj))

        self.embed = nn.Conv1d(1, hidden, kernel_size=7, padding=3)
        self.gat_layers = nn.ModuleList(
            [GraphAttentionBlock(hidden, n_heads=n_heads, dropout=dropout) for _ in range(n_layers)]
        )
        self.decode = nn.Sequential(
            nn.Conv1d(hidden, hidden, kernel_size=7, padding=3),
            nn.ReLU(inplace=True),
            nn.Conv1d(hidden, 1, kernel_size=7, padding=3),
        )
        nn.init.zeros_(self.decode[-1].weight)
        nn.init.zeros_(self.decode[-1].bias)

    def forward(self, y0: torch.Tensor) -> torch.Tensor:
        b, n, length = y0.shape
        h = self.embed(y0.reshape(b * n, 1, length))
        h = h.reshape(b, n, -1, length).mean(dim=-1)

        for layer in self.gat_layers:
            h = layer(h, self.attn_mask)

        h_seq = h.unsqueeze(-1).expand(b, n, h.shape[-1], length).reshape(b * n, -1, length)
        delta = self.decode(h_seq).reshape(b, n, length)
        return y0 + delta


class TCNGraphRefine(nn.Module):
    """M8a: M2-style TCN coarse reconstruction + lead-graph residual refinement."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        refine_hidden: int = 64,
        refine_heads: int = 4,
        refine_layers: int = 2,
    ) -> None:
        super().__init__()
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.refiner = LeadGraphRefiner(
            n_leads=out_channels,
            hidden=refine_hidden,
            n_heads=refine_heads,
            n_layers=refine_layers,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y0 = self.tcn(x)
        return self.refiner(y0)
