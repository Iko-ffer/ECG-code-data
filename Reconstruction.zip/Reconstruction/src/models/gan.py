from __future__ import annotations

from typing import Any

import torch.nn as nn

from src.models.chest_two_stage import ChestTwoStageDecoder
from src.models.cnn_baseline import CNNAutoEncoder
from src.models.cross_lead_decoder import CrossLeadAttentionDecoder
from src.models.patchgan import PatchDiscriminator1D
from src.models.spatial_patchgan import (
    HardBandedPatchDiscriminator,
    PerHardLeadPatchDiscriminator,
    SpatialBandedPatchDiscriminator,
)
from src.models.tcn_1d import TCNGenerator
from src.models.lead_graph_refine import TCNGraphRefine
from src.models.tcn_cross_lead import TCNCrossLeadAttention
from src.models.tcn_m13_refine import (
    TCNCoordDynUNetRefine,
    TCNCoordProgressiveRefine,
    TCNCoordUNetRefine,
    TCNDynGraphUNetRefine,
    TCNProgressiveRefine,
)
from src.models.tcn_unet_refine import TCNUNetChestRefine, TCNUNetRefine
from src.models.unet_1d import GeneratorUNet1D

_GAN_REFINE_NAMES = (
    "tcn_unet_hard_gan",
    "tcn_unet_chest_hard_gan",
    "tcn_unet_hard_gan_v1",
    "tcn_unet_chest_hard_gan_v3",
    "tcn_coord_unet_hard_gan",
    "tcn_dyn_graph_unet_hard_gan",
    "tcn_coord_dyn_unet_hard_gan",
    "tcn_prog_hard_gan",
    "tcn_coord_prog_hard_gan",
)


def _build_tcn_refiner(
    cfg: dict[str, Any],
    in_ch: int,
    out_ch: int,
    base: int,
    depth: int,
    input_lead: str,
    chest: bool,
) -> nn.Module:
    common = dict(
        in_channels=in_ch,
        out_channels=out_ch,
        base_channels=base,
        depth=depth,
        refine_base=int(cfg.get("refine_base", 32)),
        refine_depth=int(cfg.get("refine_depth", 3)),
        residual_scale=float(cfg.get("residual_scale", 0.05)),
        residual_scale_hard=cfg.get("residual_scale_hard"),
        residual_scale_rest=cfg.get("residual_scale_rest"),
        input_lead=input_lead,
        use_polarity_head=bool(cfg.get("polarity_head", False)),
    )
    if chest:
        return TCNUNetChestRefine(**common)
    return TCNUNetRefine(**common)


def _build_discriminator(
    cfg: dict[str, Any],
    name: str,
    input_lead: str,
    in_ch: int,
    base: int,
) -> nn.Module:
    disc_type = cfg.get("discriminator_type", "hard_banded")
    d_base = int(cfg.get("disc_base_channels", base))
    if disc_type == "temporal_per_channel":
        from src.models.ecg_discriminators import TemporalPerChannelDiscriminator

        return TemporalPerChannelDiscriminator(input_lead, in_ch, d_base)
    if disc_type == "spatial_graph":
        from src.models.ecg_discriminators import SpatialGraphDiscriminator

        return SpatialGraphDiscriminator(hidden=d_base)
    if disc_type == "st_decoupled":
        from src.models.ecg_discriminators import STDecoupledDiscriminator

        return STDecoupledDiscriminator(input_lead, in_ch, d_base)
    if disc_type == "kirchhoff":
        from src.models.ecg_discriminators import KirchhoffPatchDiscriminator

        return KirchhoffPatchDiscriminator(in_ch, d_base)
    if disc_type == "ekgan_per_lead_unet":
        from src.models.ekgan_modules import EKGANPerLeadUNetDiscriminator

        return EKGANPerLeadUNetDiscriminator(
            n_leads=in_ch,
            base_channels=int(cfg.get("ekgan_disc_base", 32)),
        )
    if disc_type == "anatomy_aware_temporal":
        from src.models.m25_anatomy_discriminator import AnatomyAwareTemporalPatchGAN

        return AnatomyAwareTemporalPatchGAN(
            n_leads=in_ch,
            base_channels=d_base,
            temporal_kernel=int(cfg.get("anatomy_disc_kernel", 17)),
            n_layers=int(cfg.get("anatomy_disc_layers", 4)),
            kvl_gain=float(cfg.get("kvl_adv_gain", 5.0)),
        )
    if disc_type == "anatomical_gated":
        from src.models.ecg_discriminators import AnatomicalGatedPatchDiscriminator

        return AnatomicalGatedPatchDiscriminator(
            in_ch,
            15,
            d_base,
            qrs_gain=float(cfg.get("qrs_adv_gain", 8.0)),
            st_gain=float(cfg.get("st_adv_gain", 5.0)),
        )
    if disc_type == "ecg_full":
        from src.models.ecg_discriminators import EcgFullDiscriminator

        streams = tuple(cfg.get("ecg_streams", ("st_decoupled", "anatomical", "kirchhoff")))
        return EcgFullDiscriminator(input_lead, in_ch, d_base, streams=streams)
    if disc_type == "st_kirchhoff":
        from src.models.ecg_discriminators import EcgFullDiscriminator

        return EcgFullDiscriminator(input_lead, in_ch, d_base, streams=("st_decoupled", "kirchhoff"))
    if disc_type == "anatomical_kirchhoff":
        from src.models.ecg_discriminators import EcgFullDiscriminator

        return EcgFullDiscriminator(input_lead, in_ch, d_base, streams=("anatomical", "kirchhoff"))
    if disc_type == "per_hard":
        return PerHardLeadPatchDiscriminator(
            input_lead=input_lead,
            in_input_channels=in_ch,
            base_channels=d_base,
        )
    if disc_type == "spatio_temporal_2d":
        from src.models.m14_discriminators import SpatioTemporalPatchDiscriminator2D

        return SpatioTemporalPatchDiscriminator2D(
            n_leads=in_ch + 14,
            base_channels=d_base,
        )
    if disc_type == "graph_temporal":
        from src.models.m14_discriminators import GraphTemporalDiscriminator

        return GraphTemporalDiscriminator(in_ch, d_base)
    if disc_type == "multi_scale":
        from src.models.m14_discriminators import MultiScalePatchDiscriminator

        return MultiScalePatchDiscriminator(in_ch + 14, d_base)
    if disc_type == "spatial_banded":
        return SpatialBandedPatchDiscriminator(
            input_lead=input_lead,
            in_input_channels=in_ch,
            base_channels=d_base,
        )
    return HardBandedPatchDiscriminator(
        input_lead=input_lead,
        in_input_channels=in_ch,
        base_channels=d_base,
    )


def build_model(
    cfg: dict[str, Any],
    input_lead: str | None = None,
    device: Any = None,
    delay_center_index: int = 0,
) -> tuple[nn.Module, nn.Module | None]:
    name = cfg.get("name", "gan_unet")
    in_ch = int(cfg.get("in_channels", 1))
    out_ch = int(cfg.get("out_channels", 15))
    base = int(cfg.get("base_channels", 64))
    depth = int(cfg.get("depth", 4))
    lead = input_lead or cfg.get("input_lead", "V2-V5")
    use_gan = bool(
        cfg.get("use_gan", name.startswith("gan") or name in _GAN_REFINE_NAMES or "hard_gan" in name)
    )

    generator: nn.Module
    if name in ("gan_unet", "spatial_gan_unet", "hard_gan_unet"):
        generator = GeneratorUNet1D(in_ch, out_ch, base, depth)
    elif name == "cnn_autoencoder":
        generator = CNNAutoEncoder(in_ch, out_ch, base, depth)
    elif name == "tcn":
        generator = TCNGenerator(in_ch, out_ch, base, depth)
    elif name == "chest_two_stage":
        generator = ChestTwoStageDecoder(
            in_channels=in_ch,
            base_channels=base,
            depth=depth,
            backbone=cfg.get("backbone", "unet"),
        )
    elif name == "cross_lead_attn":
        generator = CrossLeadAttentionDecoder(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=int(cfg.get("attn_depth", 2)),
            n_heads=int(cfg.get("n_heads", 4)),
        )
    elif name == "tcn_cross_lead":
        generator = TCNCrossLeadAttention(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            n_heads=int(cfg.get("n_heads", 4)),
            attn_layers=int(cfg.get("attn_layers", 1)),
        )
    elif name == "tcn_graph_refine":
        generator = TCNGraphRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            refine_hidden=int(cfg.get("refine_hidden", 64)),
            refine_heads=int(cfg.get("refine_heads", 4)),
            refine_layers=int(cfg.get("refine_layers", 2)),
        )
    elif name in ("tcn_unet_refine", "tcn_unet_hard_gan", "tcn_unet_hard_gan_v1"):
        generator = _build_tcn_refiner(cfg, in_ch, out_ch, base, depth, lead, chest=False)
    elif name == "tcn_coord_unet_hard_gan":
        generator = TCNCoordUNetRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            coord_token_dim=int(cfg.get("coord_token_dim", 32)),
        )
    elif name == "tcn_dyn_graph_unet_hard_gan":
        generator = TCNDynGraphUNetRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            dyn_graph_hidden=int(cfg.get("dyn_graph_hidden", 32)),
            anatomical_bias=float(cfg.get("anatomical_bias", 0.7)),
        )
    elif name == "tcn_coord_dyn_unet_hard_gan":
        generator = TCNCoordDynUNetRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            coord_token_dim=int(cfg.get("coord_token_dim", 32)),
            dyn_graph_hidden=int(cfg.get("dyn_graph_hidden", 32)),
            anatomical_bias=float(cfg.get("anatomical_bias", 0.7)),
        )
    elif name == "tcn_prog_hard_gan":
        generator = TCNProgressiveRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            lowpass_kernel=int(cfg.get("lowpass_kernel", 31)),
        )
    elif name == "tcn_coord_prog_hard_gan":
        generator = TCNCoordProgressiveRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            lowpass_kernel=int(cfg.get("lowpass_kernel", 31)),
            coord_token_dim=int(cfg.get("coord_token_dim", 32)),
        )
    elif name in ("tcn_unet_chest_refine", "tcn_unet_chest_hard_gan", "tcn_unet_chest_hard_gan_v3"):
        generator = _build_tcn_refiner(cfg, in_ch, out_ch, base, depth, lead, chest=True)
    elif name in ("tcn_film_refine", "tcn_unet_film_refine"):
        from src.models.m16_refine import TCNUNetFiLMRefine

        generator = TCNUNetFiLMRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            num_phenomena=int(cfg.get("num_phenomena", 5)),
            film_embed_dim=int(cfg.get("film_embed_dim", 32)),
        )
    elif name == "tcn_multiscale_refine":
        from src.models.m16_refine import TCNUNetMultiscaleRefine

        generator = TCNUNetMultiscaleRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
        )
    elif name == "tcn_morph_segment_refine":
        from src.models.m19_d_refine import TCNMorphSegmentRefine

        generator = TCNMorphSegmentRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            morph_gain=float(cfg.get("morph_gain", 0.5)),
            delay_center_index=delay_center_index,
        )
    elif name == "tcn_pca3_refine":
        from src.models.m19_d_refine import TCNPCA3Refine

        generator = TCNPCA3Refine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            pca_basis_path=str(cfg.get("pca_basis_path", "checkpoints_compare/pca3_V2V5.pt")),
            n_components=int(cfg.get("n_pca_components", 3)),
        )
    elif name == "tcn_latent_ode_refine":
        from src.models.m21_bw_ode import TCNLatentODERefine

        generator = TCNLatentODERefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            num_phenomena=int(cfg.get("num_phenomena", 5)),
            film_embed_dim=int(cfg.get("film_embed_dim", 32)),
            ode_latent_dim=int(cfg.get("ode_latent_dim", 64)),
            ode_steps=int(cfg.get("ode_steps", 4)),
        )
    elif name == "tcn_performer_refine":
        from src.models.m22_performer import TCNPerformerRefine

        generator = TCNPerformerRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            performer_dim=int(cfg.get("performer_dim", 128)),
            performer_heads=int(cfg.get("performer_heads", 4)),
            performer_layers=int(cfg.get("performer_layers", 4)),
            performer_downsample=int(cfg.get("performer_downsample", 4)),
        )
    elif name == "tcn_st_gcn_refine":
        from src.models.m23_st_gcn import TCNSTGCNRefine

        generator = TCNSTGCNRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            stgcn_hidden=int(cfg.get("stgcn_hidden", 64)),
            stgcn_blocks=int(cfg.get("stgcn_blocks", 3)),
        )
    elif name == "tcn_performer_stgcn_ode_refine":
        from src.models.m24_performer_stgcn_ode import TCNPerformerSTGCNODERefine

        generator = TCNPerformerSTGCNODERefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            num_phenomena=int(cfg.get("num_phenomena", 5)),
            film_embed_dim=int(cfg.get("film_embed_dim", 32)),
            performer_dim=int(cfg.get("performer_dim", 128)),
            performer_heads=int(cfg.get("performer_heads", 4)),
            performer_layers=int(cfg.get("performer_layers", 4)),
            performer_downsample=int(cfg.get("performer_downsample", 4)),
            ode_latent_dim=int(cfg.get("ode_latent_dim", 64)),
            ode_steps=int(cfg.get("ode_steps", 4)),
            ode_kernel=int(cfg.get("ode_kernel", 7)),
        )
    elif name == "tcn_performer_anatomy_stgcn_ode_refine":
        from src.models.m25_performer_stgcn_ode import TCNPerformerAnatomySTGCNODERefine

        generator = TCNPerformerAnatomySTGCNODERefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            num_phenomena=int(cfg.get("num_phenomena", 5)),
            film_embed_dim=int(cfg.get("film_embed_dim", 32)),
            performer_dim=int(cfg.get("performer_dim", 128)),
            performer_heads=int(cfg.get("performer_heads", 4)),
            performer_layers=int(cfg.get("performer_layers", 4)),
            performer_downsample=int(cfg.get("performer_downsample", 4)),
            ode_latent_dim=int(cfg.get("ode_latent_dim", 64)),
            ode_steps=int(cfg.get("ode_steps", 4)),
            ode_kernel=int(cfg.get("ode_kernel", 7)),
            cross_attn_dim=int(cfg.get("cross_attn_dim", 64)),
            cross_attn_heads=int(cfg.get("cross_attn_heads", 4)),
            cross_attn_scale=float(cfg.get("cross_attn_scale", 0.15)),
        )
    elif name == "tcn_attn_unet_refine":
        from src.models.m9_attn_refine import TCNAttnUNetRefine

        generator = TCNAttnUNetRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
        )
    elif name == "tcn_performer_attn_unet_replace":
        from src.models.m9_attn_refine import TCNPerformerAttnUNetReplaceRefine

        generator = TCNPerformerAttnUNetReplaceRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            num_phenomena=int(cfg.get("num_phenomena", 5)),
            film_embed_dim=int(cfg.get("film_embed_dim", 32)),
            performer_dim=int(cfg.get("performer_dim", 128)),
            performer_heads=int(cfg.get("performer_heads", 4)),
            performer_layers=int(cfg.get("performer_layers", 4)),
            performer_downsample=int(cfg.get("performer_downsample", 4)),
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
        )
    elif name == "tcn_performer_ode_attn_parallel":
        from src.models.m9_attn_refine import TCNPerformerODEAttnParallelRefine

        generator = TCNPerformerODEAttnParallelRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            num_phenomena=int(cfg.get("num_phenomena", 5)),
            film_embed_dim=int(cfg.get("film_embed_dim", 32)),
            performer_dim=int(cfg.get("performer_dim", 128)),
            performer_heads=int(cfg.get("performer_heads", 4)),
            performer_layers=int(cfg.get("performer_layers", 4)),
            performer_downsample=int(cfg.get("performer_downsample", 4)),
            ode_latent_dim=int(cfg.get("ode_latent_dim", 64)),
            ode_steps=int(cfg.get("ode_steps", 4)),
            ode_kernel=int(cfg.get("ode_kernel", 7)),
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            attn_residual_scale=cfg.get("attn_residual_scale"),
        )
    elif name == "unet_performer_ode_attn_parallel_full":
        from src.models.m9_attn_refine import UNetPerformerODEAttnParallelFullRefine

        generator = UNetPerformerODEAttnParallelFullRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            num_phenomena=int(cfg.get("num_phenomena", 5)),
            film_embed_dim=int(cfg.get("film_embed_dim", 32)),
            performer_dim=int(cfg.get("performer_dim", 128)),
            performer_heads=int(cfg.get("performer_heads", 4)),
            performer_layers=int(cfg.get("performer_layers", 4)),
            performer_downsample=int(cfg.get("performer_downsample", 4)),
            ode_latent_dim=int(cfg.get("ode_latent_dim", 64)),
            ode_steps=int(cfg.get("ode_steps", 4)),
            ode_kernel=int(cfg.get("ode_kernel", 7)),
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            attn_residual_scale=cfg.get("attn_residual_scale"),
            cross_attn_heads=int(cfg.get("cross_attn_heads", 4)),
            cross_attn_scale=float(cfg.get("cross_attn_scale", 0.1)),
            zero_init_gate=bool(cfg.get("zero_init_gate", True)),
        )
    elif name == "tcn_performer_ode_attn_parallel_full":
        from src.models.m9_attn_refine import TCNPerformerODEAttnParallelFullRefine

        generator = TCNPerformerODEAttnParallelFullRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            num_phenomena=int(cfg.get("num_phenomena", 5)),
            film_embed_dim=int(cfg.get("film_embed_dim", 32)),
            performer_dim=int(cfg.get("performer_dim", 128)),
            performer_heads=int(cfg.get("performer_heads", 4)),
            performer_layers=int(cfg.get("performer_layers", 4)),
            performer_downsample=int(cfg.get("performer_downsample", 4)),
            ode_latent_dim=int(cfg.get("ode_latent_dim", 64)),
            ode_steps=int(cfg.get("ode_steps", 4)),
            ode_kernel=int(cfg.get("ode_kernel", 7)),
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            attn_residual_scale=cfg.get("attn_residual_scale"),
            cross_attn_heads=int(cfg.get("cross_attn_heads", 4)),
            cross_attn_scale=float(cfg.get("cross_attn_scale", 0.1)),
            zero_init_gate=bool(cfg.get("zero_init_gate", True)),
        )
    elif name == "tcn_performer_ode_attn_ekgan":
        from src.models.m27_ekgan import TCNPerformerODEAttnEKGAN

        generator = TCNPerformerODEAttnEKGAN(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            num_phenomena=int(cfg.get("num_phenomena", 5)),
            film_embed_dim=int(cfg.get("film_embed_dim", 32)),
            performer_dim=int(cfg.get("performer_dim", 128)),
            performer_heads=int(cfg.get("performer_heads", 4)),
            performer_layers=int(cfg.get("performer_layers", 4)),
            performer_downsample=int(cfg.get("performer_downsample", 4)),
            ode_latent_dim=int(cfg.get("ode_latent_dim", 64)),
            ode_steps=int(cfg.get("ode_steps", 4)),
            ode_kernel=int(cfg.get("ode_kernel", 7)),
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            attn_residual_scale=cfg.get("attn_residual_scale"),
            label_ae_base=int(cfg.get("label_ae_base", 32)),
            label_ae_depth=int(cfg.get("label_ae_depth", 3)),
            latent_dim=int(cfg.get("ekgan_latent_dim", 128)),
        )
    elif name == "tcn_performer_m25_full_refine":
        from src.models.m25_full_model import TCNPerformerM25FullRefine

        generator = TCNPerformerM25FullRefine(
            in_channels=in_ch,
            out_channels=out_ch,
            base_channels=base,
            depth=depth,
            residual_scale=float(cfg.get("residual_scale", 0.05)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
            residual_scale_rest=cfg.get("residual_scale_rest"),
            input_lead=lead,
            num_phenomena=int(cfg.get("num_phenomena", 5)),
            film_embed_dim=int(cfg.get("film_embed_dim", 32)),
            performer_dim=int(cfg.get("performer_dim", 128)),
            performer_heads=int(cfg.get("performer_heads", 4)),
            performer_layers=int(cfg.get("performer_layers", 4)),
            performer_downsample=int(cfg.get("performer_downsample", 4)),
            ode_latent_dim=int(cfg.get("ode_latent_dim", 64)),
            ode_steps=int(cfg.get("ode_steps", 4)),
            ode_kernel=int(cfg.get("ode_kernel", 7)),
            cross_attn_heads=int(cfg.get("cross_attn_heads", 4)),
            cross_attn_scale=float(cfg.get("cross_attn_scale", 0.1)),
            zero_init_gate=bool(cfg.get("zero_init_gate", False)),
        )
    elif name == "physics_residual":
        from src.models.physics_residual import PhysicsResidualGenerator

        if device is None:
            import torch as _torch

            device = _torch.device("cpu")
        generator = PhysicsResidualGenerator(
            ridge_checkpoint=str(cfg["ridge_checkpoint"]),
            device=device,
            refine_base=int(cfg.get("refine_base", 32)),
            refine_depth=int(cfg.get("refine_depth", 3)),
            residual_scale=float(cfg.get("residual_scale", 0.2)),
            residual_scale_hard=cfg.get("residual_scale_hard"),
        residual_scale_rest=cfg.get("residual_scale_rest"),
        input_lead=lead,
        use_polarity_head=bool(cfg.get("polarity_head", False)),
    )
    else:
        raise ValueError(f"Unknown model.name: {name}")

    discriminator: nn.Module | None = None
    if use_gan:
        if name == "spatial_gan_unet":
            discriminator = SpatialBandedPatchDiscriminator(
                input_lead=lead,
                in_input_channels=in_ch,
                base_channels=base,
            )
        elif cfg.get("discriminator_type") in (
            "wavelet_high",
            "spatio_temporal_2d",
            "graph_temporal",
            "multi_scale",
        ):
            disc_type = cfg.get("discriminator_type", "wavelet_high")
            d_base = int(cfg.get("disc_base_channels", base))
            if disc_type == "wavelet_high":
                discriminator = PatchDiscriminator1D(
                    in_channels=in_ch + 14,
                    base_channels=d_base,
                )
            else:
                discriminator = _build_discriminator(cfg, name, lead, in_ch, base)
        elif cfg.get("discriminator_type") in ("anatomy_aware_temporal", "ekgan_per_lead_unet"):
            discriminator = _build_discriminator(cfg, name, lead, out_ch, base)
        elif name in (
            "tcn_performer_stgcn_ode_refine",
            "tcn_performer_anatomy_stgcn_ode_refine",
            "tcn_performer_m25_full_refine",
            "tcn_performer_ode_attn_ekgan",
            "tcn_performer_ode_attn_parallel_full",
            "unet_performer_ode_attn_parallel_full",
        ):
            discriminator = _build_discriminator(cfg, name, lead, in_ch, base)
        elif name in ("hard_gan_unet",) + _GAN_REFINE_NAMES:
            discriminator = _build_discriminator(cfg, name, lead, in_ch, base)
        else:
            discriminator = PatchDiscriminator1D(in_channels=in_ch + out_ch, base_channels=base)

    return generator, discriminator
