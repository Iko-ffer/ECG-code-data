"""Temporal convolutional network: 1 virtual lead -> 15 virtual lead pairs."""

from __future__ import annotations

import torch
import torch.nn as nn


class TCNBlock(nn.Module):
    def __init__(
        self,
        in_ch: int,
        out_ch: int,
        kernel_size: int = 7,
        dilation: int = 1,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        padding = (kernel_size - 1) * dilation // 2
        self.conv = nn.Conv1d(
            in_ch,
            out_ch,
            kernel_size=kernel_size,
            padding=padding,
            dilation=dilation,
            bias=False,
        )
        self.bn = nn.BatchNorm1d(out_ch)
        self.relu = nn.ReLU(inplace=True)
        self.drop = nn.Dropout(dropout)
        self.residual = nn.Conv1d(in_ch, out_ch, kernel_size=1) if in_ch != out_ch else nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.drop(self.relu(self.bn(self.conv(x))))
        res = self.residual(x)
        if h.shape[-1] != res.shape[-1]:
            diff = res.shape[-1] - h.shape[-1]
            h = nn.functional.pad(h, (diff // 2, diff - diff // 2))
        return h + res


class TCNGenerator(nn.Module):
    """Dilated TCN encoder-decoder for multi-lead waveform synthesis."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
    ) -> None:
        super().__init__()
        ch = base_channels
        blocks: list[nn.Module] = [nn.Conv1d(in_channels, ch, kernel_size=1)]
        for i in range(depth):
            blocks.append(TCNBlock(ch, ch, dilation=2**i, dropout=0.1))
            blocks.append(TCNBlock(ch, ch * 2, dilation=2**i, dropout=0.1))
            ch *= 2
        self.encoder = nn.Sequential(*blocks)
        self.decoder = nn.Sequential(
            nn.Conv1d(ch, base_channels * 2, kernel_size=7, padding=3),
            nn.ReLU(inplace=True),
            nn.Conv1d(base_channels * 2, base_channels, kernel_size=7, padding=3),
            nn.ReLU(inplace=True),
        )
        self.head = nn.Conv1d(base_channels, out_channels, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.encoder(x)
        h = self.decoder(h)
        if h.shape[-1] != x.shape[-1]:
            diff = x.shape[-1] - h.shape[-1]
            h = nn.functional.pad(h, (diff // 2, diff - diff // 2))
        return self.head(h)
