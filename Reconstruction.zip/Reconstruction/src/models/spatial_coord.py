"""Anatomical coordinate embeddings and lead-wise cross-attention."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.constants import LEAD_PAIR_TO_INDEX, VIRTUAL_LEAD_PAIRS
from src.lead_space import parse_pair, pair_spatial_distance


def build_anatomical_coords(input_lead: str = "V2-V5") -> torch.Tensor:
    """
    Per virtual lead pair: (norm_distance_to_input, orientation, pair_span).
    Returns (15, 3) float32.
    """
    si, sj = parse_pair(input_lead)
    center_in = (si + sj) / 2.0
    coords: list[list[float]] = []
    for pair in VIRTUAL_LEAD_PAIRS:
        i, j = parse_pair(pair)
        center = (i + j) / 2.0
        dist = float(pair_spatial_distance(pair, input_lead)) / 6.0
        orient = (center - center_in) / 5.0
        span = abs(i - j) / 5.0
        coords.append([dist, orient, span])
    return torch.tensor(coords, dtype=torch.float32)


class AnatomicalSpatialEmbedding(nn.Module):
    """Fixed anatomy -> (n_leads, token_dim) spatial tokens."""

    def __init__(
        self,
        n_leads: int = 15,
        token_dim: int = 32,
        input_lead: str = "V2-V5",
    ) -> None:
        super().__init__()
        self.n_leads = n_leads
        self.register_buffer("coords", build_anatomical_coords(input_lead))
        self.mlp = nn.Sequential(
            nn.Linear(3, token_dim),
            nn.GELU(),
            nn.Linear(token_dim, token_dim),
        )
        input_idx = LEAD_PAIR_TO_INDEX[input_lead]
        bias = torch.zeros(n_leads, token_dim)
        bias[input_idx] = 0.5
        self.input_bias = nn.Parameter(bias)

    def forward(self) -> torch.Tensor:
        tokens = self.mlp(self.coords) + self.input_bias
        return tokens


class LeadSpatialCrossAttention(nn.Module):
    """
    Cross-attention between per-lead temporal features (query) and
    fixed anatomical spatial tokens (key/value). Input/output: (B, n_leads, L).
    """

    def __init__(
        self,
        n_leads: int = 15,
        token_dim: int = 32,
        n_heads: int = 4,
        input_lead: str = "V2-V5",
        residual_scale: float = 0.1,
    ) -> None:
        super().__init__()
        self.n_leads = n_leads
        self.residual_scale = residual_scale
        self.lead_enc = nn.Sequential(
            nn.Conv1d(1, token_dim, kernel_size=7, padding=3, bias=False),
            nn.GELU(),
            nn.Conv1d(token_dim, token_dim, kernel_size=7, padding=3, bias=False),
        )
        self.spatial_emb = AnatomicalSpatialEmbedding(n_leads, token_dim, input_lead)
        self.attn = nn.MultiheadAttention(token_dim, n_heads, batch_first=True)
        self.norm = nn.LayerNorm(token_dim)
        self.out_proj = nn.Sequential(
            nn.Linear(token_dim, token_dim),
            nn.GELU(),
            nn.Linear(token_dim, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, n, length = x.shape
        h = self.lead_enc(x.reshape(b * n, 1, length))
        feat = h.mean(dim=-1).reshape(b, n, -1)
        tokens = self.spatial_emb().unsqueeze(0).expand(b, -1, -1)
        attn_out, _ = self.attn(feat, tokens, tokens)
        feat = self.norm(feat + attn_out)
        delta = self.out_proj(feat).squeeze(-1).unsqueeze(-1).expand(-1, -1, length)
        return x + self.residual_scale * delta
