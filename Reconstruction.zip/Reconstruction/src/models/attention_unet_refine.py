"""Modified Attention U-Net 1D refiner (Garg et al. single-lead multi-lead reconstruction)."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.models.unet_1d import ConvBlock1D


class AttentionGate1D(nn.Module):
    """Attention gate on skip connection (Oktay et al. style, 1D)."""

    def __init__(self, skip_channels: int, gate_channels: int, inter_channels: int | None = None) -> None:
        super().__init__()
        inter = inter_channels or max(skip_channels // 2, 8)
        self.Wx = nn.Conv1d(skip_channels, inter, kernel_size=1, bias=False)
        self.Wg = nn.Conv1d(gate_channels, inter, kernel_size=1, bias=False)
        self.psi = nn.Conv1d(inter, 1, kernel_size=1, bias=True)

    def forward(self, skip: torch.Tensor, gate: torch.Tensor) -> torch.Tensor:
        if skip.shape[-1] != gate.shape[-1]:
            gate = F.interpolate(gate, size=skip.shape[-1], mode="linear", align_corners=False)
        attn = torch.sigmoid(self.psi(F.relu(self.Wx(skip) + self.Wg(gate))))
        return skip * attn


class AttentionLeadRefinerUNet1D(nn.Module):
    """
    Modified Attention U-Net: conv stride-2 down / transpose up (no maxpool),
    concat(raw_skip, attn_gated_skip, upsampled), zero-init output head.
    """

    def __init__(
        self,
        in_channels: int = 15,
        out_channels: int | None = None,
        base_channels: int = 32,
        depth: int = 3,
    ) -> None:
        super().__init__()
        out_channels = in_channels if out_channels is None else out_channels
        self.depth = depth
        ch = base_channels

        self.down_blocks = nn.ModuleList()
        self.down_samples = nn.ModuleList()
        prev = in_channels
        for i in range(depth):
            out_ch = ch * (2**i)
            self.down_blocks.append(ConvBlock1D(prev, out_ch, k=3))
            self.down_samples.append(
                nn.Sequential(
                    nn.Conv1d(out_ch, out_ch, kernel_size=3, stride=2, padding=1, bias=False),
                    nn.BatchNorm1d(out_ch),
                    nn.LeakyReLU(0.2, inplace=True),
                )
            )
            prev = out_ch

        self.bottleneck = ConvBlock1D(prev, prev * 2, dropout=0.1)

        self.up_samples = nn.ModuleList()
        self.attn_gates = nn.ModuleList()
        self.up_convs = nn.ModuleList()
        dec_prev = prev * 2
        for i in reversed(range(depth)):
            skip_ch = ch * (2**i)
            self.up_samples.append(
                nn.Sequential(
                    nn.ConvTranspose1d(
                        dec_prev,
                        skip_ch,
                        kernel_size=3,
                        stride=2,
                        padding=1,
                        output_padding=1,
                        bias=False,
                    ),
                    nn.BatchNorm1d(skip_ch),
                    nn.LeakyReLU(0.2, inplace=True),
                )
            )
            self.attn_gates.append(AttentionGate1D(skip_ch, skip_ch))
            self.up_convs.append(ConvBlock1D(skip_ch * 3, skip_ch, k=3))
            dec_prev = skip_ch

        self.head = nn.Conv1d(dec_prev, out_channels, kernel_size=1)
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    @staticmethod
    def _align(x: torch.Tensor, length: int) -> torch.Tensor:
        if x.shape[-1] == length:
            return x
        if x.shape[-1] > length:
            return x[..., :length]
        diff = length - x.shape[-1]
        return F.pad(x, (0, diff))

    def forward(self, y0: torch.Tensor) -> torch.Tensor:
        skips: list[torch.Tensor] = []
        h = y0
        for block, down in zip(self.down_blocks, self.down_samples):
            h = block(h)
            skips.append(h)
            h = down(h)

        h = self.bottleneck(h)

        for up, gate, conv, skip in zip(
            self.up_samples, self.attn_gates, self.up_convs, reversed(skips)
        ):
            h = up(h)
            h = self._align(h, skip.shape[-1])
            attn_skip = gate(skip, h)
            h = conv(torch.cat([h, skip, attn_skip], dim=1))

        h = self._align(h, y0.shape[-1])
        return self.head(h)
