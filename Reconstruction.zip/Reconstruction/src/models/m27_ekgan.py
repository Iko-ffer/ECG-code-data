"""M27: M9c ODE+Attn parallel generator with EKGAN label-AE latent alignment."""

from __future__ import annotations

import torch
import torch.nn as nn

from src.models.ekgan_modules import InputLeadLabelAE
from src.models.m9_attn_refine import TCNPerformerODEAttnParallelRefine


class TCNPerformerODEAttnEKGAN(TCNPerformerODEAttnParallelRefine):
    """M9c parallel refine + input-lead label AE for EKGAN latent loss."""

    def __init__(
        self,
        *args,
        label_ae_base: int = 32,
        label_ae_depth: int = 3,
        latent_dim: int = 128,
        **kwargs,
    ) -> None:
        performer_dim = int(kwargs.get("performer_dim", 128))
        super().__init__(*args, **kwargs)
        self.label_ae = InputLeadLabelAE(label_ae_base, label_ae_depth, latent_dim)
        self.latent_dim = latent_dim
        self.performer_proj = nn.Linear(performer_dim, latent_dim)

    def encode_performer(self, y0: torch.Tensor) -> torch.Tensor:
        enc = self.encoder(y0)
        return self.performer_proj(enc.mean(dim=-1))

    def encode_label_input(self, x_lead: torch.Tensor) -> torch.Tensor:
        return self.label_ae.encode(x_lead)

    def label_identity(self, x_lead: torch.Tensor) -> torch.Tensor:
        return self.label_ae(x_lead)
