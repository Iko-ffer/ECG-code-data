"""EKGAN-style label generator and per-lead 1D U-Net discriminator (M27)."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.models.unet_1d import ConvBlock1D


class InputLeadLabelAE(nn.Module):
    """GL: identity autoencoder on input lead for latent alignment."""

    def __init__(self, base_channels: int = 32, depth: int = 3, latent_dim: int = 128) -> None:
        super().__init__()
        ch = base_channels
        self.downs = nn.ModuleList()
        self.pools = nn.ModuleList()
        prev = 1
        for i in range(depth):
            out_ch = ch * (2**i)
            self.downs.append(ConvBlock1D(prev, out_ch, k=7))
            self.pools.append(nn.Conv1d(out_ch, out_ch, kernel_size=3, stride=2, padding=1))
            prev = out_ch
        self.bottleneck = ConvBlock1D(prev, latent_dim, k=3)
        self.latent_dim = latent_dim
        self.up = nn.ConvTranspose1d(latent_dim, prev, kernel_size=3, stride=2, padding=1, output_padding=1)
        self.up_conv = ConvBlock1D(prev * 2, prev, k=7)
        self.head = nn.Conv1d(prev, 1, kernel_size=1)

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        h = x
        skip = h
        for block, pool in zip(self.downs, self.pools):
            h = block(h)
            skip = h
            h = F.leaky_relu(pool(h), 0.2)
        h = self.bottleneck(h)
        return h.mean(dim=-1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        skips: list[torch.Tensor] = []
        h = x
        for block, pool in zip(self.downs, self.pools):
            h = block(h)
            skips.append(h)
            h = F.leaky_relu(pool(h), 0.2)
        z = self.bottleneck(h)
        h = F.leaky_relu(self.up(z), 0.2)
        skip = skips[-1]
        if h.shape[-1] != skip.shape[-1]:
            diff = skip.shape[-1] - h.shape[-1]
            h = F.pad(h, (0, max(0, diff)))[..., : skip.shape[-1]]
        h = self.up_conv(torch.cat([h, skip], dim=1))
        out = self.head(h)
        if out.shape[-1] != x.shape[-1]:
            diff = x.shape[-1] - out.shape[-1]
            out = F.pad(out, (0, max(0, diff)))[..., : x.shape[-1]]
        return out


class _MiniUNetDisc1D(nn.Module):
    def __init__(self, in_channels: int = 2, base: int = 32, depth: int = 2) -> None:
        super().__init__()
        ch = base
        self.downs = nn.ModuleList()
        self.pools = nn.ModuleList()
        prev = in_channels
        for i in range(depth):
            out_ch = ch * (2**i)
            self.downs.append(ConvBlock1D(prev, out_ch, k=5))
            self.pools.append(nn.Conv1d(out_ch, out_ch, kernel_size=3, stride=2, padding=1))
            prev = out_ch
        self.mid = ConvBlock1D(prev, prev, k=5)
        self.out = nn.Conv1d(prev, 1, kernel_size=5, padding=2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = x
        for block, pool in zip(self.downs, self.pools):
            h = block(h)
            h = F.leaky_relu(pool(h), 0.2)
        h = self.mid(h)
        return self.out(h)


class EKGANPerLeadUNetDiscriminator(nn.Module):
    """Shared per-lead 1D U-Net D: cond input lead + each output lead separately."""

    def __init__(self, n_leads: int = 15, base_channels: int = 32) -> None:
        super().__init__()
        self.n_leads = n_leads
        self.disc = _MiniUNetDisc1D(in_channels=2, base=base_channels, depth=2)

    def forward(self, x_cond: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        if x_cond.shape[1] != 1:
            x_cond = x_cond[:, :1]
        logits = []
        for i in range(self.n_leads):
            lead = y[:, i : i + 1]
            logits.append(self.disc(torch.cat([x_cond, lead], dim=1)))
        min_len = min(t.shape[-1] for t in logits)
        logits = [t[..., :min_len] for t in logits]
        return torch.stack(logits, dim=1)
