"""M7: TCN encoder + cross-lead temporal attention decoder."""

from __future__ import annotations

import torch
import torch.nn as nn

from src.models.tcn_1d import TCNBlock


class TCNCrossLeadAttention(nn.Module):
    """
    TCN extracts multi-scale temporal features; 15 lead queries attend over time;
    per-lead conv heads decode waveforms.
    """

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        n_heads: int = 4,
        attn_layers: int = 1,
    ) -> None:
        super().__init__()
        self.out_channels = out_channels
        ch = base_channels

        blocks: list[nn.Module] = [nn.Conv1d(in_channels, ch, kernel_size=1)]
        for i in range(depth):
            d = 2**i
            blocks.append(TCNBlock(ch, ch, dilation=d, dropout=0.1))
            blocks.append(TCNBlock(ch, ch, dilation=d, dropout=0.1))
        self.tcn_encoder = nn.Sequential(*blocks)
        self.enc_norm = nn.LayerNorm(ch)

        self.lead_queries = nn.Parameter(torch.randn(out_channels, ch) * 0.02)
        self.attn_layers = nn.ModuleList(
            [
                nn.MultiheadAttention(
                    embed_dim=ch,
                    num_heads=n_heads,
                    dropout=0.1,
                    batch_first=True,
                )
                for _ in range(attn_layers)
            ]
        )
        self.norms = nn.ModuleList([nn.LayerNorm(ch) for _ in range(attn_layers)])
        self.ffs = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Linear(ch, ch * 2),
                    nn.GELU(),
                    nn.Linear(ch * 2, ch),
                )
                for _ in range(attn_layers)
            ]
        )
        self.wave_head = nn.Conv1d(ch * 2, 1, kernel_size=7, padding=3)
        nn.init.normal_(self.wave_head.weight, std=1e-3)
        nn.init.zeros_(self.wave_head.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, _, length = x.shape
        h = self.tcn_encoder(x)
        h_t = self.enc_norm(h.permute(0, 2, 1))
        tokens = self.lead_queries.unsqueeze(0).expand(b, -1, -1)

        for attn, norm, ff in zip(self.attn_layers, self.norms, self.ffs):
            attn_out, _ = attn(tokens, h_t, h_t)
            tokens = norm(tokens + attn_out)
            tokens = tokens + ff(tokens)

        outs: list[torch.Tensor] = []
        for i in range(self.out_channels):
            ctx = tokens[:, i, :].unsqueeze(-1).expand(-1, -1, length)
            fused = torch.cat([h, ctx], dim=1)
            outs.append(self.wave_head(fused))
        return torch.cat(outs, dim=1)
