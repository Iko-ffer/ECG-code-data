"""M25: M24 + anatomical cross-attention bridge (Opt2)."""

from __future__ import annotations

import torch
import torch.nn as nn

from src.constants import LEAD_PAIR_TO_INDEX
from src.models.film import PhenomenonEmbedding
from src.models.m24_performer_stgcn_ode import (
    PHENOMENON_TO_ID,
    PerformerMacroEncoder,
    STGCNODEDynamics,
    soft_per_channel_phase,
)
from src.models.m25_anatomical_cross_attn import AnatomicalCrossAttentionBridge
from src.models.tcn_unet_refine import _channel_residual_scales


class STGCNLatentODEDecoderLeadCtx(nn.Module):
    """ST-GCN ODE decoder with optional per-lead anatomical context (B, N, D, L)."""

    def __init__(
        self,
        n_leads: int = 15,
        enc_dim: int = 128,
        latent_dim: int = 64,
        cond_dim: int = 32,
        n_steps: int = 4,
        energy_kernel: int = 31,
        ode_kernel: int = 7,
    ) -> None:
        super().__init__()
        self.n_leads = n_leads
        self.n_steps = n_steps
        self.energy_kernel = energy_kernel
        self.lead_embed = nn.Conv1d(1, latent_dim, kernel_size=7, padding=3)
        self.ctx_fuse = nn.Conv1d(enc_dim + cond_dim + 1, latent_dim, kernel_size=1)
        self.lead_ctx_proj = nn.Conv1d(enc_dim, latent_dim, kernel_size=1)
        self.ode_func = STGCNODEDynamics(latent_dim, n_leads, kernel=ode_kernel)
        self.decode = nn.Conv1d(latent_dim, 1, kernel_size=7, padding=3)
        nn.init.zeros_(self.decode.weight)
        nn.init.zeros_(self.decode.bias)

    def forward(
        self,
        enc: torch.Tensor,
        y0: torch.Tensor,
        cond: torch.Tensor,
        lead_ctx: torch.Tensor | None = None,
    ) -> torch.Tensor:
        b, _, length = y0.shape
        tau = soft_per_channel_phase(y0, self.energy_kernel)
        cond_exp = cond.unsqueeze(-1).expand(b, cond.shape[1], length)
        ctx = self.ctx_fuse(torch.cat([enc, cond_exp, tau.expand(b, 1, length)], dim=1))
        h = self.lead_embed(y0.reshape(b * self.n_leads, 1, length))
        h = h.reshape(b, self.n_leads, -1, length) + ctx.unsqueeze(1)
        if lead_ctx is not None:
            lc = self.lead_ctx_proj(lead_ctx.reshape(b * self.n_leads, lead_ctx.shape[2], length))
            h = h + lc.reshape(b, self.n_leads, -1, length)
        dt = 1.0 / float(self.n_steps)
        for _ in range(self.n_steps):
            h = h + dt * self.ode_func(h)
        delta = self.decode(h.reshape(b * self.n_leads, h.shape[2], length))
        return delta.reshape(b, self.n_leads, length)


class TCNPerformerAnatomySTGCNODERefine(nn.Module):
    """M25: M24 backbone + anatomical cross-attention between encoder and ODE decoder."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
        num_phenomena: int = 5,
        film_embed_dim: int = 32,
        performer_dim: int = 128,
        performer_heads: int = 4,
        performer_layers: int = 4,
        performer_downsample: int = 4,
        ode_latent_dim: int = 64,
        ode_steps: int = 4,
        ode_kernel: int = 7,
        cross_attn_dim: int = 64,
        cross_attn_heads: int = 4,
        cross_attn_scale: float = 0.15,
    ) -> None:
        super().__init__()
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.encoder = PerformerMacroEncoder(
            n_leads=out_channels,
            dim=performer_dim,
            n_heads=performer_heads,
            n_layers=performer_layers,
            downsample=performer_downsample,
        )
        self.cross_attn = AnatomicalCrossAttentionBridge(
            enc_dim=performer_dim,
            token_dim=cross_attn_dim,
            n_leads=out_channels,
            n_heads=cross_attn_heads,
            input_lead=input_lead,
            residual_scale=cross_attn_scale,
        )
        self.phen_embed = PhenomenonEmbedding(num_phenomena, film_embed_dim)
        self.film_embed_dim = film_embed_dim
        self.decoder = STGCNLatentODEDecoderLeadCtx(
            n_leads=out_channels,
            enc_dim=performer_dim,
            latent_dim=ode_latent_dim,
            cond_dim=film_embed_dim,
            n_steps=ode_steps,
            ode_kernel=ode_kernel,
        )
        scales = _channel_residual_scales(
            out_channels, input_lead, residual_scale, residual_scale_hard, residual_scale_rest
        )
        self.register_buffer("channel_scale", scales.view(1, out_channels, 1))
        self.input_idx = LEAD_PAIR_TO_INDEX[input_lead]

    def forward(
        self,
        x: torch.Tensor,
        phen_id: torch.Tensor | None = None,
    ) -> torch.Tensor:
        y0 = self.tcn(x)
        enc = self.encoder(y0)
        x1 = x[:, :1] if x.shape[1] == 1 else x[:, self.input_idx : self.input_idx + 1]
        enc, lead_ctx = self.cross_attn(enc, x1)
        if phen_id is None:
            cond = torch.zeros(x.shape[0], self.film_embed_dim, device=x.device)
        else:
            cond = self.phen_embed(phen_id)
        delta = self.decoder(enc, y0, cond, lead_ctx)
        return y0 + self.channel_scale * delta
