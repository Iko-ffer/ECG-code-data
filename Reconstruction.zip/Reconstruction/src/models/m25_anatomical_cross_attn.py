"""M25-Opt2: Anatomical cross-attention bridge (spatial Q, input temporal K/V)."""

from __future__ import annotations

import torch
import torch.nn as nn

from src.models.spatial_coord import AnatomicalSpatialEmbedding


class AnatomicalCrossAttentionBridge(nn.Module):
    """
    Insert between Performer macro-encoder and ST-GCN ODE decoder.

    Query:  fixed 15-pair anatomical spatial tokens.
    Key/Value: temporal features from input lead (V2-V5), NOT another temporal self-attention stack.

    Output: lead-specific context (B, n_leads, dim, L) added to global encoder features.
    """

    def __init__(
        self,
        enc_dim: int = 128,
        token_dim: int = 64,
        n_leads: int = 15,
        n_heads: int = 4,
        input_lead: str = "V2-V5",
        residual_scale: float = 0.15,
    ) -> None:
        super().__init__()
        self.n_leads = n_leads
        self.enc_dim = enc_dim
        self.token_dim = token_dim
        self.residual_scale = residual_scale
        self.spatial_emb = AnatomicalSpatialEmbedding(n_leads, token_dim, input_lead)
        self.input_proj = nn.Sequential(
            nn.Conv1d(1, token_dim, kernel_size=7, padding=3, bias=False),
            nn.GELU(),
            nn.Conv1d(token_dim, token_dim, kernel_size=7, padding=3, bias=False),
        )
        self.cross_attn = nn.MultiheadAttention(token_dim, n_heads, batch_first=True)
        self.norm_q = nn.LayerNorm(token_dim)
        self.norm_kv = nn.LayerNorm(token_dim)
        self.token_to_enc = nn.Linear(token_dim, enc_dim)
        nn.init.zeros_(self.token_to_enc.weight)
        nn.init.zeros_(self.token_to_enc.bias)

    def forward(
        self,
        enc: torch.Tensor,
        x_input: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        enc: (B, enc_dim, L), x_input: (B, 1, L)
        Returns global enc (B, enc_dim, L), lead_ctx (B, n_leads, enc_dim, L)
        """
        b, _, length = enc.shape
        kv = self.input_proj(x_input).transpose(1, 2)
        kv = self.norm_kv(kv)
        q = self.spatial_emb().unsqueeze(0).expand(b, -1, -1)
        q = self.norm_q(q)
        attn_out, _ = self.cross_attn(q, kv, kv)
        lead_tok = q + attn_out

        lead_bias = self.token_to_enc(lead_tok)
        global_bias = lead_bias.mean(dim=1).unsqueeze(-1)
        enc_global = enc + self.residual_scale * global_bias
        lead_ctx = lead_bias.unsqueeze(-1).expand(-1, -1, -1, length)
        return enc_global, lead_ctx
