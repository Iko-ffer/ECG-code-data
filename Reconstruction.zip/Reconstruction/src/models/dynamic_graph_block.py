"""Dynamic graph attention over virtual lead pairs with anatomical prior."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.lead_graph import build_lead_pair_adjacency


class DynamicGraphBlock(nn.Module):
    """
    Per-beat dynamic adjacency blended with static anatomy.
    Input/output: (B, n_leads, L).
    """

    def __init__(
        self,
        n_leads: int = 15,
        hidden: int = 32,
        anatomical_bias: float = 0.7,
        residual_scale: float = 0.1,
    ) -> None:
        super().__init__()
        self.n_leads = n_leads
        self.anatomical_bias = anatomical_bias
        self.residual_scale = residual_scale
        adj = build_lead_pair_adjacency(n_leads=n_leads)
        self.register_buffer("static_adj", adj / adj.sum(dim=-1, keepdim=True).clamp(min=1.0))
        self.embed = nn.Sequential(
            nn.Conv1d(1, hidden, kernel_size=7, padding=3, bias=False),
            nn.GELU(),
        )
        self.edge_mlp = nn.Sequential(
            nn.Linear(hidden * 2, hidden),
            nn.GELU(),
            nn.Linear(hidden, 1),
        )
        self.decode = nn.Conv1d(hidden, 1, kernel_size=7, padding=3)
        nn.init.zeros_(self.decode.weight)
        nn.init.zeros_(self.decode.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, n, length = x.shape
        h = self.embed(x.reshape(b * n, 1, length)).reshape(b, n, -1, length).mean(dim=-1)

        hi = h.unsqueeze(2).expand(-1, -1, n, -1)
        hj = h.unsqueeze(1).expand(-1, n, -1, -1)
        edge_in = torch.cat([hi, hj], dim=-1)
        dyn_logits = self.edge_mlp(edge_in).squeeze(-1)
        dyn_adj = torch.softmax(dyn_logits, dim=-1)
        adj = self.anatomical_bias * self.static_adj.unsqueeze(0) + (1.0 - self.anatomical_bias) * dyn_adj

        agg = torch.einsum("bij,bjH->biH", adj, h)
        delta = self.decode(agg.reshape(b * n, -1, 1).expand(-1, -1, length)).reshape(b, n, length)
        return x + self.residual_scale * delta
