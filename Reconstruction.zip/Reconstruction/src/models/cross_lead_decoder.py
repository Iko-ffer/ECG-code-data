"""Cross-lead decoder v2: temporal cross-attention (query=lead, key/value=time)."""

from __future__ import annotations

import torch
import torch.nn as nn


class CrossLeadAttentionDecoder(nn.Module):
    """
    Encode input to (B, C, L), then each of 15 lead queries attends over time.
    Avoids the v1 bug where global pooling removed temporal information.
    """

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 2,
        n_heads: int = 4,
    ) -> None:
        super().__init__()
        self.out_channels = out_channels
        ch = base_channels

        enc: list[nn.Module] = [
            nn.Conv1d(in_channels, ch, kernel_size=7, padding=3, bias=False),
            nn.BatchNorm1d(ch),
            nn.ReLU(inplace=True),
        ]
        for _ in range(depth):
            enc += [
                nn.Conv1d(ch, ch, kernel_size=7, padding=3, bias=False),
                nn.BatchNorm1d(ch),
                nn.ReLU(inplace=True),
            ]
        self.encoder = nn.Sequential(*enc)

        self.lead_queries = nn.Parameter(torch.randn(out_channels, ch) * 0.02)
        self.cross_attn = nn.MultiheadAttention(
            embed_dim=ch,
            num_heads=n_heads,
            dropout=0.1,
            batch_first=True,
        )
        self.norm = nn.LayerNorm(ch)
        self.ff = nn.Sequential(
            nn.Linear(ch, ch * 2),
            nn.GELU(),
            nn.Linear(ch * 2, ch),
        )
        self.wave_head = nn.Conv1d(ch * 2, 1, kernel_size=7, padding=3)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, _, length = x.shape
        h = self.encoder(x)
        h_t = h.permute(0, 2, 1)
        queries = self.lead_queries.unsqueeze(0).expand(b, -1, -1)

        attn_out, _ = self.cross_attn(queries, h_t, h_t)
        attn_out = self.norm(attn_out + queries)
        attn_out = attn_out + self.ff(attn_out)

        outs: list[torch.Tensor] = []
        for i in range(self.out_channels):
            ctx = attn_out[:, i, :].unsqueeze(-1).expand(-1, -1, length)
            fused = torch.cat([h, ctx], dim=1)
            outs.append(self.wave_head(fused))
        return torch.cat(outs, dim=1)
