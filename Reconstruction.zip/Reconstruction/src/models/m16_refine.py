"""M16 literature-inspired refinements: FiLM, multiscale (SPA-lite), delay-ready TCN."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.constants import LEAD_PAIR_TO_INDEX, PHENOMENA
from src.models.film import FiLM1d, PhenomenonEmbedding
from src.models.tcn_unet_refine import LeadRefinerUNet1D, _channel_residual_scales
from src.models.unet_1d import ConvBlock1D


PHENOMENON_TO_ID: dict[str, int] = {p: i for i, p in enumerate(PHENOMENA)}


class LeadRefinerFiLMUNet1D(LeadRefinerUNet1D):
    """U-Net refiner with FiLM after each ConvBlock (phenomenon conditioning)."""

    def __init__(
        self,
        in_channels: int = 15,
        out_channels: int | None = None,
        base_channels: int = 32,
        depth: int = 3,
        cond_dim: int = 32,
    ) -> None:
        super().__init__(in_channels, out_channels, base_channels, depth)
        ch = base_channels
        self.film_downs = nn.ModuleList()
        prev = in_channels
        for i in range(depth):
            out_ch = ch * (2**i)
            self.film_downs.append(FiLM1d(cond_dim, out_ch))
            prev = out_ch
        self.film_bottleneck = FiLM1d(cond_dim, prev * 2)
        self.film_ups = nn.ModuleList()
        dec_prev = prev * 2
        for i in reversed(range(depth)):
            skip_ch = ch * (2**i)
            self.film_ups.append(FiLM1d(cond_dim, skip_ch))
            dec_prev = skip_ch

    def forward(self, y0: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        skips: list[torch.Tensor] = []
        h = y0
        for block, film in zip(self.downs, self.film_downs):
            h = block(h)
            h = film(h, cond)
            skips.append(h)
            h = self.pool(h)
        h = self.bottleneck(h)
        h = self.film_bottleneck(h, cond)
        for up, conv, film, skip in zip(self.ups, self.up_convs, self.film_ups, reversed(skips)):
            h = up(h)
            if h.shape[-1] != skip.shape[-1]:
                diff = skip.shape[-1] - h.shape[-1]
                h = F.pad(h, (diff // 2, diff - diff // 2))
            h = torch.cat([h, skip], dim=1)
            h = conv(h)
            h = film(h, cond)
        return self.head(h)


class LeadRefinerMultiscaleUNet1D(LeadRefinerUNet1D):
    """SPA-lite: parallel multi-kernel conv stem before standard U-Net."""

    def __init__(
        self,
        in_channels: int = 15,
        out_channels: int | None = None,
        base_channels: int = 32,
        depth: int = 3,
        kernel_sizes: tuple[int, ...] = (3, 7, 15, 31),
    ) -> None:
        super().__init__(in_channels, out_channels, base_channels, depth)
        ms_out = base_channels
        branches = []
        for k in kernel_sizes:
            pad = k // 2
            branches.append(
                nn.Sequential(
                    nn.Conv1d(in_channels, ms_out, kernel_size=k, padding=pad),
                    nn.GroupNorm(min(8, ms_out), ms_out),
                    nn.SiLU(),
                )
            )
        self.ms_branches = nn.ModuleList(branches)
        self.ms_fuse = nn.Conv1d(ms_out * len(kernel_sizes), in_channels, kernel_size=1)

    def forward(self, y0: torch.Tensor) -> torch.Tensor:
        ms = torch.cat([b(y0) for b in self.ms_branches], dim=1)
        y0 = y0 + self.ms_fuse(ms)
        return super().forward(y0)


class TCNUNetFiLMRefine(nn.Module):
    """M16b: TCN + FiLM-conditioned U-Net refiner."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        refine_base: int = 32,
        refine_depth: int = 3,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
        num_phenomena: int = 5,
        film_embed_dim: int = 32,
    ) -> None:
        super().__init__()
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.phen_embed = PhenomenonEmbedding(num_phenomena, film_embed_dim)
        self.film_embed_dim = film_embed_dim
        self.refiner = LeadRefinerFiLMUNet1D(
            out_channels, out_channels, refine_base, refine_depth, film_embed_dim
        )
        scales = _channel_residual_scales(
            out_channels, input_lead, residual_scale, residual_scale_hard, residual_scale_rest
        )
        self.register_buffer("channel_scale", scales.view(1, out_channels, 1))
        self.input_idx = LEAD_PAIR_TO_INDEX[input_lead]

    def forward(self, x: torch.Tensor, phen_id: torch.Tensor | None = None) -> torch.Tensor:
        y0 = self.tcn(x)
        if phen_id is None:
            cond = torch.zeros(x.shape[0], self.film_embed_dim, device=x.device)
        else:
            cond = self.phen_embed(phen_id)
        delta = self.refiner(y0, cond)
        return y0 + self.channel_scale * delta


class TCNUNetMultiscaleRefine(nn.Module):
    """M17a: TCN + multiscale (SPA-lite) refiner."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        refine_base: int = 32,
        refine_depth: int = 3,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
    ) -> None:
        super().__init__()
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.refiner = LeadRefinerMultiscaleUNet1D(out_channels, out_channels, refine_base, refine_depth)
        scales = _channel_residual_scales(
            out_channels, input_lead, residual_scale, residual_scale_hard, residual_scale_rest
        )
        self.register_buffer("channel_scale", scales.view(1, out_channels, 1))
        self.input_idx = LEAD_PAIR_TO_INDEX[input_lead]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y0 = self.tcn(x)
        delta = self.refiner(y0)
        return y0 + self.channel_scale * delta
