"""M22: Linear-attention (Performer-style) temporal refiner on TCN coarse output."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.constants import LEAD_PAIR_TO_INDEX
from src.models.tcn_unet_refine import _channel_residual_scales


class LinearAttention1d(nn.Module):
    """FAVOR+-style linear attention over time. Input (B, D, L)."""

    def __init__(self, dim: int, n_heads: int = 4, dropout: float = 0.1) -> None:
        super().__init__()
        assert dim % n_heads == 0
        self.n_heads = n_heads
        self.head_dim = dim // n_heads
        self.scale = self.head_dim**-0.5
        self.qkv = nn.Conv1d(dim, dim * 3, kernel_size=1)
        self.proj = nn.Conv1d(dim, dim, kernel_size=1)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, d, length = x.shape
        qkv = self.qkv(x)
        q, k, v = qkv.chunk(3, dim=1)
        h = self.n_heads
        hd = self.head_dim
        q = q.view(b, h, hd, length).transpose(2, 3)
        k = k.view(b, h, hd, length).transpose(2, 3)
        v = v.view(b, h, hd, length).transpose(2, 3)
        q = F.elu(q) + 1.0
        k = F.elu(k) + 1.0
        kv = torch.matmul(k.transpose(-2, -1), v)
        out = torch.matmul(q, kv)
        normalizer = torch.matmul(q, k.sum(dim=-2, keepdim=True).transpose(-2, -1)).clamp(min=1e-6)
        out = out / normalizer
        out = out.transpose(2, 3).reshape(b, d, length)
        return self.dropout(self.proj(out))


class PerformerBlock1d(nn.Module):
    def __init__(self, dim: int, n_heads: int = 4, mlp_ratio: float = 2.0, dropout: float = 0.1) -> None:
        super().__init__()
        self.norm1 = nn.GroupNorm(min(8, dim), dim)
        self.attn = LinearAttention1d(dim, n_heads, dropout)
        self.norm2 = nn.GroupNorm(min(8, dim), dim)
        hidden = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Conv1d(dim, hidden, kernel_size=1),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Conv1d(hidden, dim, kernel_size=1),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x


class PerformerTemporalRefiner(nn.Module):
    """Downsample -> linear-attention stack -> upsample residual delta."""

    def __init__(
        self,
        n_leads: int = 15,
        dim: int = 128,
        n_heads: int = 4,
        n_layers: int = 4,
        downsample: int = 4,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.downsample = downsample
        self.in_proj = nn.Conv1d(n_leads, dim, kernel_size=7, padding=3)
        self.down = nn.Conv1d(dim, dim, kernel_size=7, stride=downsample, padding=3)
        self.blocks = nn.ModuleList(
            [PerformerBlock1d(dim, n_heads, dropout=dropout) for _ in range(n_layers)]
        )
        self.up = nn.ConvTranspose1d(dim, dim, kernel_size=downsample, stride=downsample)
        self.out_proj = nn.Conv1d(dim, n_leads, kernel_size=7, padding=3)
        nn.init.zeros_(self.out_proj.weight)
        nn.init.zeros_(self.out_proj.bias)

    def forward(self, y0: torch.Tensor) -> torch.Tensor:
        length = y0.shape[-1]
        h = self.in_proj(y0)
        h = self.down(h)
        for block in self.blocks:
            h = block(h)
        h = self.up(h)
        if h.shape[-1] != length:
            diff = length - h.shape[-1]
            h = F.pad(h, (0, max(0, diff)))
            h = h[..., :length]
        return self.out_proj(h)


class TCNPerformerRefine(nn.Module):
    """M22: TCN coarse + Performer-style linear attention refiner."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
        performer_dim: int = 128,
        performer_heads: int = 4,
        performer_layers: int = 4,
        performer_downsample: int = 4,
    ) -> None:
        super().__init__()
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.refiner = PerformerTemporalRefiner(
            n_leads=out_channels,
            dim=performer_dim,
            n_heads=performer_heads,
            n_layers=performer_layers,
            downsample=performer_downsample,
        )
        scales = _channel_residual_scales(
            out_channels, input_lead, residual_scale, residual_scale_hard, residual_scale_rest
        )
        self.register_buffer("channel_scale", scales.view(1, out_channels, 1))
        self.input_idx = LEAD_PAIR_TO_INDEX[input_lead]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y0 = self.tcn(x)
        delta = self.refiner(y0)
        return y0 + self.channel_scale * delta
