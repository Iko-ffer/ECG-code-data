"""M13 generators: coordinate attention, dynamic graph, progressive multi-scale refine."""

from __future__ import annotations

import torch
import torch.nn as nn

from src.losses.wavelet_loss import LowPassFilter1D
from src.models.dynamic_graph_block import DynamicGraphBlock
from src.models.spatial_coord import LeadSpatialCrossAttention
from src.models.tcn_unet_refine import LeadRefinerUNet1D, _channel_residual_scales


class LeadRefinerUNet1DEnhanced(nn.Module):
    """U-Net refiner with optional coord cross-attn and dynamic graph at input + bottleneck."""

    def __init__(
        self,
        in_channels: int = 15,
        out_channels: int | None = None,
        base_channels: int = 32,
        depth: int = 3,
        input_lead: str = "V2-V5",
        use_coord_attn: bool = False,
        use_dyn_graph: bool = False,
        coord_token_dim: int = 32,
        dyn_graph_hidden: int = 32,
        anatomical_bias: float = 0.7,
    ) -> None:
        super().__init__()
        out_channels = in_channels if out_channels is None else out_channels
        self.use_coord_attn = use_coord_attn
        self.use_dyn_graph = use_dyn_graph
        self.unet = LeadRefinerUNet1D(in_channels, out_channels, base_channels, depth)
        n_leads = 15
        if use_coord_attn:
            self.coord_in = LeadSpatialCrossAttention(
                n_leads=n_leads,
                token_dim=coord_token_dim,
                input_lead=input_lead,
            )
            self.coord_bn = LeadSpatialCrossAttention(
                n_leads=n_leads,
                token_dim=coord_token_dim,
                input_lead=input_lead,
            )
        if use_dyn_graph:
            self.dyn_in = DynamicGraphBlock(
                n_leads=n_leads,
                hidden=dyn_graph_hidden,
                anatomical_bias=anatomical_bias,
            )
            self.dyn_bn = DynamicGraphBlock(
                n_leads=n_leads,
                hidden=dyn_graph_hidden,
                anatomical_bias=anatomical_bias,
            )

    def _spatial_preprocess(self, y0: torch.Tensor, stage: str) -> torch.Tensor:
        h = y0
        if self.use_coord_attn:
            h = self.coord_in(h) if stage == "in" else self.coord_bn(h)
        if self.use_dyn_graph:
            h = self.dyn_in(h) if stage == "in" else self.dyn_bn(h)
        return h

    def forward(self, y0: torch.Tensor) -> torch.Tensor:
        if not self.use_coord_attn and not self.use_dyn_graph:
            return self.unet(y0)
        enhanced = self._spatial_preprocess(y0, "in")
        return self.unet(enhanced)


class _TCNRefineBase(nn.Module):
    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        refine_base: int = 32,
        refine_depth: int = 3,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
        **refiner_kw,
    ) -> None:
        super().__init__()
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.refiner = LeadRefinerUNet1DEnhanced(
            out_channels,
            out_channels,
            refine_base,
            refine_depth,
            input_lead=input_lead,
            **refiner_kw,
        )
        scales = _channel_residual_scales(
            out_channels,
            input_lead,
            residual_scale,
            residual_scale_hard,
            residual_scale_rest,
        )
        self.register_buffer("channel_scale", scales.view(1, out_channels, 1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y0 = self.tcn(x)
        delta = self.refiner(y0)
        return y0 + self.channel_scale * delta


class TCNCoordUNetRefine(_TCNRefineBase):
    """M13a: TCN + coord-attention U-Net refiner."""

    def __init__(self, **kwargs) -> None:
        kwargs.setdefault("use_coord_attn", True)
        kwargs.setdefault("use_dyn_graph", False)
        super().__init__(**kwargs)


class TCNDynGraphUNetRefine(_TCNRefineBase):
    """M13c: TCN + dynamic graph U-Net refiner."""

    def __init__(self, **kwargs) -> None:
        kwargs.setdefault("use_coord_attn", False)
        kwargs.setdefault("use_dyn_graph", True)
        super().__init__(**kwargs)


class TCNCoordDynUNetRefine(_TCNRefineBase):
    """M13ac: coord attention + dynamic graph."""

    def __init__(self, **kwargs) -> None:
        kwargs.setdefault("use_coord_attn", True)
        kwargs.setdefault("use_dyn_graph", True)
        super().__init__(**kwargs)


class TCNProgressiveRefine(nn.Module):
    """
    M13b: two-stage refine — low-frequency skeleton then high-frequency residual.
    Stage 1 trains low_refiner; stage 2 freezes low and trains high_refiner (+ GAN on high).
    """

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        refine_base: int = 32,
        refine_depth: int = 3,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
        use_coord_attn: bool = False,
        lowpass_kernel: int = 31,
        high_includes_input: bool = True,
        **refiner_kw,
    ) -> None:
        super().__init__()
        from src.models.tcn_1d import TCNGenerator

        self.out_channels = out_channels
        self.use_coord_attn = use_coord_attn
        self.high_includes_input = high_includes_input
        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.low_refiner = LeadRefinerUNet1DEnhanced(
            out_channels,
            out_channels,
            refine_base,
            refine_depth,
            input_lead=input_lead,
            use_coord_attn=use_coord_attn,
            use_dyn_graph=False,
            **{k: v for k, v in refiner_kw.items() if k in ("coord_token_dim",)},
        )
        high_in_ch = out_channels + (1 if high_includes_input else 0)
        self.high_refiner = LeadRefinerUNet1D(high_in_ch, out_channels, refine_base, refine_depth)
        self.lowpass = LowPassFilter1D(lowpass_kernel)
        scales = _channel_residual_scales(
            out_channels,
            input_lead,
            residual_scale,
            residual_scale_hard,
            residual_scale_rest,
        )
        self.register_buffer("channel_scale", scales.view(1, out_channels, 1))
        self.register_buffer("high_scale", torch.tensor(float(residual_scale)))

    def forward_low(self, x: torch.Tensor) -> torch.Tensor:
        y0 = self.tcn(x)
        delta_low = self.low_refiner(y0)
        return y0 + self.channel_scale * delta_low

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y_low = self.forward_low(x)
        if self.high_includes_input:
            high_in = torch.cat([y_low, x], dim=1)
        else:
            high_in = y_low
        delta_high = self.high_refiner(high_in)
        return y_low + self.high_scale * delta_high

    def high_pass_output(self, x: torch.Tensor) -> torch.Tensor:
        y = self.forward(x)
        return y - self.lowpass(y)


class TCNCoordProgressiveRefine(TCNProgressiveRefine):
    """M13ab: coord attention + progressive two-stage."""

    def __init__(self, **kwargs) -> None:
        kwargs.setdefault("use_coord_attn", True)
        super().__init__(**kwargs)
