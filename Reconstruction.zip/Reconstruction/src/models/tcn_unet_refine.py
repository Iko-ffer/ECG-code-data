"""TCN coarse reconstruction + U-Net / chest-latent residual refinement."""

from __future__ import annotations

import torch
import torch.nn as nn

from src.constants import LEAD_PAIR_TO_INDEX, VIRTUAL_LEAD_PAIRS
from src.lead_space import HARD_LEADS_V2V5, chest_delta_to_pair_delta
from src.models.unet_1d import ConvBlock1D


class LeadRefinerUNet1D(nn.Module):
    """Small U-Net: (B, in_ch, L) -> (B, out_ch, L), zero-init head."""

    def __init__(
        self,
        in_channels: int = 15,
        out_channels: int | None = None,
        base_channels: int = 32,
        depth: int = 3,
    ) -> None:
        super().__init__()
        out_channels = in_channels if out_channels is None else out_channels
        self.depth = depth
        ch = base_channels

        self.downs = nn.ModuleList()
        prev = in_channels
        for i in range(depth):
            out_ch = ch * (2**i)
            self.downs.append(ConvBlock1D(prev, out_ch))
            prev = out_ch
        self.pool = nn.MaxPool1d(2)

        self.bottleneck = ConvBlock1D(prev, prev * 2, dropout=0.1)

        self.ups = nn.ModuleList()
        self.up_convs = nn.ModuleList()
        dec_prev = prev * 2
        for i in reversed(range(depth)):
            skip_ch = ch * (2**i)
            self.ups.append(nn.ConvTranspose1d(dec_prev, skip_ch, kernel_size=2, stride=2))
            self.up_convs.append(ConvBlock1D(skip_ch * 2, skip_ch))
            dec_prev = skip_ch

        self.head = nn.Conv1d(dec_prev, out_channels, kernel_size=1)
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    def forward(self, y0: torch.Tensor) -> torch.Tensor:
        skips: list[torch.Tensor] = []
        h = y0
        for block in self.downs:
            h = block(h)
            skips.append(h)
            h = self.pool(h)

        h = self.bottleneck(h)

        for up, conv, skip in zip(self.ups, self.up_convs, reversed(skips)):
            h = up(h)
            if h.shape[-1] != skip.shape[-1]:
                diff = skip.shape[-1] - h.shape[-1]
                h = nn.functional.pad(h, (diff // 2, diff - diff // 2))
            h = torch.cat([h, skip], dim=1)
            h = conv(h)

        return self.head(h)


def _channel_residual_scales(
    out_channels: int,
    input_lead: str,
    residual_scale: float,
    residual_scale_hard: float | None,
    residual_scale_rest: float | None,
) -> torch.Tensor:
    scales = torch.full((out_channels,), float(residual_scale), dtype=torch.float32)
    if residual_scale_hard is None and residual_scale_rest is None:
        return scales
    rest = float(residual_scale_rest if residual_scale_rest is not None else residual_scale)
    hard = float(residual_scale_hard if residual_scale_hard is not None else residual_scale)
    scales.fill_(rest)
    input_idx = LEAD_PAIR_TO_INDEX[input_lead]
    for pair in HARD_LEADS_V2V5:
        if pair in LEAD_PAIR_TO_INDEX:
            idx = LEAD_PAIR_TO_INDEX[pair]
            if idx != input_idx:
                scales[idx] = hard
    return scales


class TCNUNetRefine(nn.Module):
    """M2 TCN coarse + U-Net residual on 15 lead channels."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        refine_base: int = 32,
        refine_depth: int = 3,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
        use_polarity_head: bool = False,
    ) -> None:
        super().__init__()
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.refiner = LeadRefinerUNet1D(out_channels, out_channels, refine_base, refine_depth)
        scales = _channel_residual_scales(
            out_channels,
            input_lead,
            residual_scale,
            residual_scale_hard,
            residual_scale_rest,
        )
        self.register_buffer("channel_scale", scales.view(1, out_channels, 1))
        self.input_idx = LEAD_PAIR_TO_INDEX[input_lead]
        self.polarity_head: nn.Module | None = None
        if use_polarity_head:
            from src.models.polarity_head import ChannelPolarityHead

            self.polarity_head = ChannelPolarityHead(out_channels, input_idx=self.input_idx)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y0 = self.tcn(x)
        delta = self.refiner(y0)
        y = y0 + self.channel_scale * delta
        if self.polarity_head is not None:
            y = self.polarity_head(y)
        return y


class TCNUNetChestRefine(nn.Module):
    """M2 TCN + refiner predicts Δ on 6 chest leads, mapped to 15 pairs via analytic M."""

    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 15,
        base_channels: int = 64,
        depth: int = 4,
        refine_base: int = 32,
        refine_depth: int = 3,
        residual_scale: float = 0.05,
        residual_scale_hard: float | None = None,
        residual_scale_rest: float | None = None,
        input_lead: str = "V2-V5",
    ) -> None:
        super().__init__()
        from src.models.tcn_1d import TCNGenerator

        self.tcn = TCNGenerator(in_channels, out_channels, base_channels, depth)
        self.refiner = LeadRefinerUNet1D(out_channels, 6, refine_base, refine_depth)
        scales = _channel_residual_scales(
            out_channels,
            input_lead,
            residual_scale,
            residual_scale_hard,
            residual_scale_rest,
        )
        self.register_buffer("channel_scale", scales.view(1, out_channels, 1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y0 = self.tcn(x)
        delta_chest = self.refiner(y0)
        delta_15 = chest_delta_to_pair_delta(delta_chest)
        return y0 + self.channel_scale * delta_15
