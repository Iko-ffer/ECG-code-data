"""Post-process generator outputs: copy input lead channel from source."""

from __future__ import annotations

import torch
import torch.nn as nn


def skip_input_waveform(x: torch.Tensor, center_idx: int = 0) -> torch.Tensor:
    """Extract (B, 1, L) skip channel from delay-stack or single-channel input."""
    if x.shape[1] == 1:
        return x
    return x[:, center_idx : center_idx + 1]


def generator_forward(generator: nn.Module, x: torch.Tensor, batch: dict) -> torch.Tensor:
    """Dispatch FiLM / phenomenon-conditioned generator forward."""
    from src.models.m16_refine import PHENOMENON_TO_ID, TCNUNetFiLMRefine
    from src.models.m21_bw_ode import PHENOMENON_TO_ID as M21_PHEN_ID, TCNLatentODERefine
    from src.models.m24_performer_stgcn_ode import TCNPerformerSTGCNODERefine
    from src.models.m25_full_model import TCNPerformerM25FullRefine
    from src.models.m25_performer_stgcn_ode import TCNPerformerAnatomySTGCNODERefine
    from src.models.m9_attn_refine import (
        TCNAttnUNetRefine,
        TCNPerformerAttnUNetReplaceRefine,
        TCNPerformerODEAttnParallelFullRefine,
        TCNPerformerODEAttnParallelRefine,
        UNetPerformerODEAttnParallelFullRefine,
    )
    from src.models.m27_ekgan import TCNPerformerODEAttnEKGAN

    if isinstance(
        generator,
        (
            TCNUNetFiLMRefine,
            TCNLatentODERefine,
            TCNPerformerSTGCNODERefine,
            TCNPerformerAnatomySTGCNODERefine,
            TCNPerformerM25FullRefine,
            TCNAttnUNetRefine,
            TCNPerformerAttnUNetReplaceRefine,
            TCNPerformerODEAttnParallelRefine,
            TCNPerformerODEAttnParallelFullRefine,
            UNetPerformerODEAttnParallelFullRefine,
            TCNPerformerODEAttnEKGAN,
        ),
    ):
        phen_map = M21_PHEN_ID if isinstance(
            generator,
            (
                TCNLatentODERefine,
                TCNPerformerSTGCNODERefine,
                TCNPerformerAnatomySTGCNODERefine,
                TCNPerformerM25FullRefine,
                TCNAttnUNetRefine,
                TCNPerformerAttnUNetReplaceRefine,
                TCNPerformerODEAttnParallelRefine,
                TCNPerformerODEAttnParallelFullRefine,
                UNetPerformerODEAttnParallelFullRefine,
                TCNPerformerODEAttnEKGAN,
            ),
        ) else PHENOMENON_TO_ID
        phen_id = torch.tensor(
            [phen_map[str(p)] for p in batch["phenomenon"]],
            device=x.device,
            dtype=torch.long,
        )
        return generator(x, phen_id)
    return generator(x)


def merge_input_channel(
    pred: torch.Tensor,
    x_input: torch.Tensor,
    input_idx: int,
) -> torch.Tensor:
    """
    Replace the input virtual-lead channel with the source waveform.

    pred:    (B, 15, L)
    x_input: (B, 1, L)
    """
    out = pred.clone()
    out[:, input_idx : input_idx + 1] = x_input
    return out


def non_input_channel_indices(num_channels: int, input_idx: int) -> list[int]:
    return [i for i in range(num_channels) if i != input_idx]
