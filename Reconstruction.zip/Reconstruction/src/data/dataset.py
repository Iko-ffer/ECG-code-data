"""PyTorch dataset: 1 virtual lead pair -> 15 virtual lead pairs."""

from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import scipy.io as sio
import torch
from torch.utils.data import DataLoader, Dataset

from src.constants import LEAD_PAIR_TO_INDEX, VIRTUAL_LEAD_PAIRS
from src.data.delay_embed import delay_stack_1d
from src.data.indexing import (
    IndexStats,
    WindowSample,
    format_index_stats,
    index_windows_with_stats,
)

logger = logging.getLogger(__name__)

# Common variable names in preprocessed .mat exports.
_CANDIDATE_KEYS = (
    "ecg",
    "ECG",
    "signal",
    "data",
    "val",
    "segment",
    "x",
    "X",
    "waveform",
)


def load_signal_from_mat(path: Path) -> np.ndarray:
    """Load a 1D float waveform from a .mat file."""
    raw = sio.loadmat(path)
    best: np.ndarray | None = None
    best_size = 0

    for key, value in raw.items():
        if key.startswith("_"):
            continue
        if not isinstance(value, np.ndarray) or not np.issubdtype(value.dtype, np.number):
            continue
        arr = np.asarray(value, dtype=np.float32).squeeze()
        if arr.ndim != 1:
            continue
        if key in _CANDIDATE_KEYS:
            return arr
        if arr.size > best_size:
            best = arr
            best_size = arr.size

    if best is None:
        raise ValueError(f"No 1D numeric waveform found in {path}")
    return best


def fix_length(signal: np.ndarray, length: int) -> np.ndarray:
    if signal.shape[0] == length:
        return signal
    if signal.shape[0] > length:
        start = (signal.shape[0] - length) // 2
        return signal[start : start + length]
    pad = length - signal.shape[0]
    left = pad // 2
    right = pad - left
    return np.pad(signal, (left, right), mode="constant")


def zscore(x: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    std = float(x.std())
    if std < eps:
        return x - float(x.mean())
    return (x - float(x.mean())) / std


class VirtualLeadReconstructionDataset(Dataset):
    """
    Each item:
      input:  (1, L)  selected virtual lead pair
      target: (15, L) all virtual lead pairs in fixed order
    """

    def __init__(
        self,
        data_root: str | Path,
        split: str = "train",
        phenomena: list[str] | None = None,
        labels: list[int] | None = None,
        input_lead: str = "V1-V5",
        signal_length: int = 2500,
        normalize: bool = True,
        anchor_lead: str = "V1-V2",
        dedupe: bool | None = None,
        delay_lags: tuple[int, ...] | list[int] | None = None,
    ) -> None:
        self.data_root = Path(data_root)
        self.input_lead = input_lead
        self.signal_length = signal_length
        self.normalize = normalize
        self.input_index = LEAD_PAIR_TO_INDEX[input_lead]
        self.split = split
        self.delay_lags = tuple(delay_lags) if delay_lags else None
        self.delay_center_index = (
            self.delay_lags.index(0) if self.delay_lags and 0 in self.delay_lags else 0
        )

        if phenomena is None:
            from src.constants import PHENOMENA

            phenomena = PHENOMENA
        if labels is None:
            labels = [0, 1]
        if dedupe is None:
            # Train: dedupe shared normal windows across 5 phenomenon folders.
            # Test: keep per-phenomenon copies for stratified downstream eval.
            dedupe = split == "train"

        self.dedupe = dedupe
        self.samples, self.index_stats = index_windows_with_stats(
            self.data_root,
            phenomena=phenomena,
            split=split,
            labels=labels,
            anchor_lead=anchor_lead,
            dedupe=dedupe,
        )
        logger.info(
            format_index_stats(self.index_stats, split=split, dedupe=dedupe)
        )
        if not self.samples:
            raise RuntimeError(
                f"No complete 15-lead windows found under {self.data_root} "
                f"(split={split}). Run scripts/inspect_mat.py to verify layout."
            )

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> dict[str, torch.Tensor | str | int]:
        sample: WindowSample = self.samples[idx]
        targets = []
        for lead in VIRTUAL_LEAD_PAIRS:
            sig = load_signal_from_mat(sample.paths[lead])
            sig = fix_length(sig, self.signal_length)
            if self.normalize:
                sig = zscore(sig)
            targets.append(sig)

        target = np.stack(targets, axis=0).astype(np.float32)
        x1 = target[self.input_index : self.input_index + 1].copy()
        if self.delay_lags:
            x = delay_stack_1d(x1[0], self.delay_lags)
        else:
            x = x1

        return {
            "input": torch.from_numpy(x),
            "target": torch.from_numpy(target),
            "input_lead": self.input_lead,
            "phenomenon": sample.key.phenomenon,
            "label": sample.key.label,
            "group_id": sample.key.group_id,
        }


def build_dataloader(
    data_root: str | Path,
    split: str,
    batch_size: int,
    num_workers: int,
    input_lead: str,
    signal_length: int,
    phenomena: list[str] | None = None,
    labels: list[int] | None = None,
    shuffle: bool = True,
    dedupe: bool | None = None,
    delay_lags: tuple[int, ...] | list[int] | None = None,
) -> DataLoader:
    ds = VirtualLeadReconstructionDataset(
        data_root=data_root,
        split=split,
        phenomena=phenomena,
        labels=labels,
        input_lead=input_lead,
        signal_length=signal_length,
        dedupe=dedupe,
        delay_lags=delay_lags,
    )
    return DataLoader(
        ds,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=(split == "train"),
    )
