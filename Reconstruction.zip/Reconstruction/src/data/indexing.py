"""Index 5s window groups that have all 15 virtual lead pair .mat files."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from src.constants import VIRTUAL_LEAD_PAIRS

# A0024_V1-V4_1.mat or JS00051_v1-v2_1.mat -> record id, lead pair, window
FNAME_RE = re.compile(r"^([A-Za-z]+\d+)_([Vv]\d+-[Vv]\d+)_(\d+)\.mat$", re.IGNORECASE)


def normalize_lead_pair(name: str) -> str:
    """Canonical V1-V2 style from v1-v2 or V1-V2."""
    parts = name.split("-")
    return f"{parts[0].upper()}-{parts[1].upper()}"


def lead_dir_candidates(lead: str) -> tuple[str, ...]:
    canonical = normalize_lead_pair(lead)
    lo, hi = canonical.split("-")
    lower = f"{lo.lower()}-{hi.lower()}"
    if lower == canonical:
        return (canonical,)
    return (canonical, lower)


@dataclass(frozen=True)
class WindowKey:
    phenomenon: str
    split: str
    label: int
    record_id: str
    window_idx: int

    @property
    def group_id(self) -> str:
        return f"{self.record_id}_{self.window_idx}"

    @property
    def dedupe_id(self) -> tuple[str, str, int]:
        """Unique physical window across phenomenon folders (normal is duplicated)."""
        return (self.record_id, self.split, self.window_idx)


@dataclass
class WindowSample:
    key: WindowKey
    paths: dict[str, Path]  # lead_pair -> .mat path


@dataclass
class IndexStats:
    raw_total: int = 0
    deduped_total: int = 0
    removed_duplicates: int = 0
    by_label: dict[int, int] = field(default_factory=dict)
    by_phenomenon: dict[str, int] = field(default_factory=dict)
    positive_by_phenomenon: dict[str, int] = field(default_factory=dict)


def parse_mat_filename(path: Path) -> tuple[str, str, int] | None:
    m = FNAME_RE.match(path.name)
    if not m:
        return None
    return m.group(1), normalize_lead_pair(m.group(2)), int(m.group(3))


def _resolve_lead_dir(data_root: Path, phenomenon: str, lead: str) -> Path | None:
    for variant in lead_dir_candidates(lead):
        p = data_root / phenomenon / variant
        if p.is_dir():
            return p
    return None


def _build_sample(
    data_root: Path,
    phenomenon: str,
    split: str,
    label: int,
    record_id: str,
    window_idx: int,
) -> WindowSample | None:
    paths: dict[str, Path] = {}
    for lead in VIRTUAL_LEAD_PAIRS:
        lead_root = _resolve_lead_dir(data_root, phenomenon, lead)
        if lead_root is None:
            return None
        # Filename lead token matches dataset convention (lower or upper).
        dir_token = lead_root.name
        p = lead_root / split / str(label) / f"{record_id}_{dir_token}_{window_idx}.mat"
        if not p.is_file():
            return None
        paths[lead] = p
    key = WindowKey(
        phenomenon=phenomenon,
        split=split,
        label=label,
        record_id=record_id,
        window_idx=window_idx,
    )
    return WindowSample(key=key, paths=paths)


def index_windows(
    data_root: Path,
    phenomena: list[str],
    split: str,
    labels: list[int],
    anchor_lead: str = "V1-V2",
    dedupe: bool = False,
) -> list[WindowSample]:
    """
    Enumerate windows using one anchor lead directory, then verify all 15 pairs exist.

    Expected layout:
      {root}/{phenomenon}/{lead_pair}/{split}/{label}/{record}_{lead}_{win}.mat

    When dedupe=True (recommended for train):
      Collapse repeated normal windows that appear in multiple phenomenon folders.
      Unique key: (record_id, split, window_idx).
      If duplicates conflict, label=1 (phenomenon-positive) wins over label=0.
    """
    samples: list[WindowSample] = []

    for phenomenon in phenomena:
        anchor_dir = _resolve_lead_dir(data_root, phenomenon, anchor_lead)
        if anchor_dir is None:
            continue
        anchor_dir = anchor_dir / split
        if not anchor_dir.is_dir():
            continue

        for label in labels:
            label_dir = anchor_dir / str(label)
            if not label_dir.is_dir():
                continue

            for mat_path in sorted(label_dir.glob("*.mat")):
                parsed = parse_mat_filename(mat_path)
                if parsed is None:
                    continue
                record_id, _, window_idx = parsed
                sample = _build_sample(
                    data_root, phenomenon, split, label, record_id, window_idx
                )
                if sample is not None:
                    samples.append(sample)

    if dedupe:
        samples = dedupe_window_samples(samples)
    return samples


def dedupe_window_samples(samples: list[WindowSample]) -> list[WindowSample]:
    """Keep one sample per physical window; prefer arrhythmia-positive (label=1)."""
    kept: dict[tuple[str, str, int], WindowSample] = {}
    for sample in samples:
        uid = sample.key.dedupe_id
        if uid not in kept:
            kept[uid] = sample
            continue
        current = kept[uid]
        # Positive windows are phenomenon-specific; normal windows are duplicated across folders.
        if sample.key.label == 1 and current.key.label == 0:
            kept[uid] = sample
    return sorted(
        kept.values(),
        key=lambda s: (s.key.record_id, s.key.window_idx, s.key.phenomenon, s.key.label),
    )


def summarize_index(samples: list[WindowSample], raw_total: int | None = None) -> IndexStats:
    stats = IndexStats(
        raw_total=raw_total if raw_total is not None else len(samples),
        deduped_total=len(samples),
        removed_duplicates=(raw_total - len(samples)) if raw_total is not None else 0,
    )
    for sample in samples:
        stats.by_label[sample.key.label] = stats.by_label.get(sample.key.label, 0) + 1
        stats.by_phenomenon[sample.key.phenomenon] = (
            stats.by_phenomenon.get(sample.key.phenomenon, 0) + 1
        )
        if sample.key.label == 1:
            p = sample.key.phenomenon
            stats.positive_by_phenomenon[p] = stats.positive_by_phenomenon.get(p, 0) + 1
    return stats


def index_windows_with_stats(
    data_root: Path,
    phenomena: list[str],
    split: str,
    labels: list[int],
    anchor_lead: str = "V1-V2",
    dedupe: bool = False,
) -> tuple[list[WindowSample], IndexStats]:
    raw_samples: list[WindowSample] = []

    for phenomenon in phenomena:
        anchor_dir = _resolve_lead_dir(data_root, phenomenon, anchor_lead)
        if anchor_dir is None:
            continue
        anchor_dir = anchor_dir / split
        if not anchor_dir.is_dir():
            continue
        for label in labels:
            label_dir = anchor_dir / str(label)
            if not label_dir.is_dir():
                continue
            for mat_path in sorted(label_dir.glob("*.mat")):
                parsed = parse_mat_filename(mat_path)
                if parsed is None:
                    continue
                record_id, _, window_idx = parsed
                sample = _build_sample(
                    data_root, phenomenon, split, label, record_id, window_idx
                )
                if sample is not None:
                    raw_samples.append(sample)

    raw_total = len(raw_samples)
    final = dedupe_window_samples(raw_samples) if dedupe else raw_samples
    stats = summarize_index(final, raw_total=raw_total if dedupe else None)
    if not dedupe:
        stats.raw_total = len(final)
        stats.deduped_total = len(final)
    return final, stats


def format_index_stats(stats: IndexStats, split: str, dedupe: bool) -> str:
    lines = [
        f"[Exp4 index] split={split} dedupe={dedupe}",
        f"  windows: {stats.deduped_total}"
        + (f" (removed {stats.removed_duplicates} duplicates from {stats.raw_total})" if dedupe else ""),
        f"  by label: {dict(sorted(stats.by_label.items()))}",
        f"  by phenomenon: {dict(sorted(stats.by_phenomenon.items()))}",
        f"  positive by phenomenon: {dict(sorted(stats.positive_by_phenomenon.items()))}",
    ]
    return "\n".join(lines)
