"""Takens-style delay coordinate stacking for 1D input waveforms."""

from __future__ import annotations

import numpy as np
import torch


def delay_stack_1d(
    x: np.ndarray,
    lags: tuple[int, ...] = (-4, -2, 0, 2, 4),
) -> np.ndarray:
    """
    x: (L,) -> (len(lags), L) with edge replication padding.
    lag=0 is center channel.
    """
    length = x.shape[0]
    out = np.empty((len(lags), length), dtype=np.float32)
    for i, lag in enumerate(lags):
        if lag == 0:
            out[i] = x
            continue
        if lag > 0:
            pad = np.full(lag, x[-1], dtype=np.float32)
            out[i] = np.concatenate([x[lag:], pad])
        else:
            k = -lag
            pad = np.full(k, x[0], dtype=np.float32)
            out[i] = np.concatenate([pad, x[:-k]])
    return out


def delay_stack_batch(x: torch.Tensor, lags: tuple[int, ...]) -> torch.Tensor:
    """x: (B, 1, L) -> (B, len(lags), L)."""
    arrs = [delay_stack_1d(x[b, 0].cpu().numpy(), lags) for b in range(x.shape[0])]
    return torch.from_numpy(np.stack(arrs, axis=0)).to(device=x.device, dtype=x.dtype)
