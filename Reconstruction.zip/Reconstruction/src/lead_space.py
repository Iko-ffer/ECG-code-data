"""Chest lead geometry for virtual pair distances and analytic 15-pair synthesis."""

from __future__ import annotations

import torch

from src.constants import VIRTUAL_LEAD_PAIRS


def parse_chest_index(lead_name: str) -> int:
    """V1 -> 0, V6 -> 5."""
    return int(lead_name[1]) - 1


def parse_pair(name: str) -> tuple[int, int]:
    a, b = name.split("-")
    return parse_chest_index(a), parse_chest_index(b)


def diffs_from_chest(chest: torch.Tensor) -> torch.Tensor:
    """
    chest: (B, 6, L) waveforms V1..V6
    returns: (B, 15, L) virtual pairwise differences in VIRTUAL_LEAD_PAIRS order
    """
    parts: list[torch.Tensor] = []
    for pair in VIRTUAL_LEAD_PAIRS:
        i, j = parse_pair(pair)
        parts.append(chest[:, i] - chest[:, j])
    return torch.stack(parts, dim=1)


def pair_spatial_distance(pair: str, input_lead: str) -> int:
    """
    Distance between two virtual lead pairs on the V1–V6 chain.
    Uses sum of endpoint offsets (larger => harder / more distant pairs).
    """
    i, j = parse_pair(pair)
    si, sj = parse_pair(input_lead)
    lo_p, hi_p = min(i, j), max(i, j)
    lo_i, hi_i = min(si, sj), max(si, sj)
    return abs(hi_p - hi_i) + abs(lo_p - lo_i)


def spatial_band(pair: str, input_lead: str) -> str:
    d = pair_spatial_distance(pair, input_lead)
    if d <= 2:
        return "near"
    if d <= 3:
        return "mid"
    return "far"


# Fixed hard pairs for V2-V5 input (paper reporting)
HARD_LEADS_V2V5: tuple[str, ...] = ("V1-V2", "V4-V5", "V4-V6", "V5-V6")


def band_channel_indices(input_lead: str) -> dict[str, list[int]]:
    bands: dict[str, list[int]] = {"near": [], "mid": [], "far": []}
    for i, pair in enumerate(VIRTUAL_LEAD_PAIRS):
        bands[spatial_band(pair, input_lead)].append(i)
    return bands


def channel_loss_weights(
    input_lead: str,
    num_channels: int = 15,
    input_idx: int | None = None,
    scale: float = 1.0,
) -> torch.Tensor:
    """
    Per-channel L1 weights (higher for spatially distant pairs).
    Returns shape (num_channels,).
    """
    from src.constants import LEAD_PAIR_TO_INDEX

    if input_idx is None:
        input_idx = LEAD_PAIR_TO_INDEX[input_lead]
    w = torch.ones(num_channels, dtype=torch.float32)
    for i, pair in enumerate(VIRTUAL_LEAD_PAIRS):
        if i == input_idx:
            continue
        d = pair_spatial_distance(pair, input_lead)
        w[i] = 1.0 + scale * float(d)
    return w


def non_input_channel_weights(
    input_lead: str,
    input_idx: int,
    scale: float = 1.0,
) -> torch.Tensor:
    """Weights for non-input channels only, shape (14,)."""
    full = channel_loss_weights(input_lead, input_idx=input_idx, scale=scale)
    return torch.tensor(
        [float(full[i]) for i in range(len(VIRTUAL_LEAD_PAIRS)) if i != input_idx],
        dtype=torch.float32,
    )


def hard_band_channel_indices(input_lead: str) -> dict[str, list[int]]:
    """Task-oriented bands: hard reconstruction pairs vs the rest (non-input)."""
    from src.constants import LEAD_PAIR_TO_INDEX

    input_idx = LEAD_PAIR_TO_INDEX[input_lead]
    hard_set = {LEAD_PAIR_TO_INDEX[p] for p in HARD_LEADS_V2V5 if p in LEAD_PAIR_TO_INDEX}
    hard = sorted(i for i in hard_set if i != input_idx)
    rest = sorted(i for i in range(len(VIRTUAL_LEAD_PAIRS)) if i != input_idx and i not in hard_set)
    return {"hard": hard, "rest": rest}


def pairwise_diff_matrix(device: torch.device | None = None) -> torch.Tensor:
    """
    Fixed (15, 6) matrix M: virtual_pair = M @ chest, chest order V1..V6.
    Row i: +1 at electrode j, -1 at electrode k for VIRTUAL_LEAD_PAIRS[i] = Vj-Vk.
    """
    m = torch.zeros(len(VIRTUAL_LEAD_PAIRS), 6, dtype=torch.float32)
    for i, pair in enumerate(VIRTUAL_LEAD_PAIRS):
        a, b = parse_pair(pair)
        m[i, a] = 1.0
        m[i, b] = -1.0
    if device is not None:
        m = m.to(device)
    return m


def chest_delta_to_pair_delta(delta_chest: torch.Tensor) -> torch.Tensor:
    """delta_chest (B, 6, L) -> (B, 15, L) via analytic pairwise differences."""
    m = pairwise_diff_matrix(device=delta_chest.device)
    return torch.einsum("pc,bcl->bpl", m, delta_chest)


def _pair_index(pair: str) -> int:
    return VIRTUAL_LEAD_PAIRS.index(pair)


def _signed_pair_coeff(chest_hi: int, chest_lo: int, pair_name: str) -> float:
    """Coefficient for (V_hi - V_lo) term in cycle sum."""
    a, b = parse_pair(pair_name)
    if (a, b) == (chest_hi, chest_lo):
        return 1.0
    if (a, b) == (chest_lo, chest_hi):
        return -1.0
    return 0.0


def kirchhoff_cycle_matrix(device: torch.device | None = None) -> torch.Tensor:
    """
    Build cycle constraint matrix C (n_cycles, 15): violation = C @ y at each time.
    For each chest triangle i<j<k: (Vi-Vj)+(Vj-Vk)-(Vi-Vk)=0 in pair space.
    """
    rows: list[list[float]] = []
    n_pairs = len(VIRTUAL_LEAD_PAIRS)
    for i in range(6):
        for j in range(i + 1, 6):
            for k in range(j + 1, 6):
                row = [0.0] * n_pairs
                for pidx, pair in enumerate(VIRTUAL_LEAD_PAIRS):
                    row[pidx] += _signed_pair_coeff(i, j, pair)
                    row[pidx] += _signed_pair_coeff(j, k, pair)
                    row[pidx] -= _signed_pair_coeff(i, k, pair)
                if max(abs(v) for v in row) > 0.5:
                    rows.append(row)
    c = torch.tensor(rows, dtype=torch.float32)
    if device is not None:
        c = c.to(device)
    return c


def kirchhoff_violation(y: torch.Tensor, cycle_matrix: torch.Tensor | None = None) -> torch.Tensor:
    """y: (B, 15, L) -> violations (B, n_cycles, L)."""
    if cycle_matrix is None:
        cycle_matrix = kirchhoff_cycle_matrix(device=y.device)
    return torch.einsum("cp,bpt->bct", cycle_matrix, y)


def chest_pinv_matrix(device: torch.device | None = None) -> torch.Tensor:
    """(6, 15) pseudo-inverse: chest = pinv @ pairs."""
    m = pairwise_diff_matrix(device=device)
    return torch.linalg.pinv(m)


def hard_focused_channel_weights(
    input_lead: str,
    input_idx: int | None = None,
    hard_scale: float = 3.0,
) -> torch.Tensor:
    """Non-input channel weights: hard leads get hard_scale, others 1.0."""
    from src.constants import LEAD_PAIR_TO_INDEX

    if input_idx is None:
        input_idx = LEAD_PAIR_TO_INDEX[input_lead]
    hard_set = set(HARD_LEADS_V2V5)
    weights: list[float] = []
    for i, pair in enumerate(VIRTUAL_LEAD_PAIRS):
        if i == input_idx:
            continue
        weights.append(hard_scale if pair in hard_set else 1.0)
    return torch.tensor(weights, dtype=torch.float32)


def m15a_channel_weights(
    input_lead: str,
    input_idx: int | None = None,
    hard_scale: float = 3.0,
    far_scale: float = 2.5,
    mid_scale: float = 1.5,
    near_scale: float = 1.0,
) -> torch.Tensor:
    """
    M15a spatial anchor weights for non-input channels (14,).
    Hard pairs take precedence; otherwise band-based scaling from Step-1 audit.
    """
    from src.constants import LEAD_PAIR_TO_INDEX

    if input_idx is None:
        input_idx = LEAD_PAIR_TO_INDEX[input_lead]
    hard_set = set(HARD_LEADS_V2V5)
    weights: list[float] = []
    for i, pair in enumerate(VIRTUAL_LEAD_PAIRS):
        if i == input_idx:
            continue
        if pair in hard_set:
            weights.append(hard_scale)
            continue
        band = spatial_band(pair, input_lead)
        if band == "far":
            weights.append(far_scale)
        elif band == "mid":
            weights.append(mid_scale)
        else:
            weights.append(near_scale)
    return torch.tensor(weights, dtype=torch.float32)
