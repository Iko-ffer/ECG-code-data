#!/usr/bin/env python3
"""Evaluate Exp4 reconstruction: waveform metrics + per-lead breakdown."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import torch
from tqdm import tqdm

from src.constants import LEAD_PAIR_TO_INDEX, VIRTUAL_LEAD_PAIRS
from src.data import build_dataloader
from src.data.indexing import format_index_stats
from src.metrics import batch_metrics, pearson_per_channel
from src.models import build_model
from src.reconstruction import generator_forward, merge_input_channel, non_input_channel_indices, skip_input_waveform
from src.utils import get_device, load_config


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Exp4 reconstruction evaluation")
    p.add_argument("--config", type=str, default="configs/default.yaml")
    p.add_argument("--data-root", type=str, default=None, help="Override data.root")
    p.add_argument("--checkpoint", type=str, default=None)
    p.add_argument("--split", type=str, default="test")
    p.add_argument("--output", type=str, default="eval_results.csv")
    return p.parse_args()


@torch.no_grad()
def main() -> None:
    args = parse_args()
    cfg = load_config(args.config)
    if args.data_root:
        cfg["data"]["root"] = args.data_root
    device = get_device(cfg["eval"]["device"])
    ckpt_path = Path(args.checkpoint or cfg["eval"]["checkpoint"])
    if not ckpt_path.is_file():
        fallback = ckpt_path.parent / "last.pt"
        if fallback.is_file():
            print(f"best.pt missing; using {fallback}")
            ckpt_path = fallback

    input_lead = cfg["data"]["input_lead"]
    input_idx = LEAD_PAIR_TO_INDEX[input_lead]
    non_input_idx = non_input_channel_indices(15, input_idx)
    input_skip = bool(cfg["model"].get("input_skip", False))
    delay_lags = cfg["data"].get("delay_lags")
    skip_channel_idx = delay_lags.index(0) if delay_lags and 0 in delay_lags else 0

    data_root = Path(cfg["data"]["root"]).resolve()
    loader = build_dataloader(
        data_root,
        split=args.split,
        batch_size=int(cfg["eval"]["batch_size"]),
        num_workers=int(cfg["train"]["num_workers"]),
        input_lead=input_lead,
        signal_length=int(cfg["data"]["signal_length"]),
        phenomena=cfg["data"].get("phenomena"),
        labels=cfg["data"].get("labels"),
        shuffle=False,
        dedupe=cfg["data"].get("dedupe_test", False) if args.split == "test" else cfg["data"].get("dedupe_train", True),
        delay_lags=delay_lags,
    )
    ds = loader.dataset
    print(format_index_stats(ds.index_stats, split=args.split, dedupe=ds.dedupe))

    ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
    if ckpt.get("model_type") == "ridge":
        from src.train_ridge import predict_ridge

        ridge_models = ckpt["ridge_models"]
        non_input_idx = ckpt["non_input_idx"]
        input_idx = ckpt["input_idx"]

        def run_batch(x, y, batch=None):
            return predict_ridge(ridge_models, non_input_idx, x, input_idx)

    else:
        generator, _ = build_model(cfg["model"], input_lead=input_lead, device=device)
        generator.load_state_dict(ckpt["generator"])
        generator = generator.to(device).eval()

        def run_batch(x, y, batch):
            raw = generator_forward(generator, x, batch)
            if input_skip:
                return merge_input_channel(raw, skip_input_waveform(x, skip_channel_idx), input_idx)
            return raw

    overall = {"mae": 0.0, "mse": 0.0, "pearson_mean": 0.0}
    non_input = {"mae": 0.0, "mse": 0.0, "pearson_mean": 0.0}
    per_lead = {lead: {"mae": 0.0, "pearson": 0.0, "n": 0} for lead in VIRTUAL_LEAD_PAIRS}
    n_batches = 0

    for batch in tqdm(loader, desc=f"eval/{args.split}"):
        x = batch["input"].to(device)
        y = batch["target"].to(device)
        pred = run_batch(x, y, batch)

        m_all = batch_metrics(pred, y)
        m_ni = batch_metrics(pred, y, channel_indices=non_input_idx)
        for k in overall:
            overall[k] += m_all[k]
        for k in non_input:
            non_input[k] += m_ni[k]
        n_batches += 1

        pred_np = pred.cpu().numpy()
        y_np = y.cpu().numpy()
        for b in range(pred_np.shape[0]):
            pears = pearson_per_channel(pred_np[b], y_np[b])
            for i, lead in enumerate(VIRTUAL_LEAD_PAIRS):
                per_lead[lead]["pearson"] += float(pears[i])
                per_lead[lead]["mae"] += float(abs(pred_np[b, i] - y_np[b, i]).mean())
                per_lead[lead]["n"] += 1

    overall = {k: v / max(n_batches, 1) for k, v in overall.items()}
    non_input = {k: v / max(n_batches, 1) for k, v in non_input.items()}

    rows: list[dict] = [
        {
            "scope": "overall_all",
            "lead": "all_15",
            "mae": overall["mae"],
            "mse": overall["mse"],
            "pearson_mean": overall["pearson_mean"],
            "is_input_lead": "",
        },
        {
            "scope": "overall_non_input",
            "lead": "all_14",
            "mae": non_input["mae"],
            "mse": non_input["mse"],
            "pearson_mean": non_input["pearson_mean"],
            "is_input_lead": "",
        },
    ]
    for lead in VIRTUAL_LEAD_PAIRS:
        n = max(per_lead[lead]["n"], 1)
        rows.append(
            {
                "scope": "per_lead",
                "lead": lead,
                "mae": per_lead[lead]["mae"] / n,
                "mse": "",
                "pearson_mean": per_lead[lead]["pearson"] / n,
                "is_input_lead": int(lead == input_lead),
            }
        )

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["scope", "lead", "mae", "mse", "pearson_mean", "is_input_lead"]
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print("Overall (15 leads):", overall)
    print("Non-input (14 leads):", non_input)
    print(f"Input lead: {input_lead} (index {input_idx}), input_skip={input_skip}")
    print(f"Wrote {out_path}")


if __name__ == "__main__":
    main()
