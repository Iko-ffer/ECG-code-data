"""Waveform-level reconstruction metrics (L1 / MSE / Pearson)."""

from __future__ import annotations

import numpy as np
import torch


def pearson_per_channel(pred: np.ndarray, target: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    """pred/target: (C, L)"""
    c = pred.shape[0]
    out = np.zeros(c, dtype=np.float64)
    for i in range(c):
        p = pred[i] - pred[i].mean()
        t = target[i] - target[i].mean()
        denom = (np.linalg.norm(p) * np.linalg.norm(t)) + eps
        out[i] = float(np.dot(p, t) / denom)
    return out


def _slice_channels(t: torch.Tensor, channel_indices: list[int] | None) -> torch.Tensor:
    if channel_indices is None:
        return t
    idx = torch.tensor(channel_indices, device=t.device, dtype=torch.long)
    return t.index_select(dim=1, index=idx)


def batch_metrics(
    pred: torch.Tensor,
    target: torch.Tensor,
    channel_indices: list[int] | None = None,
) -> dict[str, float]:
    """
    pred/target: (B, C, L)
    channel_indices: optional subset of channels for aggregation.
    """
    pred_s = _slice_channels(pred, channel_indices)
    tgt_s = _slice_channels(target, channel_indices)

    mae = torch.mean(torch.abs(pred_s - tgt_s)).item()
    mse = torch.mean((pred_s - tgt_s) ** 2).item()

    pred_np = pred_s.detach().cpu().numpy()
    tgt_np = tgt_s.detach().cpu().numpy()
    pears: list[float] = []
    for b in range(pred_np.shape[0]):
        p_ch = pearson_per_channel(pred_np[b], tgt_np[b])
        pears.append(float(np.nanmean(p_ch)))
    pearson_mean = float(np.nanmean(pears)) if pears else 0.0
    return {"mae": mae, "mse": mse, "pearson_mean": pearson_mean}
