"""Virtual lead pair definitions for Exp4."""

from __future__ import annotations

# Fixed order for 15 pairwise chest virtual leads (V1-V6 differences).
VIRTUAL_LEAD_PAIRS: list[str] = [
    "V1-V2",
    "V1-V3",
    "V1-V4",
    "V1-V5",
    "V1-V6",
    "V2-V3",
    "V2-V4",
    "V2-V5",
    "V2-V6",
    "V3-V4",
    "V3-V5",
    "V3-V6",
    "V4-V5",
    "V4-V6",
    "V5-V6",
]

LEAD_PAIR_TO_INDEX: dict[str, int] = {name: i for i, name in enumerate(VIRTUAL_LEAD_PAIRS)}

PHENOMENA: list[str] = ["AF", "LBBB", "RBBB", "PVC", "ST-T"]
