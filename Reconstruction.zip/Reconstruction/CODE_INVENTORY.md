

```bash
cd m30a_runnable_package
export PYTHONPATH=.

# SPCS 训练 / 测试
python src/train.py --config configs/compare/m30a_unfreeze_tcn.yaml --data-root /path/to/SPCS2018
python src/eval.py  --config configs/compare/m30a_unfreeze_tcn.yaml --split test \
  --data-root /path/to/SPCS2018 --output results/m30a_spcs_test.csv

# ls12ed 微调 / 测试（需先有 SPCS 的 best.pt，或改 yaml 的 init 路径）
python src/train.py --config configs/compare/m30a_unfreeze_tcn_ls12ed.yaml --data-root /path/to/ls12ed
python src/eval.py  --config configs/compare/m30a_unfreeze_tcn_ls12ed.yaml --split test \
  --data-root /path/to/ls12ed --output results/m30a_ls12ed_test.csv
```



## 二、本包已包含（语义核心）

| 类别 | 文件 | 作用 |
|------|------|------|
| 入口 | `src/train.py`, `src/eval.py` | 训练 / 测试 |
| 组网 | `src/models/m9_attn_refine.py` | M30a 总装 |
| 粗估计 | `tcn_1d.py` | 膨胀 TCN → 15 导 y0 |
| 宏编码 | `m22_performer.py`, `m24_performer_stgcn_ode.py` | Performer-style e |
| ODE | `m25_full_model.py`, `m23_st_gcn.py`, `m21_bw_ode.py` | soft phase + ST-GCN ODE + cross-attn |
| U-Net | `attention_unet_refine.py`, `unet_1d.py` | 高频残差 |
| 条件 | `film.py`, `spatial_coord.py` | 病理嵌入 / 解剖坐标 |
| 损失 | `wavelet_loss.py`, `supervised_loss.py` | HF-enhanced gated loss |
| 数据 | `src/data/*` | Dataset / 索引 |
| 指标 | `src/metrics/waveform.py` | Pearson / MAE |
| 工具 | `constants.py`, `lead_space.py`, `lead_graph.py`, `utils.py`, `reconstruction.py` | 导联空间与前向封装 |
| 配置 | `configs/compare/m30a_unfreeze_tcn*.yaml` | SPCS / ls12ed / 可选 V1-V2 |

## 三、本包为“能 import 通”额外带上的历史文件“

因 `gan.py` / `reconstruction.py` 顶端仍 `import` 旧模型，未改代码前必须带着，否则 ImportError：

`chest_two_stage`, `cnn_baseline`, `cross_lead_decoder`, `patchgan`, `spatial_patchgan`, `lead_graph_refine`, `tcn_cross_lead`, `tcn_m13_refine`, `dynamic_graph_block`, `m16_refine`, `m25_performer_stgcn_ode`, `m25_anatomical_cross_attn`, `m27_ekgan`, `ekgan_modules`, `gan_loss`

若以后精简 `gan.py` / `reconstruction.py` 只保留 M30a 分支，以上可全部删除。

## 四、明确不需要下载 / 不进本包（历史与产物）

- **旧实验配置**：`configs/compare/` 里除 `m30a_*` 外的全部（M0–M29、M30b/c、curriculum、literature…）
- **服务器脚本**：`scripts/run_m*_server.sh`、`pull_*`、`export_*`、`deploy_*`、`sync_*`
- **旧模型源码**：`polarity_head`, `physics_residual`, `m14/m19 discriminators`, `pair15_classifier`, `ecg_discriminators`, `m25_anatomy_discriminator` 等
- **旁路训练**：`train_ekgan.py`, `train_ridge.py`, `export_waveforms.py`, `compare/*` 可视化
- **训练产物**：`checkpoints_compare/**`, `runs_compare/**`, `results_compare/**`, `predictions_export*/**`, `waveforms_export*/**`, `logs/**`

> 用户要求：不需要训练过程与训练好的参数。本包**不含**任何 `.pt` checkpoint。  
> 若要从头复现 yaml 里的 warm-start 路径，才需要另备 `M2_tcn/best.pt`、`M29-Full-Parallel/best.pt`（那是权重，不是代码）。

## 五、数据依赖（代码外）

- SPCS2018：`train/` + `test/`（
- ls12ed：同上
