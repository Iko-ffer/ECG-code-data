import matplotlib.pyplot as plt
import numpy as np
import torch
import os
import psutil
import time
import random
from torch.utils.data import Dataset, DataLoader
from scipy.io import loadmat
import sys
_CODE_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
if _CODE_ROOT not in sys.path:
    sys.path.insert(0, _CODE_ROOT)
from common.ecg_preprocess import prepare_ecg_signal, resolve_label_dir
import warnings
warnings.filterwarnings('ignore')

# ===================== 导入你的模型和训练器（保持不变） =====================
from model import RobustCNNBiGRU, WorkingECGModel, SimpleButEffectiveModel, DebuggableECGModel, ResNet1D, UNet1DClassifier, MobileNetV1_ECG, BiGRU_ECG
from train import DebugTrainer, WorkingTrainer

# ===================== 全局配置（只需要修改这里切换疾病） =====================
DISEASE_NAME = "LBBB"  # 一键切换：AF / LBBB / RBBB / PVC / STT
DATASET_ROOT = os.path.join(os.environ.get("ECG_DATASET_BASE", "/root/autodl-tmp/SPCS2018"), DISEASE_NAME)
SAMPLING_RATE = 500
SEGMENT_LENGTH = 5
BATCH_SIZE = 8
RANDOM_STATE = 42

# 标签映射（通用二分类）
LABEL_MAPPING = {0: "Normal", 1: DISEASE_NAME}

# 15个固定虚拟导联对
LEAD_PAIRS = [
    'V1-V2', 'V2-V3', 'V3-V4', 'V4-V5', 'V5-V6',
    'V1-V3', 'V2-V4', 'V3-V5', 'V4-V6', 'V1-V4',
    'V2-V5', 'V3-V6', 'V1-V5', 'V1-V6', 'V2-V6'
]

# ===================== 数据集类（已添加样本级Z-Score归一化） =====================
class ECGFolderDataset(Dataset):
    """从文件夹加载ECG切片数据集"""
    def __init__(self, root_dir, lead_name, mode='train', transform=None):
        """
        Args:
            root_dir: 数据集根目录（如AF/）
            lead_name: 导联名称（如V1-V2）
            mode: 'train' 或 'test'
            transform: 可选的数据增强
        """
        self.root_dir = root_dir
        self.lead_name = lead_name
        self.mode = mode
        self.transform = transform
        
        # 存储所有文件路径和对应的标签
        self.file_paths = []
        self.labels = []
        
        # 加载阳性样本（标签1）
        pos_dir = resolve_label_dir(root_dir, lead_name, mode, '1')
        if pos_dir:
            for f in os.listdir(pos_dir):
                if f.endswith('.mat'):
                    self.file_paths.append(os.path.join(pos_dir, f))
                    self.labels.append(1)
        
        # 加载阴性样本（标签0）
        neg_dir = resolve_label_dir(root_dir, lead_name, mode, '0')
        if neg_dir:
            for f in os.listdir(neg_dir):
                if f.endswith('.mat'):
                    self.file_paths.append(os.path.join(neg_dir, f))
                    self.labels.append(0)
        
        # 标签类型改为int64（Long），适配cross_entropy损失
        self.labels = np.array(self.labels, dtype=np.int64)
        
        print(f"✅ 加载 {lead_name} {mode} 集: 总样本={len(self)}, 阳性={np.sum(self.labels)}, 阴性={len(self)-np.sum(self.labels)}")

    def __len__(self):
        return len(self.file_paths)

    def __getitem__(self, idx):
        # 加载mat文件
        mat_data = loadmat(self.file_paths[idx])
        signal = prepare_ecg_signal(mat_data['signal'])
        
        # 应用数据增强（可选）
        if self.transform:
            signal = self.transform(signal)
        
        # 转换为torch张量
        signal_tensor = torch.from_numpy(signal)
        # 标签张量类型改为torch.long
        label_tensor = torch.tensor(self.labels[idx], dtype=torch.long)
        
        return signal_tensor, label_tensor

def collate_fn(batch):
    """批次整理函数（与原脚本完全兼容）"""
    signals = torch.stack([item[0] for item in batch])
    labels = torch.stack([item[1] for item in batch])
    return signals, labels

# ===================== GPU优化（保持不变） =====================
class GPUOptimizer:
    @staticmethod
    def setup_environment():
        if torch.cuda.is_available():
            device_count = torch.cuda.device_count()
            print(f"CUDA可用，GPU数量: {device_count}")
            torch.cuda.set_device(0)
            current_device = torch.cuda.get_device_name(0)
            print(f"使用GPU: {current_device}")
            torch.cuda.empty_cache()
        else:
            print("CUDA不可用，使用CPU")

        torch.set_num_threads(min(8, os.cpu_count()))
        print("GPU优化配置完成")

    @staticmethod
    def get_dataloader_config():
        return {
            'num_workers': min(4, os.cpu_count()),
            'pin_memory': torch.cuda.is_available(),
            'persistent_workers': True,
        }

    @staticmethod
    def cleanup_memory():
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
        import gc
        gc.collect()

# ===================== 系统信息打印（保持不变） =====================
def print_system_info():
    if torch.cuda.is_available():
        device = torch.device('cuda:0')
        gpu_name = torch.cuda.get_device_name(0)
        gpu_memory = torch.cuda.get_device_properties(0).total_memory / 1024 ** 3
        print(f"使用设备: {device} ({gpu_name})")
        print(f"GPU内存: {gpu_memory:.1f} GB")
    else:
        device = torch.device('cpu')
        print(f"使用设备: {device}")

    memory = psutil.virtual_memory()
    print(f"系统内存: {memory.total / 1024 ** 3:.1f} GB")
    print(f"可用内存: {memory.available / 1024 ** 3:.1f} GB")

    print(f"PyTorch版本: {torch.__version__}")
    if torch.cuda.is_available():
        print(f"CUDA版本: {torch.version.cuda}")
        print(f"cuDNN版本: {torch.backends.cudnn.version()}")
    print("=" * 60)

# ===================== 导联选择（保持不变） =====================
def select_target_leads():
    print("\n 选择目标训练导联")
    print("自动使用全部15个预设导联对作为目标导联")
    
    print("选中的目标导联组合:")
    for i, lead in enumerate(LEAD_PAIRS, 1):
        print(f"  {i}: {lead}")
    
    return LEAD_PAIRS

# ===================== 数据加载器创建函数（保持不变） =====================
def create_dataloader():
    """直接从文件夹创建所有导联的数据加载器"""
    print("\n" + "="*80)
    print(f" 加载 {DISEASE_NAME} 二分类数据集")
    print("="*80)

    TARGET_LEADS = select_target_leads()
    dataloader_config = GPUOptimizer.get_dataloader_config()
    valid_dataloader_keys = {'num_workers', 'pin_memory', 'timeout'}
    dataloader_config = {k: v for k, v in dataloader_config.items() if k in valid_dataloader_keys}
    
    dataloaders_by_lead = {}
    lead_comparison = []

    for lead_name in TARGET_LEADS:
        # 创建训练集和测试集
        train_ds = ECGFolderDataset(DATASET_ROOT, lead_name, mode='train')
        test_ds = ECGFolderDataset(DATASET_ROOT, lead_name, mode='test')
        
        if len(train_ds) == 0 or len(test_ds) == 0:
            print(f"⚠️  导联 {lead_name} 无有效数据，跳过")
            continue
        
        # 从训练集中划分验证集（8:2）
        train_sample_names = [os.path.basename(fp).split('_')[0] for fp in train_ds.file_paths]
        unique_train_samples = sorted(list(set(train_sample_names)))
        
        # 按原样本8:2划分
        random.seed(RANDOM_STATE)
        random.shuffle(unique_train_samples)
        n_train_samples = int(0.8 * len(unique_train_samples))
        train_sample_set = set(unique_train_samples[:n_train_samples])
        val_sample_set = set(unique_train_samples[n_train_samples:])
        
        # 根据原样本名划分切片
        train_indices = [i for i, name in enumerate(train_sample_names) if name in train_sample_set]
        val_indices = [i for i, name in enumerate(train_sample_names) if name in val_sample_set]
        
        train_ds_split = torch.utils.data.Subset(train_ds, train_indices)
        val_ds_split = torch.utils.data.Subset(train_ds, val_indices)
        
        print(f"\n✅ 导联 {lead_name} 按原样本划分验证集:")
        print(f"  训练样本数: {len(train_sample_set)} | 验证样本数: {len(val_sample_set)}")
        print(f"  训练切片数: {len(train_ds_split)} | 验证切片数: {len(val_ds_split)}")
        
        # 创建DataLoader
        train_loader = DataLoader(
            train_ds_split,
            batch_size=BATCH_SIZE,
            shuffle=True,
            collate_fn=collate_fn,
            drop_last=True,
            **dataloader_config
        )
        val_loader = DataLoader(
            val_ds_split,
            batch_size=BATCH_SIZE * 2,
            shuffle=False,
            collate_fn=collate_fn,
            **dataloader_config
        )
        test_loader = DataLoader(
            test_ds,
            batch_size=BATCH_SIZE * 2,
            shuffle=False,
            collate_fn=collate_fn,
            **dataloader_config
        )
        
        dataloaders_by_lead[lead_name] = {
            'train': train_loader,
            'val': val_loader,
            'test': test_loader
        }

        # 统计导联信息（用于后续对比）
        total_samples = len(train_ds_split) + len(val_ds_split) + len(test_ds)
        pos_count = int(np.sum(train_ds.labels[train_indices]) + np.sum(test_ds.labels))
        pos_ratio = pos_count / total_samples if total_samples > 0 else 0
        
        lead_comparison.append({
            'lead_name': lead_name,
            'total_samples': total_samples,
            'train_samples': len(train_ds_split),
            'val_samples': len(val_ds_split),
            'test_samples': len(test_ds),
            'pos_count': pos_count,
            'neg_count': total_samples - pos_count,
            'pos_ratio': pos_ratio
        })

        # 打印加载器信息
        print(f"\n目标导联 {lead_name}:")
        print(f"  训练集: {len(train_loader)} 批次 ({len(train_ds_split)} 样本)")
        print(f"  验证集: {len(val_loader)} 批次 ({len(val_ds_split)} 样本)")
        print(f"  测试集: {len(test_loader)} 批次 ({len(test_ds)} 样本)")

    # 验证数据加载器
    print("\n" + "="*80)
    print(" 数据加载器验证")
    print("="*80)
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    
    for lead_name, loaders in dataloaders_by_lead.items():
        train_batch = next(iter(loaders['train']))
        train_signals, train_labels = train_batch
        train_signals = train_signals.to(device)
        train_labels = train_labels.to(device)
        
        print(f"\n导联 {lead_name} 批次验证:")
        print(f"  信号形状: {train_signals.shape}")
        print(f"  标签形状: {train_labels.shape}")
        print(f"  标签类型: {train_labels.dtype}")
        print(f"  归一化后信号均值: {train_signals.mean().item():.4f}")
        print(f"  归一化后信号标准差: {train_signals.std().item():.4f}")
        print(f"  批次标签分布: {DISEASE_NAME}={torch.sum(train_labels).item()}, Normal={len(train_labels)-torch.sum(train_labels).item()}")

    print("\n" + "="*80)
    print(" 所有导联数据加载完成！")
    print("="*80)
    
    GPUOptimizer.cleanup_memory()
    
    # 按总样本数排序
    lead_comparison_sorted = sorted(lead_comparison, key=lambda x: x['total_samples'], reverse=True)
    
    return dataloaders_by_lead, lead_comparison_sorted, lead_comparison

# ===================== 以下所有函数保持不变 =====================
def visualize_metrics(lead_metrics, save_path=f"{DISEASE_NAME}_metrics_comparison.png"):
    """生成多指标对比可视化"""
    if not lead_metrics:
        print(" 无指标数据可可视化，跳过")
        return
    
    lead_names = [item['lead_name'] for item in lead_metrics]
    accs = [item.get('accuracy', 0) for item in lead_metrics]
    f1s = [item.get('f1', 0) for item in lead_metrics]
    aurocs = [item.get('auroc', 0) for item in lead_metrics]
    sensitivities = [item.get('sensitivity', 0) for item in lead_metrics]
    specificities = [item.get('specificity', 0) for item in lead_metrics]
    
    sorted_indices = np.argsort(aurocs)[::-1]
    lead_names = [lead_names[i] for i in sorted_indices]
    accs = [accs[i] for i in sorted_indices]
    f1s = [f1s[i] for i in sorted_indices]
    aurocs = [aurocs[i] for i in sorted_indices]
    sensitivities = [sensitivities[i] for i in sorted_indices]
    specificities = [specificities[i] for i in sorted_indices]
    
    colors = plt.cm.viridis(np.linspace(0, 1, len(lead_names)))
    
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))
    fig.suptitle(f"{DISEASE_NAME} 虚拟导联多指标对比", fontsize=16, fontweight='bold')
    
    ax1 = axes[0, 0]
    ax1.bar(lead_names, accs, color=colors)
    ax1.set_title('ACCURACY Comparison')
    ax1.set_ylabel('Accuracy')
    ax1.set_ylim(0, 1)
    ax1.set_xticklabels(lead_names, rotation=45, ha='right')
    for i, v in enumerate(accs):
        ax1.text(i, v + 0.01, f'{v:.3f}', ha='center')
    
    ax2 = axes[0, 1]
    ax2.bar(lead_names, f1s, color=colors)
    ax2.set_title('F1_SCORE Comparison')
    ax2.set_ylabel('F1 Score')
    ax2.set_ylim(0, 1)
    ax2.set_xticklabels(lead_names, rotation=45, ha='right')
    for i, v in enumerate(f1s):
        ax2.text(i, v + 0.01, f'{v:.3f}', ha='center')
    
    ax3 = axes[0, 2]
    ax3.bar(lead_names, aurocs, color=colors)
    ax3.set_title('AUROC Comparison')
    ax3.set_ylabel('AUROC')
    ax3.set_ylim(0, 1)
    ax3.set_xticklabels(lead_names, rotation=45, ha='right')
    for i, v in enumerate(aurocs):
        ax3.text(i, v + 0.01, f'{v:.3f}', ha='center')
    
    ax4 = axes[1, 0]
    ax4.bar(lead_names, sensitivities, color=colors)
    ax4.set_title('SENSITIVITY Comparison')
    ax4.set_ylabel('Sensitivity')
    ax4.set_ylim(0, 1)
    ax4.set_xticklabels(lead_names, rotation=45, ha='right')
    for i, v in enumerate(sensitivities):
        ax4.text(i, v + 0.01, f'{v:.3f}', ha='center')
    
    ax5 = axes[1, 1]
    ax5.bar(lead_names, specificities, color=colors)
    ax5.set_title('SPECIFICITY Comparison')
    ax5.set_ylabel('Specificity')
    ax5.set_ylim(0, 1)
    ax5.set_xticklabels(lead_names, rotation=45, ha='right')
    for i, v in enumerate(specificities):
        ax5.text(i, v + 0.01, f'{v:.3f}', ha='center')
    
    ax6 = axes[1, 2]
    ax6.axis('off')
    rank_text = "Virtual Lead Performance Ranking:\n"
    for i, (lead, acc, f1, auroc) in enumerate(zip(lead_names, accs, f1s, aurocs), 1):
        rank_text += f"{i}. {lead}: ACC: {acc:.3f}, F1: {f1:.3f}, AUROC: {auroc:.3f}\n"
    ax6.text(0, 0.5, rank_text, fontsize=10, va='center')
    
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.show()
    print(f" 多指标对比图表已保存为: {save_path}")

def select_model_and_attention():
    print("\n 选择模型和注意力机制")

    model_options = {
        "1": ("RobustCNNBiGRU (完整CNN+BiGRU)", RobustCNNBiGRU),
        "2": ("WorkingECGModel (推荐)", WorkingECGModel),
        "3": ("SimpleButEffectiveModel (稳定)", SimpleButEffectiveModel),
        "4": ("DebuggableECGModel (调试)", DebuggableECGModel),
        "5": ("ResNet1d (残差网络)", ResNet1D),
        "6": ("UNet1DClassifier (UNet分类版)", UNet1DClassifier),
        "7": ("MobileNetV1_ECG (轻量化CNN)", MobileNetV1_ECG), 
        "8": ("BiGRU_ECG", BiGRU_ECG),
    }

    attention_options = {
        "1": ("robust", "稳健注意力 (默认)"),
        "2": ("hierarchical", "层次化注意力"),
        "3": ("multihead", "多头注意力"),
        "4": ("adaptive", "自适应注意力 (推荐)"),
    }

    print("\n📊 模型选择:")
    for key, (name, _) in model_options.items():
        print(f"  {key}. {name}")

    model_choice = os.environ.get("ECG_MODEL_CHOICE") or input("请选择模型 (默认1): ").strip() or "1"
    model_name, model_class = model_options.get(model_choice, model_options["1"])
    print(f" 选择模型: {model_name}")

    if model_class in [ResNet1D, UNet1DClassifier, MobileNetV1_ECG, BiGRU_ECG]:  
        print(f"\n {model_name} 不使用注意力机制")
        return model_class, "none", model_name

    print("\n🎯 注意力机制选择:")
    for key, (att_type, desc) in attention_options.items():
        print(f"  {key}. {desc}")

    attention_choice = input("请选择注意力机制 (默认4): ").strip() or "4"
    attention_type, attention_desc = attention_options.get(attention_choice, attention_options["4"])
    print(f" 选择注意力机制: {attention_desc}")

    return model_class, attention_type, model_name

def select_trainer():
    print("\n 训练器选择:")
    print("  1. DebugTrainer (调试模式 - 推荐)")
    print("  2. WorkingTrainer (稳定模式)")

    trainer_choice = os.environ.get("ECG_TRAINER_CHOICE") or input("请选择训练器 (默认1): ").strip() or "1"

    if trainer_choice == "2":
        return WorkingTrainer, "WorkingTrainer"
    else:
        return DebugTrainer, "DebugTrainer"

def train_model(model, train_loader, val_loader, test_loader, device, model_name, attention_type, trainer_class, model_id):
    if torch.cuda.is_available():
        gpu_memory = torch.cuda.get_device_properties(0).total_memory / 1024 ** 3
        if gpu_memory >= 10:
            training_configs = {
                "RobustCNNBiGRU": {"epochs": 80, "patience": 20, "batch_size": 32},
                "WorkingECGModel": {"epochs": 100, "patience": 25, "batch_size": 32},
                "SimpleButEffectiveModel": {"epochs": 100, "patience": 25, "batch_size": 32},
                "DebuggableECGModel": {"epochs": 60, "patience": 15, "batch_size": 32},
                "ResNet1D": {"epochs": 120, "patience": 25, "batch_size": 32},
                "UNet1DClassifier": {"epochs": 90, "patience": 25, "batch_size": 16},
                "MobileNetV1_ECG": {"epochs": 90, "patience": 25, "batch_size": 16}, 
                "BiGRU_ECG": {"epochs": 90, "patience": 25, "batch_size": 16},
            }
        elif gpu_memory >= 6:
            training_configs = {
                "RobustCNNBiGRU": {"epochs": 70, "patience": 18, "batch_size": 24},
                "WorkingECGModel": {"epochs": 90, "patience": 22, "batch_size": 24},
                "SimpleButEffectiveModel": {"epochs": 90, "patience": 22, "batch_size": 24},
                "DebuggableECGModel": {"epochs": 55, "patience": 15, "batch_size": 24},
                "ResNet1D": {"epochs": 90, "patience": 22, "batch_size": 24},
                "UNet1DClassifier": {"epochs": 80, "patience": 22, "batch_size": 24},
                "MobileNetV1_ECG": {"epochs": 80, "patience": 22, "batch_size": 48},
                "BiGRU_ECG": {"epochs": 80, "patience": 22, "batch_size": 48},
            }
        else:
            training_configs = {
                "RobustCNNBiGRU": {"epochs": 60, "patience": 15, "batch_size": 16},
                "WorkingECGModel": {"epochs": 80, "patience": 20, "batch_size": 16},
                "SimpleButEffectiveModel": {"epochs": 80, "patience": 20, "batch_size": 16},
                "DebuggableECGModel": {"epochs": 50, "patience": 15, "batch_size": 16},
                "ResNet1D": {"epochs": 80, "patience": 20, "batch_size": 16},
                "UNet1DClassifier": {"epochs": 70, "patience": 20, "batch_size": 16},
                "MobileNetV1_ECG": {"epochs": 70, "patience": 20, "batch_size": 32},
                "BiGRU_ECG": {"epochs": 70, "patience": 20, "batch_size": 32},
            }
    else:
        training_configs = {
            "RobustCNNBiGRU": {"epochs": 30, "patience": 10, "batch_size": 8},
            "WorkingECGModel": {"epochs": 40, "patience": 12, "batch_size": 8},
            "SimpleButEffectiveModel": {"epochs": 40, "patience": 12, "batch_size": 8},
            "DebuggableECGModel": {"epochs": 20, "patience": 8, "batch_size": 8},
            "ResNet1D": {"epochs": 40, "patience": 12, "batch_size": 8},
            "UNet1DClassifier": {"epochs": 25, "patience": 8, "batch_size": 4},
            "MobileNetV1_ECG": {"epochs": 25, "patience": 8, "batch_size": 16},
            "BiGRU_ECG": {"epochs": 25, "patience": 8, "batch_size": 16},
        }

    config = training_configs.get(model.__class__.__name__, {"epochs": 90, "patience": 25, "batch_size": 16})

    print(f"\n训练配置:")
    print(f"  轮数: {config['epochs']}")
    print(f"  早停: {config['patience']}")
    print(f"  注意力机制: {attention_type}")

    print(f" 使用训练器: {trainer_class.__name__}")

    trainer = trainer_class(model, device, model_id)

    print("\n开始训练...")
    training_start = time.time()

    try:
        trainer.train(
            train_loader,
            val_loader,
            epochs=config['epochs'],
            patience=config['patience']
        )
        training_time = time.time() - training_start
        return trainer, training_time, True

    except Exception as e:
        print(f"训练过程中出错: {e}")
        import traceback
        traceback.print_exc()
        
        GPUOptimizer.cleanup_memory()
        return trainer, 0, False

def save_model_and_results(model, trainer, training_time, attention_type, lead_name, success=True):
    if not success:
        print("训练失败，跳过模型保存")
        return None

    model_cpu = model.cpu() if torch.cuda.is_available() else model

    model_info = {
        'model_state_dict': model_cpu.state_dict(),
        'label_mapping': LABEL_MAPPING,
        'model_config': {
            'model_type': model.__class__.__name__,
            'num_classes': 2,
            'attention_type': attention_type,
            'lead_name': lead_name,
            'disease': DISEASE_NAME
        },
        'training_info': {
            'best_accuracy': getattr(trainer, 'best_accuracy', 0),
            'best_f1': getattr(trainer, 'best_f1', 0),
            'training_time': training_time,
            'total_epochs': len(getattr(trainer, 'train_losses', [])),
            'training_device': 'cuda' if torch.cuda.is_available() else 'cpu'
        },
        'performance_metrics': {
            'train_losses': getattr(trainer, 'train_losses', []),
            'val_losses': getattr(trainer, 'val_losses', []),
            'train_accuracies': getattr(trainer, 'train_accuracies', []),
            'val_accuracies': getattr(trainer, 'val_accuracies', [])
        }
    }

    timestamp = int(time.time())
    filename = f'final_{DISEASE_NAME}_{model.__class__.__name__.lower()}_{attention_type}_{lead_name}_{timestamp}.pth'

    try:
        torch.save(model_info, filename)
        print(f"💾 模型已保存: {filename}")
        
        if torch.cuda.is_available():
            model.to('cuda:0')
        
        return filename
    except Exception as e:
        print(f"❌ 模型保存失败: {e}")
        return None

def print_training_summary(model, trainer, training_time, filename, attention_type, lead_name, success=True):
    print("\n" + "=" * 60)
    print(f" 导联 {lead_name} 训练完成总结")
    print("=" * 60)

    if success:
        print(f" 疾病类型: {DISEASE_NAME}")
        print(f" 模型类型: {model.__class__.__name__}")
        print(f" 注意力机制: {attention_type}")
        print(f" 对应导联: {lead_name}")
        print(f"  训练设备: {'GPU (CUDA)' if torch.cuda.is_available() else 'CPU'}")
        print(f" 最佳验证准确率: {getattr(trainer, 'best_accuracy', 0):.4f}")
        print(f" 最佳F1分数: {getattr(trainer, 'best_f1', 0):.4f}")
        print(f"  总训练时间: {training_time / 60:.1f} 分钟")
        print(f" 训练轮数: {len(getattr(trainer, 'train_losses', []))}")

        if hasattr(trainer, 'epoch_times') and trainer.epoch_times:
            avg_epoch_time = np.mean(trainer.epoch_times)
            print(f"平均每轮时间: {avg_epoch_time:.1f} 秒")

        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print(f"模型参数: {total_params:,}")
        print(f"可训练参数: {trainable_params:,}")
        print(f"模型大小: {total_params * 4 / 1024 ** 2:.2f} MB")

        if filename:
            print(f"模型文件: {filename}")
    else:
        print(f"❌ 导联 {lead_name} 训练失败")
        print("💡 建议检查:")
        print("  - 数据集文件夹结构是否正确")
        print("  - 正负样本数量是否平衡")
        print("  - 模型输入长度是否为2500")
        print("  - GPU内存是否充足")

    print("=" * 60)

# ===================== 主函数（已移除评估逻辑） =====================
def main():
    print_system_info()
    GPUOptimizer.setup_environment()
    
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    print(f"\n 当前训练疾病: {DISEASE_NAME}")
    print(f" 数据集根目录: {DATASET_ROOT}")
    print(f" 批次大小: {BATCH_SIZE}")

    # 创建数据加载器
    dataloaders, lead_comparison_sorted, lead_comparison = create_dataloader()
    
    # 选择模型和训练器
    model_class, attention_type, model_name = select_model_and_attention()
    trainer_class, trainer_name = select_trainer()
    print(f" 使用训练器: {trainer_name}")

    lead_trainers = {}

    # 遍历所有导联训练
    for idx, (lead_name, loaders) in enumerate(dataloaders.items(), 1):
        print(f"\n" + "="*80)
        print(f" 正在训练导联 {idx}/{len(dataloaders)}: {lead_name}")
        print("="*80)
        
        train_loader = loaders['train']
        val_loader = loaders['val']
        test_loader = loaders['test']

        # 初始化模型（修正输入长度为2500）
        try:
            if model_class in [RobustCNNBiGRU, WorkingECGModel]:
                model = model_class(num_classes=2, attention_type=attention_type)
            elif model_class == ResNet1D:
                model = model_class(
                    input_channels=1,
                    num_classes=2,
                    segment_length=2500,
                    dropout_rate=0.2
                )
            elif model_class == UNet1DClassifier:   
                model = model_class(
                    input_channels=1,
                    input_length=2500,
                    num_classes=2,
                    base_filters=16,  
                    dropout_rate=0.3
                )
            elif model_class == MobileNetV1_ECG:
                model = model_class(
                    input_length=2048,
                    in_channels=1,
                    scale=1.0,
                    num_classes=2,
                    dropout_rate=0.3
                ) 
            elif model_class == BiGRU_ECG:
                model = BiGRU_ECG(
                    num_classes=2,          
                    input_length=2000,      
                    num_gru_layers=2,       
                    dropout_rate=0.2        
                )
            else:
                model = model_class(num_classes=2) 

            model.to(device)
            if torch.cuda.device_count() > 1:
                model = torch.nn.DataParallel(model)
        except Exception as e:
            print(f"❌ 导联 {lead_name} 模型初始化失败: {e}")
            continue

        model_id = f"{DISEASE_NAME}_{model.__class__.__name__.lower()}_{attention_type}_{lead_name}"
        
        # 训练
        trainer, training_time, success = train_model(
            model, train_loader, val_loader, test_loader, device,
            model_name, attention_type, trainer_class, model_id
        )
        
        lead_trainers[lead_name] = (trainer, model, device)
        
        # 保存模型
        filename = save_model_and_results(model, trainer, training_time, attention_type, lead_name, success)
        print_training_summary(model, trainer, training_time, filename, attention_type, lead_name, success)
        
        GPUOptimizer.cleanup_memory()

    # 清理内存
    for trainer, model, device in lead_trainers.values():
        del trainer
        del model
    for lead_name, loaders in dataloaders.items():
        del loaders['train']
        del loaders['val']
        del loaders['test']
    del dataloaders
    torch.cuda.empty_cache()
    
    print(f"\n✅ {DISEASE_NAME} 所有导联训练完成！")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n⚠️ 用户中断程序，清理内存...")
        GPUOptimizer.cleanup_memory()
        torch.cuda.empty_cache()
    except Exception as e:
        print(f"\n❌ 程序执行出错: {e}")
        import traceback
        traceback.print_exc()
        GPUOptimizer.cleanup_memory()
        torch.cuda.empty_cache()