import torch
import torch.nn as nn
import torch.nn.init as init
import torch.nn.functional as F
import math
from torch.autograd import Variable
from torchinfo import summary
from torch.optim import Adam
from torch.utils.data import DataLoader, Subset, ConcatDataset, TensorDataset
import random
import numpy as np

class ECGChannelAttention1D(nn.Module):
    """ECG专用通道注意力：适配心电信号幅值分布特性"""
    def __init__(self, channels, reduction=8):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.max_pool = nn.AdaptiveMaxPool1d(1)
        
        self.mlp = nn.Sequential(
            nn.Linear(channels, channels // reduction, bias=False),
            nn.BatchNorm1d(channels // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(channels // reduction, channels, bias=False)
        )
        self.sigmoid = nn.Sigmoid()
        self.alpha = nn.Parameter(torch.ones(1))
        self.beta = nn.Parameter(torch.ones(1))

    def forward(self, x):
        b, c, _ = x.size()
        avg_out = self.mlp(self.avg_pool(x).view(b, c))
        max_out = self.mlp(self.max_pool(x).view(b, c))
        out = self.alpha * avg_out + self.beta * max_out
        return x * self.sigmoid(out).view(b, c, 1)


class ECGTemporalAttention1D(nn.Module):
    """ECG专用时序注意力：捕捉R波/QRS波等关键时序特征"""
    def __init__(self, channels, kernel_size=3):
        super().__init__()
        self.channels = channels
        self.query_conv = nn.Conv1d(channels, channels//8, 1, bias=False)
        self.key_conv = nn.Conv1d(channels, channels//8, 1, bias=False)
        self.value_conv = nn.Conv1d(channels, channels, 1, bias=False)
        self.gamma = nn.Parameter(torch.zeros(1))
        self.softmax = nn.Softmax(dim=-1)
        self.local_conv = nn.Conv1d(channels, channels, kernel_size, 
                                   padding=kernel_size//2, groups=channels, bias=False)

    def forward(self, x):
        b, c, t = x.size()
        x_local = self.local_conv(x)
        
        query = self.query_conv(x_local).permute(0, 2, 1)
        key = self.key_conv(x_local)
        value = self.value_conv(x_local)
        
        attention = self.softmax(torch.bmm(query, key) / math.sqrt(c//8))
        out = torch.bmm(value, attention.permute(0, 2, 1))
        
        out = self.gamma * out + x
        return out


class ECGBlockAttention1D(nn.Module):
    """ECG残差块级注意力：通道+时序双维度增强"""
    def __init__(self, channels):
        super().__init__()
        self.channel_att = ECGChannelAttention1D(channels)
        self.temporal_att = ECGTemporalAttention1D(channels)

    def forward(self, x):
        x = self.channel_att(x)
        x = self.temporal_att(x)
        return x


class Bottleneck1D(nn.Module):
    """增强型1D瓶颈残差块：添加注意力+动态正则化"""
    expansion = 4

    def __init__(self, in_channels, out_channels, stride=1, downsample=None, dropout_rate=0.3):
        super().__init__()
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size=1,
                              stride=1, padding=0, bias=False)
        self.bn1 = nn.BatchNorm1d(out_channels)
        
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size=3,
                              stride=stride, padding=1, bias=False, 
                              groups=max(1, out_channels//16))
        self.bn2 = nn.BatchNorm1d(out_channels)
        
        self.conv3 = nn.Conv1d(out_channels, out_channels * self.expansion,
                              kernel_size=1, stride=1, padding=0, bias=False)
        self.bn3 = nn.BatchNorm1d(out_channels * self.expansion)
        
        self.relu = nn.ReLU(inplace=True)
        self.dropout = nn.Dropout1d(dropout_rate)
        self.downsample = downsample
        self.stride = stride
        
        self.attention = ECGBlockAttention1D(out_channels * self.expansion)
        
        self.fusion = nn.Conv1d(out_channels * self.expansion, 
                               out_channels * self.expansion, 
                               kernel_size=1, bias=False)

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)
        out = self.dropout(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out = self.attention(out)
        out = self.fusion(out)
        
        out += identity
        out = self.relu(out)

        return out


class ResNet1D(nn.Module):
    """优化后的1D ResNet-101，适配心电信号二分类（双通道输出）"""
    def __init__(self, input_channels=1, num_classes=2, segment_length=2000, 
                 dropout_rate=0.2, use_spectral_norm=True):
        super().__init__()
        self.num_classes = num_classes
        self.in_channels = 64
        self.segment_length = segment_length
        self.dropout_rate = dropout_rate

        self.conv1 = nn.Sequential(
            nn.Conv1d(input_channels, 32, kernel_size=5, stride=1, padding=2, bias=False),
            nn.BatchNorm1d(32),
            nn.ReLU(inplace=True),
            nn.Conv1d(32, 64, kernel_size=5, stride=2, padding=2, bias=False),
            nn.BatchNorm1d(64),
            nn.ReLU(inplace=True)
        )
        self.bn1 = nn.BatchNorm1d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool1d(kernel_size=5, stride=2, padding=2)
        self.dropout1 = nn.Dropout1d(dropout_rate * 0.5)

        self.layer1 = self._make_layer(Bottleneck1D, 64, 3, stride=1)
        self.layer2 = self._make_layer(Bottleneck1D, 128, 4, stride=2)
        self.layer3 = self._make_layer(Bottleneck1D, 192, 23, stride=2)
        self.layer4 = self._make_layer(Bottleneck1D, 256, 3, stride=2)

        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.max_pool = nn.AdaptiveMaxPool1d(1)
        self.global_pool = nn.AdaptiveAvgPool1d(4)
        self.temporal_fusion = nn.Conv1d(256 * Bottleneck1D.expansion, 
                                        256 * Bottleneck1D.expansion, 
                                        kernel_size=4, padding=0, bias=False)

        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(256 * Bottleneck1D.expansion * 3, 512),
            nn.LayerNorm(512),
            nn.ReLU(inplace=True),
            nn.AlphaDropout(dropout_rate),
            nn.Linear(512, 128),
            nn.LayerNorm(128),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout_rate * 0.8),
            nn.Linear(128, self.num_classes)
        )

        if use_spectral_norm:
            for m in self.modules():
                if isinstance(m, nn.Conv1d) or isinstance(m, nn.Linear):
                    nn.utils.spectral_norm(m)

        self._initialize_weights()

    def _make_layer(self, block, out_channels, blocks, stride=1):
        downsample = None
        if stride != 1 or self.in_channels != out_channels * block.expansion:
            downsample = nn.Sequential(
                nn.Conv1d(self.in_channels, out_channels * block.expansion,
                         kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm1d(out_channels * block.expansion),
            )

        layers = []
        layers.append(block(self.in_channels, out_channels, stride, 
                           downsample, self.dropout_rate))
        self.in_channels = out_channels * block.expansion
        
        for _ in range(1, blocks):
            layers.append(block(self.in_channels, out_channels,
                               dropout_rate=self.dropout_rate))

        return nn.Sequential(*layers)

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', 
                                       nonlinearity='relu', a=0.01)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight, gain=0.8)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0.001)
            elif isinstance(m, (ECGChannelAttention1D, ECGTemporalAttention1D)):
                for p in m.parameters():
                    if p.dim() > 1:
                        nn.init.xavier_uniform_(p)
                    else:
                        nn.init.constant_(p, 1.0)

    def forward(self, x, lengths=None):
        # ====================== 修复维度：支持任意通道数 ======================
        if x.dim() == 2:
            x = x.unsqueeze(1)  # (batch, seq_len) -> (batch, 1, seq_len)
        # 现在x一定是(batch, channels, seq_len)格式
        # ======================================================

        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.dropout1(x)
        x = self.maxpool(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        avg_feat = self.avg_pool(x).flatten(1)
        max_feat = self.max_pool(x).flatten(1)
        local_feat = self.global_pool(x)
        local_feat = self.temporal_fusion(local_feat).flatten(1)

        fusion_feat = torch.cat([avg_feat, max_feat, local_feat], dim=1)
        logits = self.classifier(fusion_feat)
        
        return logits, None


class MultiScaleConv1d(nn.Module):
    """多尺度并行卷积模块（适配ECG不同波形特征）"""
    def __init__(self, in_channels, out_channels, kernel_sizes=[3,7,15,21,31], padding='same', bias=False):
        super().__init__()
        self.out_channels = out_channels
        self.kernel_sizes = kernel_sizes
        self.num_scales = len(kernel_sizes)
        
        self.convs = nn.ModuleList()
        for ks in kernel_sizes:
            self.convs.append(
                nn.Conv1d(in_channels, out_channels//self.num_scales, kernel_size=ks, 
                          padding=padding, bias=bias)
            )
        
        self.residual_conv = None
        if out_channels % self.num_scales != 0:
            self.residual_conv = nn.Conv1d(in_channels, out_channels % self.num_scales, 
                                          kernel_size=1, padding=padding, bias=bias)

    def forward(self, x):
        conv_outs = []
        for conv in self.convs:
            conv_outs.append(conv(x))
        
        out = torch.cat(conv_outs, dim=1)
        
        if self.residual_conv is not None:
            residual = self.residual_conv(x)
            out = torch.cat([out, residual], dim=1)
        
        return out


class UNet1DClassifier(nn.Module):
    """优化版1D UNet：修复通道注意力维度不匹配+多尺度卷积问题"""
    def __init__(self, 
                 input_channels=1,
                 num_classes=2,
                 input_length=2500,
                 base_filters=32,
                 dropout_rate=0.2):
        super(UNet1DClassifier, self).__init__()
        self.input_channels = input_channels
        self.input_length = input_length
        self.base_filters = base_filters

        self.enc_block1 = nn.Sequential(
            MultiScaleConv1d(input_channels, base_filters, kernel_sizes=[3,7,15], padding='same', bias=False),
            nn.BatchNorm1d(base_filters),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters, base_filters, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )
        self.pool1 = nn.MaxPool1d(kernel_size=2, stride=2)

        self.enc_block2 = nn.Sequential(
            nn.Conv1d(base_filters, base_filters*2, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*2),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters*2, base_filters*2, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*2),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )
        self.pool2 = nn.MaxPool1d(kernel_size=2, stride=2)

        self.enc_block3 = nn.Sequential(
            nn.Conv1d(base_filters*2, base_filters*4, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*4),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters*4, base_filters*4, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*4),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )
        self.pool3 = nn.MaxPool1d(kernel_size=2, stride=2)

        self.enc_block4 = nn.Sequential(
            nn.Conv1d(base_filters*4, base_filters*8, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*8),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters*8, base_filters*8, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*8),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )
        self.pool4 = nn.MaxPool1d(kernel_size=2, stride=2)

        self.bottleneck = nn.Sequential(
            nn.Conv1d(base_filters*8, base_filters*16, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*16),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters*16, base_filters*16, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*16),
            nn.ELU(inplace=True),
            nn.Dropout(0.4)
        )
        self.pool_bottleneck = nn.MaxPool1d(kernel_size=2, stride=2)

        self.upconv1 = nn.ConvTranspose1d(base_filters*16, base_filters*8, kernel_size=2, stride=2, bias=False)
        self.dec_block1 = nn.Sequential(
            nn.Conv1d(base_filters*16, base_filters*4, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*4),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters*4, base_filters*4, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*4),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )

        self.upconv2 = nn.ConvTranspose1d(base_filters*4, base_filters*2, kernel_size=2, stride=2, bias=False)
        self.dec_block2 = nn.Sequential(
            nn.Conv1d(base_filters*6, base_filters*2, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*2),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters*2, base_filters*2, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*2),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )

        self.upconv3 = nn.ConvTranspose1d(base_filters*2, base_filters, kernel_size=2, stride=2, bias=False)
        self.dec_block3 = nn.Sequential(
            nn.Conv1d(base_filters*3, base_filters, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters, base_filters, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )

        self.upconv4 = nn.ConvTranspose1d(base_filters, base_filters, kernel_size=2, stride=2, bias=False)
        self.dec_block4 = nn.Sequential(
            nn.Conv1d(base_filters*2, base_filters, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters, base_filters, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )

        self.global_avg_pool = nn.AdaptiveAvgPool1d(1)
        self.global_max_pool = nn.AdaptiveMaxPool1d(1)
        self.classifier = nn.Sequential(
            nn.Flatten(),  
            nn.Linear(base_filters*2, base_filters),  
            nn.LayerNorm(base_filters),
            nn.ELU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(base_filters, base_filters),
            nn.Sigmoid(),
            nn.Linear(base_filters, base_filters//2),  
            nn.ELU(inplace=True),
            nn.Linear(base_filters//2, num_classes)  
         )

        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, (nn.Conv1d, nn.ConvTranspose1d)):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.LayerNorm):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def _align_length(self, x1, x2):
        target_len = max(x1.size(2), x2.size(2))
        x1_aligned = F.interpolate(x1, size=target_len, mode='linear', align_corners=False)
        x2_aligned = F.interpolate(x2, size=target_len, mode='linear', align_corners=False)
        return x1_aligned, x2_aligned

    def forward(self, x, lengths=None):
        # ====================== 修复维度：支持任意通道数 ======================
        if x.dim() == 2:
            x = x.unsqueeze(1)  # (batch, seq_len) -> (batch, 1, seq_len)
        # 现在x一定是(batch, channels, seq_len)格式
        batch_size, channels, seq_len = x.size()
        # ======================================================

        if seq_len > self.input_length:
            start = (seq_len - self.input_length) // 2
            x = x[:, :, start:start+self.input_length]
        elif seq_len < self.input_length:
            pad_left = (self.input_length - seq_len) // 2
            pad_right = self.input_length - seq_len - pad_left
            x = F.pad(x, (pad_left, pad_right))

        enc1 = self.enc_block1(x)
        pool1 = self.pool1(enc1)

        enc2 = self.enc_block2(pool1)
        pool2 = self.pool2(enc2)

        enc3 = self.enc_block3(pool2)
        pool3 = self.pool3(enc3)

        enc4 = self.enc_block4(pool3)
        pool4 = self.pool4(enc4)

        bottleneck = self.bottleneck(pool4)
        bottleneck_pool = self.pool_bottleneck(bottleneck)

        up1 = self.upconv1(bottleneck_pool)
        up1, enc4_aligned = self._align_length(up1, enc4)
        dec1 = torch.cat([up1, enc4_aligned], dim=1)
        dec1 = self.dec_block1(dec1)

        up2 = self.upconv2(dec1)
        up2, enc3_aligned = self._align_length(up2, enc3)
        dec2 = torch.cat([up2, enc3_aligned], dim=1)
        dec2 = self.dec_block2(dec2)

        up3 = self.upconv3(dec2)
        up3, enc2_aligned = self._align_length(up2, enc2)
        dec3 = torch.cat([up3, enc2_aligned], dim=1)
        dec3 = self.dec_block3(dec3)

        up4 = self.upconv4(dec3)
        up4, enc1_aligned = self._align_length(up4, enc1)
        dec4 = torch.cat([up4, enc1_aligned], dim=1)
        dec4 = self.dec_block4(dec4)

        gap = self.global_avg_pool(dec4)
        gmp = self.global_max_pool(dec4)
        pooled = torch.cat([gap, gmp], dim=1)
        logits = self.classifier(pooled)

        return logits, None


def make_divisible(x, divisor=8):
    result = (x + divisor - 1) // divisor
    return int(result)


class ConvBNReLU(nn.Module):
    def __init__(self, input_channels, output_channels, kernel_size, stride, padding):
        super(ConvBNReLU, self).__init__()
        self.layer = nn.Sequential(
            nn.Conv1d(input_channels, output_channels, kernel_size, stride, padding, bias=False),
            nn.BatchNorm1d(output_channels),
            nn.ReLU()
        )

    def forward(self, x):
        return self.layer(x)


class DepthSeparableConv1d(nn.Module):
     def __init__(self, in_channel, out_channel, kernel_size, stride, padding):
        super(DepthSeparableConv1d, self).__init__()
        self.depth_conv = nn.Conv1d(in_channel, in_channel, kernel_size, stride, padding, groups=in_channel, bias=False)
        self.depth_bn = nn.BatchNorm1d(in_channel)
        self.point_conv = nn.Conv1d(in_channel, out_channel, 1, 1, 0, bias=False)
        self.point_bn = nn.BatchNorm1d(out_channel)

     def forward(self, x):
        x = self.depth_conv(x)
        x = self.depth_bn(x)
        x = F.relu(x, inplace=True)
        x = self.point_conv(x)
        x = self.point_bn(x)
        x = F.relu(x, inplace=True)
        return x


class MobileNetV1_ECG(nn.Module):
    def __init__(self, input_length=2048, in_channels=1, scale=1.0, num_classes=2, dropout_rate=0.3):
        super(MobileNetV1_ECG, self).__init__()
        self.input_length = input_length
        self.in_channels = in_channels

        input_channel = make_divisible(32 * scale)

        self.conv1 = ConvBNReLU(in_channels, input_channel, kernel_size=15, stride=2, padding=7)

        self.conv2 = nn.Sequential(
            DepthSeparableConv1d(input_channel, make_divisible(64*scale), 15, 1, 7),
            DepthSeparableConv1d(make_divisible(64*scale), make_divisible(128*scale), 15, 2, 7),
            DepthSeparableConv1d(make_divisible(128*scale), make_divisible(256*scale), 15, 1, 7),
            DepthSeparableConv1d(make_divisible(256*scale), make_divisible(256*scale), 15, 1, 7),
            DepthSeparableConv1d(make_divisible(256*scale), make_divisible(512*scale), 15, 2, 7),
        )
        input_channel = make_divisible(512 * scale)

        conv3_layers = []
        for i in range(5):
            conv3_layers.append(DepthSeparableConv1d(input_channel, input_channel, 15, 1, 7))
        self.conv3 = nn.Sequential(*conv3_layers)

        last_channel = make_divisible(1024 * scale)
        self.conv4 = nn.Sequential(
            DepthSeparableConv1d(input_channel, last_channel, 15, 2, 7),
            DepthSeparableConv1d(last_channel, last_channel, 15, 2, 7),
        )
       
        self.avgpool = nn.AvgPool1d(kernel_size=64)

        self.classifier = nn.Sequential(
            nn.Dropout(dropout_rate),
            nn.Linear(last_channel, last_channel // 2),
            nn.ReLU(),
            nn.Dropout(dropout_rate * 0.5),
            nn.Linear(last_channel // 2, num_classes)
        )
        
        self._initialize_weights()
        
    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)

    def forward(self, x, lengths=None):
        # ====================== 修复维度：支持任意通道数 ======================
        if x.dim() == 2:
            x = x.unsqueeze(1)  # (batch, seq_len) -> (batch, 1, seq_len)
        # 现在x一定是(batch, channels, seq_len)格式
        batch_size, channels, seq_len = x.size()
        # ======================================================

        if seq_len != self.input_length:
            if seq_len > self.input_length:
                x = x[:, :, :self.input_length]
            else:
                pad_len = self.input_length - seq_len
                x = F.pad(x, (0, pad_len))

        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)

        x = self.avgpool(x)
        x = x.view(batch_size, -1)
        logits = self.classifier(x)

        return logits, None


class BiGRU_ECG(nn.Module):
    def __init__(self, 
                 input_channels=1,
                 num_classes=2,
                 input_length=2000,
                 hidden_dim=128,
                 num_gru_layers=2,
                 dropout_rate=0.2):
        super().__init__()
        self.input_length = input_length
        self.hidden_dim = hidden_dim
        self.num_gru_layers = num_gru_layers
        self.num_classes = num_classes

        self.feature_extractor = nn.Sequential(
            nn.Conv1d(input_channels, 64, kernel_size=7, stride=1, padding=3, bias=False),
            nn.BatchNorm1d(64),
            nn.ELU(inplace=True),
            nn.MaxPool1d(kernel_size=2, stride=2),
            nn.Dropout1d(dropout_rate * 0.5),

            nn.Conv1d(64, 128, kernel_size=5, stride=1, padding=2, bias=False),
            nn.BatchNorm1d(128),
            nn.ELU(inplace=True),
            nn.MaxPool1d(kernel_size=2, stride=2),
            nn.Dropout1d(dropout_rate * 0.5),

            nn.Conv1d(128, hidden_dim, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm1d(hidden_dim),
            nn.ELU(inplace=True),
            nn.MaxPool1d(kernel_size=2, stride=2),
            nn.Dropout1d(dropout_rate)
        )

        self.bigru = nn.GRU(
            input_size=hidden_dim,
            hidden_size=hidden_dim,
            num_layers=num_gru_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout_rate if num_gru_layers > 1 else 0.0
        )

        self.global_avg_pool = nn.AdaptiveAvgPool1d(1)
        self.global_max_pool = nn.AdaptiveMaxPool1d(1)

        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim * 4, hidden_dim * 2),  
            nn.LayerNorm(hidden_dim * 2),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate * 1.2),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim, num_classes)
        )

        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu', a=0.01)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0.0)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1.0)
                nn.init.constant_(m.bias, 0.0)
            elif isinstance(m, nn.GRU):
                for name, param in m.named_parameters():
                    if 'weight' in name:
                        nn.init.xavier_uniform_(param, gain=0.8)
                    elif 'bias' in name:
                        nn.init.constant_(param, 0.0)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight, gain=0.7)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0.001)
            elif isinstance(m, nn.LayerNorm):
                nn.init.constant_(m.weight, 1.0)
                nn.init.constant_(m.bias, 0.0)

    def forward(self, x, lengths=None):
        # ====================== 修复维度：支持任意通道数 ======================
        if x.dim() == 2:
            x = x.unsqueeze(1)  # (batch, seq_len) -> (batch, 1, seq_len)
        # 现在x一定是(batch, channels, seq_len)格式
        batch_size, channels, seq_len = x.size()
        # ======================================================

        if seq_len > self.input_length:
            start = (seq_len - self.input_length) // 2
            x = x[:, :, start:start+self.input_length]
        elif seq_len < self.input_length:
            pad_left = (self.input_length - seq_len) // 2
            pad_right = self.input_length - seq_len - pad_left
            x = F.pad(x, (pad_left, pad_right))

        features = self.feature_extractor(x)
        features = features.permute(0, 2, 1)

        h0 = torch.zeros(
            self.num_gru_layers * 2,
            batch_size,
            self.hidden_dim,
            device=x.device
        )
        gru_out, _ = self.bigru(features, h0)

        gru_out_chan = gru_out.permute(0, 2, 1)
        avg_feat = self.global_avg_pool(gru_out_chan).squeeze(-1)
        max_feat = self.global_max_pool(gru_out_chan).squeeze(-1)
        fusion_feat = torch.cat([avg_feat, max_feat], dim=1)

        logits = self.classifier(fusion_feat).clamp(-1e2, 1e2)
        return logits, None


class AdaptivePool1dSafe(nn.Module):
    def __init__(self, output_size):
        super(AdaptivePool1dSafe, self).__init__()
        self.output_size = output_size

    def forward(self, x):
        input_size = x.size(2)
        if input_size == self.output_size:
            return x
        if input_size < self.output_size:
            pad_size = self.output_size - input_size
            x = F.pad(x, (0, pad_size))
            return F.adaptive_avg_pool1d(x, self.output_size)
        if input_size % self.output_size != 0:
            new_size = (input_size // self.output_size) * self.output_size
            if new_size == 0:
                new_size = self.output_size
            kernel_size = input_size // new_size
            stride = kernel_size
            return F.avg_pool1d(x, kernel_size=kernel_size, stride=stride)
        else:
            return F.adaptive_avg_pool1d(x, self.output_size)


class ECGBatchNorm1d(nn.Module):
    def __init__(self, num_features):
        super(ECGBatchNorm1d, self).__init__()
        self.bn = nn.BatchNorm1d(num_features)

    def forward(self, x):
        if x.size(0) == 1:
            return x
        return self.bn(x)


class MultiHeadAttention(nn.Module):
    def __init__(self, hidden_dim, num_heads=8, dropout=0.1):
        super(MultiHeadAttention, self).__init__()
        assert hidden_dim % num_heads == 0
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads

        self.q_linear = nn.Linear(hidden_dim, hidden_dim)
        self.k_linear = nn.Linear(hidden_dim, hidden_dim)
        self.v_linear = nn.Linear(hidden_dim, hidden_dim)
        self.out_linear = nn.Linear(hidden_dim, hidden_dim)

        self.dropout = nn.Dropout(dropout)
        self.layer_norm = nn.LayerNorm(hidden_dim)

    def forward(self, x, mask=None):
        batch_size, seq_len, hidden_dim = x.size()
        Q = self.q_linear(x)
        K = self.k_linear(x)
        V = self.v_linear(x)

        Q = Q.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        K = K.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        V = V.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)

        scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.head_dim)
        if mask is not None:
            mask = mask.unsqueeze(1).unsqueeze(2)
            scores = scores.masked_fill(~mask, -1e9)

        attention_weights = F.softmax(scores, dim=-1)
        attention_weights = self.dropout(attention_weights)
        context = torch.matmul(attention_weights, V)
        context = context.transpose(1, 2).contiguous().view(batch_size, seq_len, hidden_dim)
        output = self.out_linear(context)
        output = self.dropout(output)
        output = self.layer_norm(x + output)
        return output, attention_weights.mean(dim=1)


class RobustAttention(nn.Module):
    def __init__(self, hidden_dim, attention_dim=128, use_multi_head=False):
        super(RobustAttention, self).__init__()
        self.use_multi_head = use_multi_head

        if use_multi_head:
            self.attention = MultiHeadAttention(hidden_dim)
        else:
            self.attention_network = nn.Sequential(
                nn.Linear(hidden_dim, attention_dim),
                nn.Tanh(),
                nn.Dropout(0.1),
                nn.Linear(attention_dim, 1)
            )
            self.softmax = nn.Softmax(dim=1)

    def forward(self, gru_output, lengths=None):
        batch_size, seq_len, hidden_dim = gru_output.shape

        if self.use_multi_head:
            mask = None
            if lengths is not None:
                device = gru_output.device
                mask = torch.arange(seq_len, device=device).expand(batch_size, seq_len) < lengths.unsqueeze(1)
            attended_output, attention_weights = self.attention(gru_output, mask)
            context_vector = attended_output.mean(dim=1)
        else:
            attention_scores = self.attention_network(gru_output).squeeze(-1)
            if lengths is not None:
                device = gru_output.device
                mask = torch.arange(seq_len, device=device).expand(batch_size, seq_len) < lengths.unsqueeze(1)
                attention_scores = attention_scores.masked_fill(~mask, -1e9)
            attention_weights = self.softmax(attention_scores)
            context_vector = torch.bmm(attention_weights.unsqueeze(1), gru_output).squeeze(1)

        return context_vector, attention_weights


class HierarchicalAttention(nn.Module):
    def __init__(self, hidden_dim, reduction_ratio=8):
        super(HierarchicalAttention, self).__init__()
        self.temporal_attention = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // reduction_ratio),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim // reduction_ratio, 1),
            nn.Sigmoid()
        )
        self.feature_attention = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // reduction_ratio),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim // reduction_ratio, hidden_dim),
            nn.Sigmoid()
        )

    def forward(self, x, lengths=None):
        batch_size, seq_len, hidden_dim = x.shape
        temporal_weights = self.temporal_attention(x)
        feature_weights = self.feature_attention(x.mean(dim=1)).unsqueeze(1)
        attended = x * temporal_weights * feature_weights

        if lengths is not None:
            device = x.device
            mask = torch.arange(seq_len, device=device).expand(batch_size, seq_len) < lengths.unsqueeze(1)
            mask = mask.unsqueeze(-1).float()
            context = (attended * mask).sum(dim=1) / lengths.unsqueeze(1).float()
        else:
            context = attended.mean(dim=1)
        return context, temporal_weights.squeeze(-1)


class AdaptiveAttention(nn.Module):
    def __init__(self, hidden_dim, attention_types=['robust', 'hierarchical']):
        super(AdaptiveAttention, self).__init__()
        self.attention_modules = nn.ModuleDict()
        self.attention_weights = nn.Parameter(torch.ones(len(attention_types)))

        if 'robust' in attention_types:
            self.attention_modules['robust'] = RobustAttention(hidden_dim)
        if 'hierarchical' in attention_types:
            self.attention_modules['hierarchical'] = HierarchicalAttention(hidden_dim)
        if 'multihead' in attention_types:
            self.attention_modules['multihead'] = RobustAttention(hidden_dim, use_multi_head=True)

    def forward(self, x, lengths=None):
        contexts = []
        attention_maps = []
        weights = F.softmax(self.attention_weights, dim=0)

        for i, (name, module) in enumerate(self.attention_modules.items()):
            context, attention = module(x, lengths)
            contexts.append(context * weights[i])
            attention_maps.append(attention)

        fused_context = torch.stack(contexts).sum(dim=0)
        fused_attention = attention_maps[0]
        return fused_context, fused_attention


class MPSCompatibleCNN(nn.Module):
    def __init__(self, output_size=32):
        super(MPSCompatibleCNN, self).__init__()
        self.output_size = output_size

        self.conv_layers = nn.Sequential(
            nn.Conv1d(1, 32, kernel_size=15, stride=2, padding=7),
            ECGBatchNorm1d(32),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),

            nn.Conv1d(32, 64, kernel_size=9, stride=2, padding=4),
            ECGBatchNorm1d(64),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),

            nn.Conv1d(64, 128, kernel_size=7, stride=2, padding=3),
            ECGBatchNorm1d(128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),

            nn.Conv1d(128, 256, kernel_size=5, stride=2, padding=2),
            ECGBatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),
        )
        self.pool = AdaptivePool1dSafe(output_size)

    def forward(self, x):
        features = self.conv_layers(x)
        pooled_features = self.pool(features)
        return pooled_features


class RobustCNNBiGRU(nn.Module):
    def __init__(self, num_classes=9, attention_type='robust'):
        super(RobustCNNBiGRU, self).__init__()
        self.cnn = MPSCompatibleCNN(output_size=32)
        self.gru = nn.GRU(
            input_size=256,
            hidden_size=128,
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=0.3
        )

        if attention_type == 'robust':
            self.attention = RobustAttention(256)
        elif attention_type == 'hierarchical':
            self.attention = HierarchicalAttention(256)
        elif attention_type == 'multihead':
            self.attention = RobustAttention(256, use_multi_head=True)
        elif attention_type == 'adaptive':
            self.attention = AdaptiveAttention(256)
        else:
            self.attention = RobustAttention(256)

        self.classifier = nn.Sequential(
            nn.Dropout(0.5),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(128, num_classes)
        )
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)

    def forward(self, x, lengths=None):
        # ====================== 修复维度：支持任意通道数 ======================
        if x.dim() == 2:
            x = x.unsqueeze(1)  # (batch, seq_len) -> (batch, 1, seq_len)
        # 现在x一定是(batch, channels, seq_len)格式
        batch_size, channels, seq_len = x.size()
        target_length = 2500
        # ======================================================

        if seq_len > target_length:
            x = x[:, :, :target_length]
        elif seq_len < target_length:
            x = F.pad(x, (0, target_length - seq_len))

        cnn_features = self.cnn(x)
        cnn_features = cnn_features.transpose(1, 2)
        gru_output, _ = self.gru(cnn_features)

        if lengths is not None:
            lengths = lengths.to(gru_output.device)
        context, attention_weights = self.attention(gru_output, lengths)
        logits = self.classifier(context)
        return logits, attention_weights


class PureBiGRU_ECG(nn.Module):
    def __init__(self, 
                 input_channels=1,
                 num_classes=2,
                 input_length=2000,
                 hidden_dim=128,
                 num_gru_layers=2,
                 dropout_rate=0.2):
        super().__init__()
        self.input_length = input_length
        self.hidden_dim = hidden_dim
        self.num_gru_layers = num_gru_layers
        self.num_classes = num_classes

        self.input_proj = nn.Sequential(
            nn.Linear(input_length, hidden_dim * 4),
            nn.LayerNorm(hidden_dim * 4),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim * 4, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ELU(inplace=True)
        )

        self.bigru = nn.GRU(
            input_size=hidden_dim,
            hidden_size=hidden_dim,
            num_layers=num_gru_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout_rate if num_gru_layers > 1 else 0.0
        )

        self.global_avg_pool = nn.AdaptiveAvgPool1d(1)
        self.global_max_pool = nn.AdaptiveMaxPool1d(1)

        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim * 4, hidden_dim * 2),  
            nn.LayerNorm(hidden_dim * 2),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate * 0.8),
            nn.Linear(hidden_dim, num_classes)
        )
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.GRU):
                for name, param in m.named_parameters():
                    if 'weight' in name:
                        nn.init.xavier_uniform_(param, gain=0.8)
                    elif 'bias' in name:
                        nn.init.constant_(param, 0.0)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight, gain=0.7)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0.001)
            elif isinstance(m, nn.LayerNorm):
                nn.init.constant_(m.weight, 1.0)
                nn.init.constant_(m.bias, 0.0)

    def forward(self, x, lengths=None):
        # ====================== 修复维度：支持任意通道数 ======================
        if x.dim() == 3:
            # 多通道输入：对所有通道取平均
            x = x.mean(dim=1)
        # 现在x一定是(batch, seq_len)格式
        batch_size, seq_len = x.size()
        # ======================================================

        if seq_len > self.input_length:
            start = (seq_len - self.input_length) // 2
            x = x[:, start:start+self.input_length]
        elif seq_len < self.input_length:
            pad_left = (self.input_length - seq_len) // 2
            pad_right = self.input_length - seq_len - pad_left
            x = F.pad(x, (pad_left, pad_right))

        x_proj = self.input_proj(x)
        x_seq = x_proj.unsqueeze(1).repeat(1, 32, 1)

        h0 = torch.zeros(
            self.num_gru_layers * 2,
            batch_size,
            self.hidden_dim,
            device=x.device
        )
        gru_out, _ = self.bigru(x_seq, h0)

        gru_out_chan = gru_out.permute(0, 2, 1)
        avg_feat = self.global_avg_pool(gru_out_chan).squeeze(-1)
        max_feat = self.global_max_pool(gru_out_chan).squeeze(-1)
        fusion_feat = torch.cat([avg_feat, max_feat], dim=1)
        logits = self.classifier(fusion_feat)
        return logits, None


class WorkingECGModel(nn.Module):
    def __init__(self, num_classes=9, attention_type='hierarchical'):
        super(WorkingECGModel, self).__init__()
        self.cnn = MPSCompatibleCNN(output_size=32)
        self.gru = nn.GRU(
            input_size=256,
            hidden_size=64,
            num_layers=1,
            batch_first=True,
            bidirectional=True,
            dropout=0.1
        )

        if attention_type == 'robust':
            self.attention = RobustAttention(128)
        elif attention_type == 'hierarchical':
            self.attention = HierarchicalAttention(128)
        elif attention_type == 'multihead':
            self.attention = RobustAttention(128, use_multi_head=True)
        elif attention_type == 'adaptive':
            self.attention = AdaptiveAttention(128)
        else:
            self.attention = HierarchicalAttention(128)

        self.classifier = nn.Sequential(
            nn.Dropout(0.3),
            nn.Linear(128, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.2),
            nn.Linear(128, num_classes)
        )
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)

    def forward(self, x, lengths=None):
        # ====================== 修复维度：支持任意通道数 ======================
        if x.dim() == 2:
            x = x.unsqueeze(1)  # (batch, seq_len) -> (batch, 1, seq_len)
        # 现在x一定是(batch, channels, seq_len)格式
        batch_size, channels, seq_len = x.size()
        target_length = 2500
        # ======================================================

        if seq_len > target_length:
            x = x[:, :, :target_length]
        elif seq_len < target_length:
            x = F.pad(x, (0, target_length - seq_len))

        cnn_features = self.cnn(x)
        cnn_features = cnn_features.transpose(1, 2)
        gru_output, _ = self.gru(cnn_features)

        if lengths is not None:
            lengths = lengths.to(gru_output.device)
        context, attention_weights = self.attention(gru_output, lengths)
        logits = self.classifier(context)
        return logits, attention_weights


class SimpleButEffectiveModel(nn.Module):
    def __init__(self, num_classes=9):
        super(SimpleButEffectiveModel, self).__init__()
        self.cnn = MPSCompatibleCNN(output_size=32)
        self.gru = nn.GRU(
            input_size=256,
            hidden_size=64,
            num_layers=1,
            batch_first=True,
            bidirectional=True
        )
        self.attention = RobustAttention(128)
        self.classifier = nn.Sequential(
            nn.Dropout(0.4),
            nn.Linear(128, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.2),
            nn.Linear(128, num_classes)
        )
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)

    def forward(self, x, lengths=None):
        # ====================== 修复维度：支持任意通道数 ======================
        if x.dim() == 2:
            x = x.unsqueeze(1)  # (batch, seq_len) -> (batch, 1, seq_len)
        # 现在x一定是(batch, channels, seq_len)格式
        batch_size, channels, seq_len = x.size()
        target_length = 2500
        # ======================================================

        if seq_len > target_length:
            x = x[:, :, :target_length]
        elif seq_len < target_length:
            x = F.pad(x, (0, target_length - seq_len))

        features = self.cnn(x)
        features = features.transpose(1, 2)
        gru_output, _ = self.gru(features)

        if lengths is not None:
            lengths = lengths.to(gru_output.device)
        context, attention_weights = self.attention(gru_output, lengths)
        logits = self.classifier(context)
        return logits, attention_weights


class DebuggableECGModel(nn.Module):
    def __init__(self, num_classes=9):
        super(DebuggableECGModel, self).__init__()
        self.num_classes = num_classes

        self.conv_layers = nn.Sequential(
            nn.Conv1d(1, 32, 15, stride=2, padding=7),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.MaxPool1d(3, stride=2, padding=1),

            nn.Conv1d(32, 64, 7, stride=2, padding=3),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(3, stride=2, padding=1),

            nn.Conv1d(64, 128, 5, stride=1, padding=2),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),
        )

        self.classifier = nn.Sequential(
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, num_classes)
        )
        print(f"模型初始化: 输出维度 {num_classes}")

    def forward(self, x, lengths=None):
        # ====================== 修复维度：支持任意通道数 ======================
        if x.dim() == 2:
            x = x.unsqueeze(1)  # (batch, seq_len) -> (batch, 1, seq_len)
        # 现在x一定是(batch, channels, seq_len)格式
        batch_size, channels, seq_len = x.size()
        # ======================================================

        if torch.isnan(x).any():
            print("警告: 输入包含NaN")

        x = x[:, :, :2500] if x.size(2) > 2500 else F.pad(x, (0, 2500 - x.size(2)))

        features = self.conv_layers(x)
        features = features.squeeze(-1)
        logits = self.classifier(features)

        if torch.isnan(logits).any():
            print("警告: 输出包含NaN")
        return logits, None