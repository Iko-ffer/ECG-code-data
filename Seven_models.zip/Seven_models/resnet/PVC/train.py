import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F
from sklearn.metrics import f1_score, accuracy_score, roc_auc_score
import time
import warnings
import matplotlib.pyplot as plt
import seaborn as sns
from torch.optim.lr_scheduler import CosineAnnealingLR, ReduceLROnPlateau, CosineAnnealingWarmRestarts
from sklearn.metrics import (
    accuracy_score, 
    f1_score, 
    precision_score,  
    recall_score,    
    confusion_matrix, 
    classification_report
)
from torch.utils.data import WeightedRandomSampler

warnings.filterwarnings('ignore')


class FPWeightedFocalLoss(nn.Module):
    def __init__(self, class_weights, gamma=2, fp_weight=1.5):
        super().__init__()
        self.class_weights = class_weights
        self.gamma = gamma
        self.fp_weight = fp_weight  

    def forward(self, logits, targets):
        ce_loss = F.cross_entropy(logits, targets, weight=self.class_weights, reduction='none')
        pt = torch.exp(-ce_loss)
        focal_loss = (1 - pt) ** self.gamma * ce_loss
        
        
        fp_mask = (targets == 0) & (torch.argmax(logits, dim=1) == 1)
        focal_loss[fp_mask] *= self.fp_weight
        
        return focal_loss.mean()


class DebugTrainer:
    

    def __init__(self, model, device, model_name="debug_model"):
        self.model = model
        self.device = device
        self.model_name = model_name
        
        # 禁用混合精度训练，避免数值不稳定
        self.scaler = None
        self.use_amp = False

        class_weights = torch.tensor([1.0, 1.5], device=device)  
        self.criterion = FPWeightedFocalLoss(
            class_weights=class_weights,
            gamma=2,
            fp_weight=1.0  
        )

    
        self.optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-5)
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer, mode='max', factor=0.5, patience=10
        )
 
        self.best_accuracy = 0.0
        self.best_f1 = 0.0
        self.best_sensitivity = 0.0
        self.best_specificity = 0.0
        self.patience_counter = 0
        self.epoch = 0

        
        self.train_losses = []
        self.val_losses = []
        self.train_accuracies = []
        self.val_accuracies = []
        self.val_sensitivities = []  
        self.val_specificities = []  
        self.learning_rates = []
        self.epoch_times = []

        print(f"训练器初始化: 学习率=0.0001, 设备={device}, FP惩罚权重=2.5")

    def _compute_metrics(self, y_true, y_pred):
        return {
            'sensitivity': recall_score(y_true, y_pred, pos_label=1, zero_division=0),
            'specificity': recall_score(y_true, y_pred, pos_label=0, zero_division=0)
        }
   
    def train_epoch_debug(self, dataloader, epoch):
        self.model.train()
        running_loss = 0.0
        all_preds = []
        all_targets = []

        start_time = time.time()

        for batch_idx, (data, targets) in enumerate(dataloader):
            data = data.to(self.device, non_blocking=True)
            targets = targets.to(self.device, non_blocking=True)
            
            # 数据检查：防止NaN或Inf
            if torch.isnan(data).any() or torch.isinf(data).any():
                print(f"Epoch {epoch}, Batch {batch_idx}: 输入数据包含NaN或Inf!")
                continue
            
            if torch.isnan(targets).any() or torch.isinf(targets).any():
                print(f"Epoch {epoch}, Batch {batch_idx}: 目标标签包含NaN或Inf!")
                continue

            self.optimizer.zero_grad()
            
            outputs, _ = self.model(data)
            loss = self.criterion(outputs, targets)
            
            if torch.isnan(loss):
                print(f"Epoch {epoch}, Batch {batch_idx}: 损失为NaN!")
                continue
            
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()

            running_loss += loss.item()
            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_targets.extend(targets.cpu().numpy())

            if batch_idx % 10 == 0:
                batch_acc = accuracy_score(targets.cpu().numpy(), preds.cpu().numpy())
                batch_metrics = self._compute_metrics(targets.cpu().numpy(), preds.cpu().numpy())
                print(f"  Batch {batch_idx}: loss={loss.item():.4f}, acc={batch_acc:.3f}, "
                      f"sens={batch_metrics['sensitivity']:.3f}, spec={batch_metrics['specificity']:.3f}")

        epoch_time = time.time() - start_time
        epoch_loss = running_loss / len(dataloader)
        epoch_acc = accuracy_score(all_targets, all_preds)

        return epoch_loss, epoch_acc, epoch_time

    def validate_epoch_debug(self, dataloader):
        self.model.eval()
        running_loss = 0.0
        all_preds = []
        all_targets = []

        with torch.no_grad():
            for data, targets in dataloader:
                data = data.to(self.device, non_blocking=True)
                targets = targets.to(self.device, non_blocking=True)

                outputs, _ = self.model(data)
                loss = self.criterion(outputs, targets)

                running_loss += loss.item()
                _, preds = torch.max(outputs, 1)
                all_preds.extend(preds.cpu().numpy())
                all_targets.extend(targets.cpu().numpy())

        epoch_loss = running_loss / len(dataloader)
        epoch_acc = accuracy_score(all_targets, all_preds)
        epoch_f1 = f1_score(all_targets, all_preds, average='weighted')

        metrics = self._compute_metrics(all_targets, all_preds)
        self.val_sensitivities.append(metrics['sensitivity'])
        self.val_specificities.append(metrics['specificity'])
        
        print(f"  预测分布: {dict(zip(np.unique(all_preds), np.bincount(all_preds)))}")
        print(f"  验证指标: 灵敏度={metrics['sensitivity']:.3f}, 特异性={metrics['specificity']:.3f}")  # 新增

        return epoch_loss, epoch_acc, epoch_f1


    def train(self, train_loader, val_loader, epochs=100, patience=20):
 
        self.model.train()

        best_val_loss = float('inf')
        patience_counter = 0

        for epoch in range(epochs):
            print(f'\nEpoch [{epoch + 1}/{epochs}]')

            train_loss, train_acc, epoch_time = self.train_epoch_debug(train_loader, epoch + 1)
            val_loss, val_acc, val_f1 = self.validate_epoch_debug(val_loader)

            self.scheduler.step(val_acc)  # ReduceLROnPlateau需要传入监控指标
            current_lr = self.optimizer.param_groups[0]['lr']


            self.train_losses.append(train_loss)
            self.val_losses.append(val_loss)
            self.train_accuracies.append(train_acc)
            self.val_accuracies.append(val_acc)
            self.learning_rates.append(current_lr)
            self.epoch_times.append(epoch_time)

            print(f'  学习率: {current_lr:.2e}')
            print(f'  训练: 损失={train_loss:.4f}, 准确率={train_acc:.4f}')
            print(f'  验证: 损失={val_loss:.4f}, 准确率={val_acc:.4f}, F1={val_f1:.4f}')
            if len(self.val_sensitivities) > 0:
                print(f'  核心指标: 灵敏度={self.val_sensitivities[-1]:.3f}, 特异性={self.val_specificities[-1]:.3f}')  # 新增
            print(f'  时间: {epoch_time:.1f}s')

            if val_acc > self.best_accuracy + 0.001:
                improvement = True
            else:
                improvement = False
                patience_counter += 1

            if improvement:
                self.best_accuracy = max(self.best_accuracy, val_acc)
                self.best_f1 = max(self.best_f1, val_f1)
                self.best_sensitivity = max(self.best_sensitivity, self.val_sensitivities[-1])  # 新增
                self.best_specificity = max(self.best_specificity, self.val_specificities[-1])  # 新增
                best_val_loss = min(best_val_loss, val_loss)
                patience_counter = 0

                torch.save({
                    'model_state_dict': self.model.state_dict(),
                    'optimizer_state_dict': self.optimizer.state_dict(),
                    'scheduler_state_dict': self.scheduler.state_dict(),
                    'best_accuracy': self.best_accuracy,
                    'best_sensitivity': self.best_sensitivity,  
                    'best_specificity': self.best_specificity,  
                    'epoch': epoch
                }, f'best_{self.model_name}.pth')

                print(f"   保存最佳模型: 准确率={val_acc:.4f}, 特异性={self.val_specificities[-1]:.3f}")  

            print(f"  耐心计数: {patience_counter}/{patience}")

            if epoch >= 5 and max(self.val_accuracies[-5:]) < 0.1:
                print("  准确率持续低于10%")
                print("  建议检查数据预处理和标签")
                break

            if patience_counter >= patience:
                print(f"   早停于第 {epoch + 1} 轮")
                break

       
        try:
            checkpoint = torch.load(f'best_{self.model_name}.pth')
            self.model.load_state_dict(checkpoint['model_state_dict'])
            print(f"   加载最佳模型成功，最佳特异性={checkpoint['best_specificity']:.3f}")  
        except:
            print("    加载最佳模型失败")

        total_time = sum(self.epoch_times)
        print(f" 训练完成! 总时间: {total_time / 60:.1f}分钟")
        print(f" 最佳验证指标:")
        print(f"   准确率: {self.best_accuracy:.4f}")
        print(f"   灵敏度: {self.best_sensitivity:.4f}")  
        print(f"   特异性: {self.best_specificity:.4f}")  

    def evaluate(self, test_loader, device):
        self.model.eval()
        all_preds = []
        all_labels = []
        all_probs = []

        with torch.no_grad():
            for batch_idx, batch_data in enumerate(test_loader):
                batch = list(batch_data)
                valid_items = []
                for item in batch:
                    if isinstance(item, torch.Tensor):  
                        valid_items.append(item)
                    else:
                        print(f"警告：测试批次 {batch_idx} 包含非张量数据（{type(item)}），已过滤")
        
                if len(valid_items) < 2:
                    print(f"警告：测试批次 {batch_idx} 有效张量不足2个（实际{len(valid_items)}个），跳过")
                    continue
            
                signals, labels = valid_items[0], valid_items[1]
            
                signals = signals.to(device, non_blocking=True)  
                labels = labels.to(device, non_blocking=True)
            
                if labels.dim() > 1:
                    labels = labels.squeeze(dim=1)  
            
                model_output = self.model(signals.unsqueeze(1))  
                outputs = model_output[0] if isinstance(model_output, tuple) else model_output
            
                probs = torch.nn.functional.softmax(outputs, dim=1)[:, 1] 
                preds = (probs > 0.5).long()  
            
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
                all_probs.extend(probs.cpu().numpy())

        if len(all_labels) == 0:
            print("警告：无有效测试数据，返回默认指标")
            return {
            'accuracy': 0.0,
            'f1': 0.0,
            'auroc': 0.0,
            'sensitivity': 0.0,
            'specificity': 0.0
            }

        accuracy = accuracy_score(all_labels, all_preds)
        f1 = f1_score(all_labels, all_preds, zero_division=0)
        auroc = roc_auc_score(all_labels, all_probs) if len(set(all_labels)) > 1 else 0.0
        sensitivity = recall_score(all_labels, all_preds, zero_division=0)

        try:
            specificity = recall_score(all_labels, all_preds, pos_label=0, zero_division=0)
        except Exception as e:
            print(f"警告：特异性计算失败 - {str(e)}，返回0.0")
            specificity = 0.0

    
        cm = confusion_matrix(all_labels, all_preds)
        print("\n 测试集混淆矩阵:")
        print(f"   真阴性(TN): {cm[0,0]}, 假阳性(FP): {cm[0,1]}")
        print(f"   假阴性(FN): {cm[1,0]}, 真阳性(TP): {cm[1,1]}")

        return {
        'accuracy': accuracy,
        'f1': f1,
        'auroc': auroc,
        'sensitivity': sensitivity,
        'specificity': specificity
        }




class WorkingTrainer:
    """能正常工作的训练器"""

    def __init__(self, model, device, model_name="working_model"):
        self.model = model
        self.device = device
        self.model_name = model_name

        # 稳定的优化器配置
        self.optimizer = torch.optim.Adam(
            model.parameters(),
            lr=0.0003,  # 更小的学习率
            weight_decay=1e-4
        )

        # 温和的学习率调度
        self.scheduler = ReduceLROnPlateau(
            self.optimizer,
            mode='max',
            factor=0.5,
            patience=10
        )

        self.criterion = nn.CrossEntropyLoss()

        # 训练历史
        self.train_losses = []
        self.val_losses = []
        self.train_accuracies = []
        self.val_accuracies = []

        self.best_accuracy = 0
    
    def save_model(self, lead_name):
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'best_accuracy': self.best_accuracy,
            'epoch': self.epoch,
            'lead_name': lead_name  # 保存导联信息
        }, f'best_{self.model_name}_{lead_name}.pth')

    def train(self, train_loader, val_loader, epochs=100, patience=25):
        """稳定的训练过程"""
        print(" 开始稳定训练...")

        for epoch in range(epochs):
            # 训练
            self.model.train()
            train_loss = 0.0
            train_correct = 0
            train_total = 0

            for data, targets in train_loader:
                data, targets = data.to(self.device), targets.to(self.device)

                self.optimizer.zero_grad()
                outputs, _ = self.model(data)
                loss = self.criterion(outputs, targets)
                loss.backward()

                # 温和的梯度裁剪
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 5.0)
                self.optimizer.step()

                train_loss += loss.item()
                _, predicted = outputs.max(1)
                train_total += targets.size(0)
                train_correct += predicted.eq(targets).sum().item()

            train_acc = 100. * train_correct / train_total
            train_loss = train_loss / len(train_loader)

            # 验证
            self.model.eval()
            val_loss = 0.0
            val_correct = 0
            val_total = 0

            with torch.no_grad():
                for data, targets in val_loader:
                    data, targets = data.to(self.device), targets.to(self.device)
                    outputs, _ = self.model(data)
                    loss = self.criterion(outputs, targets)

                    val_loss += loss.item()
                    _, predicted = outputs.max(1)
                    val_total += targets.size(0)
                    val_correct += predicted.eq(targets).sum().item()

            val_acc = 100. * val_correct / val_total
            val_loss = val_loss / len(val_loader)

            # 学习率调整
            self.scheduler.step(val_acc)

            # 记录历史
            self.train_losses.append(train_loss)
            self.val_losses.append(val_loss)
            self.train_accuracies.append(train_acc)
            self.val_accuracies.append(val_acc)

            # 打印进度
            if (epoch + 1) % 5 == 0 or epoch == 0:
                print(f'Epoch [{epoch + 1}/{epochs}]')
                print(f'  训练: 损失={train_loss:.4f}, 准确率={train_acc:.2f}%')
                print(f'  验证: 损失={val_loss:.4f}, 准确率={val_acc:.2f}%')

            # 保存最佳模型
            if val_acc > self.best_accuracy:
                self.best_accuracy = val_acc
                torch.save({
                    'model_state_dict': self.model.state_dict(),
                    'best_accuracy': self.best_accuracy,
                    'epoch': epoch
                }, f'best_{self.model_name}.pth')

                if (epoch + 1) % 10 == 0:
                    print(f'  💾 保存最佳模型: {val_acc:.2f}%')

        print(f" 训练完成! 最佳验证准确率: {self.best_accuracy:.2f}%")
    
    def evaluate(self, test_loader, device):
        """评估模型"""
        self.model.eval()
        all_preds = []
        all_labels = []
        all_probs = []
    
        with torch.no_grad():
            for batch_data in test_loader:  # 不再直接解包，先接收完整批次数据
                # 核心修复3：适配可变长度返回值（只取前2个值：signals和labels）
                if len(batch_data) >= 2:
                    signals, labels = batch_data[0], batch_data[1]
                else:
                    print(f"警告：测试批次数据格式异常，跳过")
                    continue
                
                signals = signals.to(device)
                labels = labels.to(device)
                
                # 修复模型输入：如果模型返回 (outputs, _)，需正确解包
                model_output = self.model(signals.unsqueeze(1))  # 增加通道维度
                if isinstance(model_output, tuple):
                    outputs = model_output[0]  # 取模型输出的第一个元素（logits）
                else:
                    outputs = model_output
                
                probs = torch.nn.functional.softmax(outputs, dim=1)[:, 1]  # 二分类正类概率
                preds = (probs > 0.5).long()
            
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
                all_probs.extend(probs.cpu().numpy())

        # 处理可能的空数据情况
        if len(all_labels) == 0:
            print("警告：无有效测试数据，返回默认指标")
            return {
                'accuracy': 0.0,
                'f1': 0.0,
                'auroc': 0.0,
                'sensitivity': 0.0,
                'specificity': 0.0
            }

        accuracy = accuracy_score(all_labels, all_preds)
        f1 = f1_score(all_labels, all_preds)
        auroc = roc_auc_score(all_labels, all_probs) if len(set(all_labels)) > 1 else 0.0
        sensitivity = recall_score(all_labels, all_preds)
        
        # 处理特异性计算可能的错误（无负类时）
        try:
            specificity = precision_score(all_labels, all_preds, pos_label=0)
        except:
            specificity = 0.0

        return {
            'accuracy': accuracy,
            'f1': f1,
            'auroc': auroc,
            'sensitivity': sensitivity,
            'specificity': specificity
        }