import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F
from sklearn.metrics import f1_score, accuracy_score, roc_auc_score
import time
import warnings
import matplotlib.pyplot as plt
import seaborn as sns
from torch.optim.lr_scheduler import CosineAnnealingLR, ReduceLROnPlateau, CosineAnnealingWarmRestarts
from sklearn.metrics import (
    accuracy_score, 
    f1_score, 
    precision_score,  
    recall_score,    
    confusion_matrix, 
    classification_report
)
from torch.utils.data import WeightedRandomSampler



class FPWeightedFocalLoss(nn.Module):
    def __init__(self, class_weights=None, gamma=2, fp_weight=1.0):
        super().__init__()
        self.class_weights = class_weights
        self.gamma = gamma
        self.fp_weight = fp_weight  # 正常1.0即可，不要放大

    def forward(self, logits, targets):
        # 标准focal loss
        ce_loss = F.cross_entropy(logits, targets, weight=self.class_weights, reduction='none')
        pt = torch.exp(-ce_loss)
        focal_loss = (1 - pt) ** self.gamma * ce_loss
        
        # 温和FP惩罚，仅在 fp_weight>1 时启用
        if self.fp_weight > 1.0:
            pred = torch.argmax(logits, dim=1)
            fp_mask = (targets.long() == 0) & (pred == 1)
            focal_loss[fp_mask] *= self.fp_weight

        return focal_loss.mean()


class DebugTrainer:
    def __init__(self, model, device, model_name="debug_model"):
        self.model = model
        self.device = device
        self.model_name = model_name

        # ====================== 修复：合理类别权重 ======================
        class_weights = torch.tensor([1.0, 4.0], device=device)  # 正常RBBB推荐 1:4
        self.criterion = FPWeightedFocalLoss(
            class_weights=class_weights,
            gamma=2,
            fp_weight=1.0  # 关闭强惩罚，避免训练崩溃
        )

        # 优化器
        self.optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-5)
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            self.optimizer, T_0=10, T_mult=2, eta_min=1e-6
        )

        # 最佳指标
        self.best_accuracy = 0.0
        self.best_f1 = 0.0
        self.best_sensitivity = 0.0
        self.best_specificity = 0.0
        self.patience_counter = 0
        self.epoch = 0

        # 日志
        self.train_losses = []
        self.val_losses = []
        self.train_accuracies = []
        self.val_accuracies = []
        self.val_sensitivities = []
        self.val_specificities = []
        self.learning_rates = []
        self.epoch_times = []


    def _compute_metrics(self, y_true, y_pred):
        return {
            'sensitivity': recall_score(y_true, y_pred, pos_label=1, zero_division=0),
            'specificity': recall_score(y_true, y_pred, pos_label=0, zero_division=0)
        }

    def train_epoch_debug(self, dataloader, epoch):
        self.model.train()
        running_loss = 0.0
        all_preds = []
        all_targets = []
        start_time = time.time()

        for batch_idx, (data, targets) in enumerate(dataloader):
            data = data.to(self.device, non_blocking=True)
            targets = targets.to(self.device, non_blocking=True)

            # 确保形状正确 [B, 1, 2500]
            if data.dim() == 2:
                data = data.unsqueeze(1)

            self.optimizer.zero_grad()
            outputs = self.model(data)
            if isinstance(outputs, tuple):
                outputs = outputs[0]

            loss = self.criterion(outputs, targets)

            if torch.isnan(loss):
                print(f"NaN损失，跳过batch")
                continue

            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()

            running_loss += loss.item()
            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_targets.extend(targets.cpu().numpy())

        epoch_time = time.time() - start_time
        epoch_loss = running_loss / len(dataloader)
        epoch_acc = accuracy_score(all_targets, all_preds)
        return epoch_loss, epoch_acc, epoch_time

    def validate_epoch_debug(self, dataloader):
        self.model.eval()
        running_loss = 0.0
        all_preds = []
        all_targets = []

        with torch.no_grad():
            for data, targets in dataloader:
                data = data.to(self.device, non_blocking=True)
                targets = targets.to(self.device, non_blocking=True)

                if data.dim() == 2:
                    data = data.unsqueeze(1)

                outputs = self.model(data)
                if isinstance(outputs, tuple):
                    outputs = outputs[0]

                loss = self.criterion(outputs, targets)
                running_loss += loss.item()
                _, preds = torch.max(outputs, 1)

                all_preds.extend(preds.cpu().numpy())
                all_targets.extend(targets.cpu().numpy())

        epoch_loss = running_loss / len(dataloader)
        epoch_acc = accuracy_score(all_targets, all_preds)
        epoch_f1 = f1_score(all_targets, all_preds, average='binary', zero_division=0)
        metrics = self._compute_metrics(all_targets, all_preds)

        self.val_sensitivities.append(metrics['sensitivity'])
        self.val_specificities.append(metrics['specificity'])

        print(f"  验证：acc={epoch_acc:.3f} | f1={epoch_f1:.3f} | sens={metrics['sensitivity']:.3f} | spec={metrics['specificity']:.3f}")
        return epoch_loss, epoch_acc, epoch_f1

    def train(self, train_loader, val_loader, epochs=100, patience=12):
        best_val_f1 = 0.0
        patience_counter = 0

        for epoch in range(epochs):
            print(f'\n=== Epoch {epoch+1}/{epochs} ===')
            train_loss, train_acc, epoch_time = self.train_epoch_debug(train_loader, epoch+1)
            val_loss, val_acc, val_f1 = self.validate_epoch_debug(val_loader)
            self.scheduler.step()

            # 记录
            self.train_losses.append(train_loss)
            self.val_losses.append(val_loss)
            self.train_accuracies.append(train_acc)
            self.val_accuracies.append(val_acc)

            # ====================== 修复：按F1保存最佳模型 ======================
            if val_f1 > best_val_f1 + 0.001:
                best_val_f1 = val_f1
                self.best_accuracy = val_acc
                self.best_f1 = val_f1
                self.best_sensitivity = self.val_sensitivities[-1]
                self.best_specificity = self.val_specificities[-1]
                patience_counter = 0

                torch.save({
                    'model_state_dict': self.model.state_dict(),
                    'best_f1': best_val_f1,
                    'best_accuracy': self.best_accuracy,
                }, f'best_{self.model_name}.pth')
                print(f" 保存最佳模型 | F1={val_f1:.4f}")
            else:
                patience_counter += 1

            print(f"  训练损失：{train_loss:.4f} | 耐心：{patience_counter}/{patience}")

            if patience_counter >= patience:
                print(" 早停")
                break

        # 加载最佳模型
        try:
            ckpt = torch.load(f'best_{self.model_name}.pth')
            self.model.load_state_dict(ckpt['model_state_dict'])
        except:
            print(" 无法加载最佳模型")

    def evaluate(self, test_loader, device):
        self.model.eval()
        all_labels = []
        all_preds = []
        all_probs = []

        with torch.no_grad():
            for data, labels in test_loader:
                data = data.to(device)
                labels = labels.to(device)

                if data.dim() == 2:
                    data = data.unsqueeze(1)

                outputs = self.model(data)
                if isinstance(outputs, tuple):
                    outputs = outputs[0]

                probs = F.softmax(outputs, dim=1)[:, 1]
                preds = (probs > 0.5).long()

                all_labels.extend(labels.cpu().numpy())
                all_preds.extend(preds.cpu().numpy())
                all_probs.extend(probs.cpu().numpy())

        accuracy = accuracy_score(all_labels, all_preds)
        f1 = f1_score(all_labels, all_preds, zero_division=0)
        auroc = roc_auc_score(all_labels, all_probs) if len(set(all_labels))>1 else 0.0
        sensitivity = recall_score(all_labels, all_preds, zero_division=0)
        specificity = recall_score(all_labels, all_preds, pos_label=0, zero_division=0)

        print(f"\n测试结果：ACC={accuracy:.3f} | F1={f1:.3f} | AUROC={auroc:.3f}")
        return {"accuracy":accuracy,"f1":f1,"auroc":auroc,"sensitivity":sensitivity,"specificity":specificity}


class WorkingTrainer:
    """能正常工作的训练器"""

    def __init__(self, model, device, model_name="working_model"):
        self.model = model
        self.device = device
        self.model_name = model_name

        # 稳定的优化器配置
        self.optimizer = torch.optim.Adam(
            model.parameters(),
            lr=0.0003,  # 更小的学习率
            weight_decay=1e-4
        )

        # 温和的学习率调度
        self.scheduler = ReduceLROnPlateau(
            self.optimizer,
            mode='max',
            factor=0.5,
            patience=10
        )

        self.criterion = nn.CrossEntropyLoss()

        # 训练历史
        self.train_losses = []
        self.val_losses = []
        self.train_accuracies = []
        self.val_accuracies = []

        self.best_accuracy = 0
    
    def save_model(self, lead_name):
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'best_accuracy': self.best_accuracy,
            'epoch': self.epoch,
            'lead_name': lead_name  # 保存导联信息
        }, f'best_{self.model_name}_{lead_name}.pth')

    def train(self, train_loader, val_loader, epochs=100, patience=25):
        """稳定的训练过程"""
        print("🚀 开始稳定训练...")

        for epoch in range(epochs):
            # 训练
            self.model.train()
            train_loss = 0.0
            train_correct = 0
            train_total = 0

            for data, targets in train_loader:
                data, targets = data.to(self.device), targets.to(self.device)

                self.optimizer.zero_grad()
                outputs, _ = self.model(data)
                loss = self.criterion(outputs, targets)
                loss.backward()

                # 温和的梯度裁剪
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 5.0)
                self.optimizer.step()

                train_loss += loss.item()
                _, predicted = outputs.max(1)
                train_total += targets.size(0)
                train_correct += predicted.eq(targets).sum().item()

            train_acc = 100. * train_correct / train_total
            train_loss = train_loss / len(train_loader)

            # 验证
            self.model.eval()
            val_loss = 0.0
            val_correct = 0
            val_total = 0

            with torch.no_grad():
                for data, targets in val_loader:
                    data, targets = data.to(self.device), targets.to(self.device)
                    outputs, _ = self.model(data)
                    loss = self.criterion(outputs, targets)

                    val_loss += loss.item()
                    _, predicted = outputs.max(1)
                    val_total += targets.size(0)
                    val_correct += predicted.eq(targets).sum().item()

            val_acc = 100. * val_correct / val_total
            val_loss = val_loss / len(val_loader)

            # 学习率调整
            self.scheduler.step(val_acc)

            # 记录历史
            self.train_losses.append(train_loss)
            self.val_losses.append(val_loss)
            self.train_accuracies.append(train_acc)
            self.val_accuracies.append(val_acc)

            # 打印进度
            if (epoch + 1) % 5 == 0 or epoch == 0:
                print(f'Epoch [{epoch + 1}/{epochs}]')
                print(f'  训练: 损失={train_loss:.4f}, 准确率={train_acc:.2f}%')
                print(f'  验证: 损失={val_loss:.4f}, 准确率={val_acc:.2f}%')

            # 保存最佳模型
            if val_acc > self.best_accuracy:
                self.best_accuracy = val_acc
                torch.save({
                    'model_state_dict': self.model.state_dict(),
                    'best_accuracy': self.best_accuracy,
                    'epoch': epoch
                }, f'best_{self.model_name}.pth')

                if (epoch + 1) % 10 == 0:
                    print(f'  💾 保存最佳模型: {val_acc:.2f}%')

        print(f"✅ 训练完成! 最佳验证准确率: {self.best_accuracy:.2f}%")
    
    def evaluate(self, test_loader, device):
        """评估模型"""
        self.model.eval()
        all_preds = []
        all_labels = []
        all_probs = []
    
        with torch.no_grad():
            for batch_data in test_loader:  # 不再直接解包，先接收完整批次数据
                # 核心修复3：适配可变长度返回值（只取前2个值：signals和labels）
                if len(batch_data) >= 2:
                    signals, labels = batch_data[0], batch_data[1]
                else:
                    print(f"警告：测试批次数据格式异常，跳过")
                    continue
                
                signals = signals.to(device)
                labels = labels.to(device)
                
                # 修复模型输入：如果模型返回 (outputs, _)，需正确解包
                model_output = self.model(signals.unsqueeze(1))  # 增加通道维度
                if isinstance(model_output, tuple):
                    outputs = model_output[0]  # 取模型输出的第一个元素（logits）
                else:
                    outputs = model_output
                
                probs = torch.nn.functional.softmax(outputs, dim=1)[:, 1]  # 二分类正类概率
                preds = (probs > 0.5).long()
            
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
                all_probs.extend(probs.cpu().numpy())

        # 处理可能的空数据情况
        if len(all_labels) == 0:
            print("警告：无有效测试数据，返回默认指标")
            return {
                'accuracy': 0.0,
                'f1': 0.0,
                'auroc': 0.0,
                'sensitivity': 0.0,
                'specificity': 0.0
            }

        accuracy = accuracy_score(all_labels, all_preds)
        f1 = f1_score(all_labels, all_preds)
        auroc = roc_auc_score(all_labels, all_probs) if len(set(all_labels)) > 1 else 0.0
        sensitivity = recall_score(all_labels, all_preds)
        
        # 处理特异性计算可能的错误（无负类时）
        try:
            specificity = precision_score(all_labels, all_preds, pos_label=0)
        except:
            specificity = 0.0

        return {
            'accuracy': accuracy,
            'f1': f1,
            'auroc': auroc,
            'sensitivity': sensitivity,
            'specificity': specificity
        }
