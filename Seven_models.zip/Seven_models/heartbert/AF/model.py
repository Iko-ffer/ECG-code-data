import os
import torch
import torch.nn as nn
import torch.nn.init as init
import torch.nn.functional as F
import math
from torch.autograd import Variable
from torchinfo import summary
from torch.optim import Adam
from torch.utils.data import DataLoader, Subset, ConcatDataset, TensorDataset
import random
import numpy as np
from transformers import AutoTokenizer, AutoModel

class ECGChannelAttention1D(nn.Module):
    """ECG专用通道注意力：适配心电信号幅值分布特性"""
    def __init__(self, channels, reduction=8):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.max_pool = nn.AdaptiveMaxPool1d(1)
        
        self.mlp = nn.Sequential(
            nn.Linear(channels, channels // reduction, bias=False),
            nn.BatchNorm1d(channels // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(channels // reduction, channels, bias=False)
        )
        self.sigmoid = nn.Sigmoid()
        # ECG信号幅值差异大，添加可学习权重平衡avg/max
        self.alpha = nn.Parameter(torch.ones(1))
        self.beta = nn.Parameter(torch.ones(1))

    def forward(self, x):
        b, c, _ = x.size()
        avg_out = self.mlp(self.avg_pool(x).view(b, c))
        max_out = self.mlp(self.max_pool(x).view(b, c))
        out = self.alpha * avg_out + self.beta * max_out
        return x * self.sigmoid(out).view(b, c, 1)


class ECGTemporalAttention1D(nn.Module):
    """ECG专用时序注意力：捕捉R波/QRS波等关键时序特征"""
    def __init__(self, channels, kernel_size=3):
        super().__init__()
        self.channels = channels
        self.query_conv = nn.Conv1d(channels, channels//8, 1, bias=False)
        self.key_conv = nn.Conv1d(channels, channels//8, 1, bias=False)
        self.value_conv = nn.Conv1d(channels, channels, 1, bias=False)
        self.gamma = nn.Parameter(torch.zeros(1))
        self.softmax = nn.Softmax(dim=-1)
        # 局部窗口适配ECG周期（0.2-1秒）
        self.local_conv = nn.Conv1d(channels, channels, kernel_size, 
                                   padding=kernel_size//2, groups=channels, bias=False)

    def forward(self, x):
        b, c, t = x.size()
        # 局部上下文增强（适配ECG波形）
        x_local = self.local_conv(x)
        
        query = self.query_conv(x_local).permute(0, 2, 1)  # [b, t, c//8]
        key = self.key_conv(x_local)  # [b, c//8, t]
        value = self.value_conv(x_local)  # [b, c, t]
        
        # 注意力计算（缩放因子适配ECG特征维度）
        attention = self.softmax(torch.bmm(query, key) / math.sqrt(c//8))
        out = torch.bmm(value, attention.permute(0, 2, 1))
        
        # 残差融合，避免梯度消失
        out = self.gamma * out + x
        return out


class ECGBlockAttention1D(nn.Module):
    """ECG残差块级注意力：通道+时序双维度增强"""
    def __init__(self, channels):
        super().__init__()
        self.channel_att = ECGChannelAttention1D(channels)
        self.temporal_att = ECGTemporalAttention1D(channels)

    def forward(self, x):
        x = self.channel_att(x)
        x = self.temporal_att(x)
        return x


# -------------------------- 2. 优化的瓶颈残差块（适配ECG信号） --------------------------
class Bottleneck1D(nn.Module):
    """增强型1D瓶颈残差块：添加注意力+动态正则化"""
    expansion = 4

    def __init__(self, in_channels, out_channels, stride=1, downsample=None, dropout_rate=0.3):
        super().__init__()
        # 1x1卷积降维（适配ECG低幅值特性，减小卷积核权重初始化尺度）
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size=1,
                              stride=1, padding=0, bias=False)
        self.bn1 = nn.BatchNorm1d(out_channels)
        
        # 3x3卷积（替换为分组卷积，减少参数+增强局部特征）
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size=3,
                              stride=stride, padding=1, bias=False, 
                              groups=max(1, out_channels//16))  # 分组数适配ECG通道数
        self.bn2 = nn.BatchNorm1d(out_channels)
        
        # 1x1卷积升维
        self.conv3 = nn.Conv1d(out_channels, out_channels * self.expansion,
                              kernel_size=1, stride=1, padding=0, bias=False)
        self.bn3 = nn.BatchNorm1d(out_channels * self.expansion)
        
        self.relu = nn.ReLU(inplace=True)
        # 动态Dropout：训练时随批次调整 dropout rate
        self.dropout = nn.Dropout1d(dropout_rate)
        self.downsample = downsample
        self.stride = stride
        
        # 添加ECG专用注意力
        self.attention = ECGBlockAttention1D(out_channels * self.expansion)
        
        # 特征融合层（解决ECG特征分布偏移）
        self.fusion = nn.Conv1d(out_channels * self.expansion, 
                               out_channels * self.expansion, 
                               kernel_size=1, bias=False)

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)
        out = self.dropout(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        # 注意力增强 + 特征融合
        out = self.attention(out)
        out = self.fusion(out)
        
        out += identity
        out = self.relu(out)

        return out


# -------------------------- 3. 主模型：ResNet101-1D（ECG优化版） --------------------------
class ResNet1D(nn.Module):
    """优化后的1D ResNet-101，适配心电信号二分类（双通道输出）"""
    def __init__(self, input_channels=1, num_classes=2, segment_length=2000, 
                 dropout_rate=0.2, use_spectral_norm=True):  # num_classes默认2
        super().__init__()
        self.num_classes = num_classes  # 关键：保持num_classes=2
        self.in_channels = 64
        self.segment_length = segment_length
        self.dropout_rate = dropout_rate

        # -------------------------- 初始卷积层优化（适配ECG信号） --------------------------
        # 替换大核为多尺度小核，捕捉不同ECG波形（P波/QRS/T波）
        self.conv1 = nn.Sequential(
            nn.Conv1d(input_channels, 32, kernel_size=5, stride=1, padding=2, bias=False),
            nn.BatchNorm1d(32),
            nn.ReLU(inplace=True),
            nn.Conv1d(32, 64, kernel_size=5, stride=2, padding=2, bias=False),
            nn.BatchNorm1d(64),
            nn.ReLU(inplace=True)
        )
        self.bn1 = nn.BatchNorm1d(64)
        self.relu = nn.ReLU(inplace=True)
        # 池化核适配ECG采样率（通常250Hz，5个点=20ms）
        self.maxpool = nn.MaxPool1d(kernel_size=5, stride=2, padding=2)
        # 轻量dropout，避免ECG特征丢失
        self.dropout1 = nn.Dropout1d(dropout_rate * 0.5)

        # -------------------------- 残差层（优化通道增长策略） --------------------------
        # ResNet-101配置：[3, 4, 23, 3]，调整通道增长更平缓
        self.layer1 = self._make_layer(Bottleneck1D, 64, 3, stride=1)
        self.layer2 = self._make_layer(Bottleneck1D, 128, 4, stride=2)
        self.layer3 = self._make_layer(Bottleneck1D, 192, 23, stride=2)  # 减缓通道增长
        self.layer4 = self._make_layer(Bottleneck1D, 256, 3, stride=2)   # 最终通道：256*4=1024

        # -------------------------- 多尺度特征融合（适配ECG长短期特征） --------------------------
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.max_pool = nn.AdaptiveMaxPool1d(1)
        self.global_pool = nn.AdaptiveAvgPool1d(4)  # 保留局部时序特征
        # 时序特征聚合
        self.temporal_fusion = nn.Conv1d(256 * Bottleneck1D.expansion, 
                                        256 * Bottleneck1D.expansion, 
                                        kernel_size=4, padding=0, bias=False)

        # -------------------------- 分类头修改：双通道输出（适配CrossEntropyLoss） --------------------------
        self.classifier = nn.Sequential(
            nn.Flatten(),
            # 多尺度特征拼接：全局avg + 全局max + 局部时序
            nn.Linear(256 * Bottleneck1D.expansion * 3, 512),
            nn.LayerNorm(512),  # 替代BN，适配小批量ECG数据
            nn.ReLU(inplace=True),
            nn.AlphaDropout(dropout_rate),  # 保持ECG特征分布
            nn.Linear(512, 128),
            nn.LayerNorm(128),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout_rate * 0.8),
            # 核心修改：从nn.Linear(128, 1)改为nn.Linear(128, 2)（双通道输出）
            nn.Linear(128, self.num_classes)  # 输出维度=2，匹配CrossEntropyLoss
        )

        # -------------------------- 正则化增强 --------------------------
        # 谱归一化：增强泛化性，防止ECG数据分布偏移
        if use_spectral_norm:
            for m in self.modules():
                if isinstance(m, nn.Conv1d) or isinstance(m, nn.Linear):
                    nn.utils.spectral_norm(m)

        self._initialize_weights()

    def _make_layer(self, block, out_channels, blocks, stride=1):
        downsample = None
        if stride != 1 or self.in_channels != out_channels * block.expansion:
            downsample = nn.Sequential(
                nn.Conv1d(self.in_channels, out_channels * block.expansion,
                         kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm1d(out_channels * block.expansion),
            )

        layers = []
        layers.append(block(self.in_channels, out_channels, stride, 
                           downsample, self.dropout_rate))
        self.in_channels = out_channels * block.expansion
        
        for _ in range(1, blocks):
            layers.append(block(self.in_channels, out_channels,
                               dropout_rate=self.dropout_rate))

        return nn.Sequential(*layers)

    def _initialize_weights(self):
        """ECG专用初始化：适配心电信号幅值小（通常±1mV）的特性"""
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                # 减小初始化尺度，适配ECG低幅值
                nn.init.kaiming_normal_(m.weight, mode='fan_out', 
                                       nonlinearity='relu', a=0.01)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                # 二分类权重初始化更保守
                nn.init.xavier_uniform_(m.weight, gain=0.8)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0.001)
            # 注意力参数初始化
            elif isinstance(m, (ECGChannelAttention1D, ECGTemporalAttention1D)):
                for p in m.parameters():
                    if p.dim() > 1:
                        nn.init.xavier_uniform_(p)
                    else:
                        nn.init.constant_(p, 1.0)

    def forward(self, x, lengths=None):
        """前向传播：输入[batch, seq_len]，输出[batch, 2]（适配CrossEntropyLoss）"""
        # 添加通道维度 [B, 1, L]
        x = x.unsqueeze(1)

        # 初始特征提取（多尺度小核）
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.dropout1(x)
        x = self.maxpool(x)

        # 残差层特征提取（带注意力增强）
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        # 多尺度池化融合
        avg_feat = self.avg_pool(x).flatten(1)
        max_feat = self.max_pool(x).flatten(1)
        # 局部时序特征（保留QRS波群信息）
        local_feat = self.global_pool(x)
        local_feat = self.temporal_fusion(local_feat).flatten(1)

        # 特征拼接
        fusion_feat = torch.cat([avg_feat, max_feat, local_feat], dim=1)

        # 分类（核心修改：输出[batch,2]）
        logits = self.classifier(fusion_feat)
        
        # 兼容原接口：返回(logits, None)，logits为[batch,2]
        return logits, None
    
    
class MultiScaleConv1d(nn.Module):
    """多尺度并行卷积模块（适配ECG不同波形特征）"""
    def __init__(self, in_channels, out_channels, kernel_sizes=[3,7,15,21,31], padding='same', bias=False):
        super().__init__()
        self.out_channels = out_channels
        self.kernel_sizes = kernel_sizes
        self.num_scales = len(kernel_sizes)
        
        # 为每个尺度创建卷积层
        self.convs = nn.ModuleList()
        for ks in kernel_sizes:
            self.convs.append(
                nn.Conv1d(in_channels, out_channels//self.num_scales, kernel_size=ks, 
                          padding=padding, bias=bias)
            )
        
        # 处理通道数不能整除的情况
        self.residual_conv = None
        if out_channels % self.num_scales != 0:
            self.residual_conv = nn.Conv1d(in_channels, out_channels % self.num_scales, 
                                          kernel_size=1, padding=padding, bias=bias)

    def forward(self, x):
        # 并行计算各尺度卷积
        conv_outs = []
        for conv in self.convs:
            conv_outs.append(conv(x))
        
        # 拼接多尺度特征
        out = torch.cat(conv_outs, dim=1)
        
        # 补充剩余通道（若有）
        if self.residual_conv is not None:
            residual = self.residual_conv(x)
            out = torch.cat([out, residual], dim=1)
        
        return out


class UNet1DClassifier(nn.Module):
    """优化版1D UNet：修复通道注意力维度不匹配+多尺度卷积问题"""
    def __init__(self, 
                 input_channels=1,    # 输入通道数：1（单通道）
                 num_classes=2,       # 二分类（异常/正常）
                 input_length=2500,   # 输入序列长度：2500
                 base_filters=32,     # 基础卷积核数
                 dropout_rate=0.2):    # Dropout概率
        super(UNet1DClassifier, self).__init__()
        self.input_channels = input_channels
        self.input_length = input_length
        self.base_filters = base_filters

        # ---------------------- 编码器（Encoder）：多尺度特征提取 + 下采样 ----------------------
        # 编码器块1：多尺度并行卷积，输入(1, 2500) → 输出(32, 2500)
        self.enc_block1 = nn.Sequential(
            MultiScaleConv1d(input_channels, base_filters, kernel_sizes=[3,7,15], padding='same', bias=False),
            nn.BatchNorm1d(base_filters),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters, base_filters, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )
        self.pool1 = nn.MaxPool1d(kernel_size=2, stride=2)  # 2500→1250

        # 编码器块2：输入(32, 1250) → 输出(64, 1250)
        self.enc_block2 = nn.Sequential(
            nn.Conv1d(base_filters, base_filters*2, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*2),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters*2, base_filters*2, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*2),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )
        self.pool2 = nn.MaxPool1d(kernel_size=2, stride=2)  # 1250→625

        # 编码器块3：输入(64, 625) → 输出(128, 625)
        self.enc_block3 = nn.Sequential(
            nn.Conv1d(base_filters*2, base_filters*4, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*4),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters*4, base_filters*4, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*4),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )
        self.pool3 = nn.MaxPool1d(kernel_size=2, stride=2)  # 625→312

        # 编码器块4：输入(128, 312) → 输出(256, 312)
        self.enc_block4 = nn.Sequential(
            nn.Conv1d(base_filters*4, base_filters*8, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*8),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters*8, base_filters*8, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*8),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )
        self.pool4 = nn.MaxPool1d(kernel_size=2, stride=2)  # 312→156

        # ---------------------- 瓶颈层（Bottleneck）：深层特征融合 ----------------------
        # 输入(256, 156) → 输出(512, 156)
        self.bottleneck = nn.Sequential(
            nn.Conv1d(base_filters*8, base_filters*16, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*16),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters*16, base_filters*16, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*16),
            nn.ELU(inplace=True),
            nn.Dropout(0.4)
        )
        self.pool_bottleneck = nn.MaxPool1d(kernel_size=2, stride=2)  # 156→78

        # ---------------------- 解码器（Decoder）：特征恢复 + 跳跃连接 ----------------------
        # 解码器块1：输入(512, 78) → 上采样→(256, 156) → 拼接→(512, 156) → 输出(128, 156)
        self.upconv1 = nn.ConvTranspose1d(base_filters*16, base_filters*8, kernel_size=2, stride=2, bias=False)
        self.dec_block1 = nn.Sequential(
            nn.Conv1d(base_filters*16, base_filters*4, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*4),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters*4, base_filters*4, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*4),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )

        # 解码器块2：输入(128, 156) → 上采样→(64, 312) → 拼接→(192, 312) → 输出(64, 312)
        self.upconv2 = nn.ConvTranspose1d(base_filters*4, base_filters*2, kernel_size=2, stride=2, bias=False)
        self.dec_block2 = nn.Sequential(
            nn.Conv1d(base_filters*6, base_filters*2, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*2),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters*2, base_filters*2, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters*2),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )

        # 解码器块3：输入(64, 312) → 上采样→(32, 624) → 拼接→(96, 624) → 输出(32, 624)
        self.upconv3 = nn.ConvTranspose1d(base_filters*2, base_filters, kernel_size=2, stride=2, bias=False)
        self.dec_block3 = nn.Sequential(
            nn.Conv1d(base_filters*3, base_filters, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters, base_filters, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )

        # 解码器块4：输入(32, 624) → 上采样→(32, 1248) → 拼接→(64, 1248) → 输出(32, 1248)
        self.upconv4 = nn.ConvTranspose1d(base_filters, base_filters, kernel_size=2, stride=2, bias=False)
        self.dec_block4 = nn.Sequential(
            nn.Conv1d(base_filters*2, base_filters, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters),
            nn.ELU(inplace=True),
            nn.Conv1d(base_filters, base_filters, kernel_size=15, padding='same', bias=False),
            nn.BatchNorm1d(base_filters),
            nn.ELU(inplace=True),
            nn.Dropout(dropout_rate)
        )

        # ---------------------- 分类头（Classifier）：全局+局部特征融合 ----------------------
        self.global_avg_pool = nn.AdaptiveAvgPool1d(1)  # 平均池化：捕捉整体节律
        self.global_max_pool = nn.AdaptiveMaxPool1d(1)  # 最大池化：捕捉峰值特征
        self.classifier = nn.Sequential(
            nn.Flatten(),  
            nn.Linear(base_filters*2, base_filters),  
            nn.LayerNorm(base_filters),
            nn.ELU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(base_filters, base_filters),
            nn.Sigmoid(),  # 门控系数，平衡正负类特征
            nn.Linear(base_filters, base_filters//2),  
            nn.ELU(inplace=True),
            nn.Linear(base_filters//2, num_classes)  
         )

        # 初始化权重
        self._initialize_weights()

    def _initialize_weights(self):
        """Kaiming初始化（适配ELU激活函数）"""
        for m in self.modules():
            if isinstance(m, (nn.Conv1d, nn.ConvTranspose1d)):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.LayerNorm):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def _align_length(self, x1, x2):
        """优化的长度对齐：仅插值，移除易出错的动态通道注意力"""
        target_len = max(x1.size(2), x2.size(2))
        # 插值对齐到较长的长度（避免截断丢失特征）
        x1_aligned = F.interpolate(x1, size=target_len, mode='linear', align_corners=False)
        x2_aligned = F.interpolate(x2, size=target_len, mode='linear', align_corners=False)
        
        # 移除动态通道注意力（核心修复：避免维度不匹配）
        return x1_aligned, x2_aligned

    def forward(self, x, lengths=None):
        """
        前向传播：适配 (batch, seq_len) 输入，输出二分类logits
        x: 输入张量 (batch_size, seq_len)
        lengths: 可选，序列长度（兼容原有训练流程）
        """
        batch_size, seq_len = x.size()

        # 1. 输入长度适配（中心截断/补零）
        if seq_len > self.input_length:
            start = (seq_len - self.input_length) // 2
            x = x[:, start:start+self.input_length]
        elif seq_len < self.input_length:
            pad_left = (self.input_length - seq_len) // 2
            pad_right = self.input_length - seq_len - pad_left
            x = F.pad(x, (pad_left, pad_right))

        # 2. 扩展通道维度：(batch_size, 2500) → (batch_size, 1, 2500)
        x = x.unsqueeze(1)

        # 3. 编码器前向传播
        enc1 = self.enc_block1(x)        # (batch, 32, 2500)
        pool1 = self.pool1(enc1)         # (batch, 32, 1250)

        enc2 = self.enc_block2(pool1)    # (batch, 64, 1250)
        pool2 = self.pool2(enc2)         # (batch, 64, 625)

        enc3 = self.enc_block3(pool2)    # (batch, 128, 625)
        pool3 = self.pool3(enc3)         # (batch, 128, 312)

        enc4 = self.enc_block4(pool3)    # (batch, 256, 312)
        pool4 = self.pool4(enc4)         # (batch, 256, 156)

        # 4. 瓶颈层
        bottleneck = self.bottleneck(pool4)  # (batch, 512, 156)
        bottleneck_pool = self.pool_bottleneck(bottleneck)  # (batch, 512, 78)

        # 5. 解码器前向传播
        # 解码器块1
        up1 = self.upconv1(bottleneck_pool)  # (batch, 256, 156)
        up1, enc4_aligned = self._align_length(up1, enc4)
        dec1 = torch.cat([up1, enc4_aligned], dim=1)  # (batch, 512, 156)
        dec1 = self.dec_block1(dec1)                  # (batch, 128, 156)

        # 解码器块2
        up2 = self.upconv2(dec1)  # (batch, 64, 312)
        up2, enc3_aligned = self._align_length(up2, enc3)
        dec2 = torch.cat([up2, enc3_aligned], dim=1)  # (batch, 192, 312)
        dec2 = self.dec_block2(dec2)                  # (batch, 64, 312)

        # 解码器块3
        up3 = self.upconv3(dec2)  # (batch, 32, 624)
        up3, enc2_aligned = self._align_length(up3, enc2)
        dec3 = torch.cat([up3, enc2_aligned], dim=1)  # (batch, 96, 624)
        dec3 = self.dec_block3(dec3)                  # (batch, 32, 624)

        # 解码器块4
        up4 = self.upconv4(dec3)  # (batch, 32, 1248)
        up4, enc1_aligned = self._align_length(up4, enc1)
        dec4 = torch.cat([up4, enc1_aligned], dim=1)  # (batch, 64, 1248)
        dec4 = self.dec_block4(dec4)                  # (batch, 32, 1248)

        # 6. 分类头：融合全局平均+最大池化特征
        gap = self.global_avg_pool(dec4)  # (batch, 32, 1)
        gmp = self.global_max_pool(dec4)  # (batch, 32, 1)
        pooled = torch.cat([gap, gmp], dim=1)  # (batch, 64, 1)
        logits = self.classifier(pooled)       # (batch, 2)

        return logits, None  # 适配原有训练代码


# 保留原有make_divisible函数
def make_divisible(x, divisor=8):
    result = (x + divisor - 1) // divisor
    return int(result)



# 1D版本的 Conv-BN-ReLU 块（适配时序信号）
class ConvBNReLU(nn.Module):
    def __init__(self, input_channels, output_channels, kernel_size, stride, padding):
        super(ConvBNReLU, self).__init__()
        # 2D→1D：Conv2d→Conv1d，kernel_size (3,3)→3
        self.layer = nn.Sequential(
            nn.Conv1d(input_channels, output_channels, kernel_size, stride, padding, bias=False),
            nn.BatchNorm1d(output_channels),
            nn.ReLU()
        )

    def forward(self, x):
        return self.layer(x)

# 1D深度可分离卷积块（核心模块适配）
class DepthSeparableConv1d(nn.Module):
     def __init__(self, in_channel, out_channel, kernel_size, stride, padding):
        super(DepthSeparableConv1d, self).__init__()
        # DW卷积
        self.depth_conv = nn.Conv1d(in_channel, in_channel, kernel_size, stride, padding, groups=in_channel, bias=False)
        self.depth_bn = nn.BatchNorm1d(in_channel)
        # 逐点卷积
        self.point_conv = nn.Conv1d(in_channel, out_channel, 1, 1, 0, bias=False)
        self.point_bn = nn.BatchNorm1d(out_channel)

     def forward(self, x):
        # DW卷积
        x = self.depth_conv(x)
        x = self.depth_bn(x)
        x = F.relu(x, inplace=True)
        # 逐点卷积
        x = self.point_conv(x)
        x = self.point_bn(x)
        x = F.relu(x, inplace=True)
        return x
    
class MobileNetV1_ECG(nn.Module):
    def __init__(self, input_length=2048, in_channels=1, scale=1.0, num_classes=2, dropout_rate=0.3):
        super(MobileNetV1_ECG, self).__init__()
        self.input_length = input_length
        self.in_channels = in_channels

        input_channel = make_divisible(32 * scale)

        self.conv1 = ConvBNReLU(in_channels, input_channel, kernel_size=15, stride=2, padding=7)

        self.conv2 = nn.Sequential(
            DepthSeparableConv1d(input_channel, make_divisible(64*scale), 15, 1, 7),
            DepthSeparableConv1d(make_divisible(64*scale), make_divisible(128*scale), 15, 2, 7),
            DepthSeparableConv1d(make_divisible(128*scale), make_divisible(256*scale), 15, 1, 7),
            DepthSeparableConv1d(make_divisible(256*scale), make_divisible(256*scale), 15, 1, 7),
            DepthSeparableConv1d(make_divisible(256*scale), make_divisible(512*scale), 15, 2, 7),
        )
        input_channel = make_divisible(512 * scale)

        conv3_layers = []
        for i in range(5):
            conv3_layers.append(DepthSeparableConv1d(input_channel, input_channel, 15, 1, 7))
        self.conv3 = nn.Sequential(*conv3_layers)

        last_channel = make_divisible(1024 * scale)
        print(f"  last_channel={last_channel}")
        self.conv4 = nn.Sequential(
            DepthSeparableConv1d(input_channel, last_channel, 15, 2, 7),
            DepthSeparableConv1d(last_channel, last_channel, 15, 2, 7),
        )
       
        self.avgpool = nn.AvgPool1d(kernel_size=64)

        self.classifier = nn.Sequential(
            nn.Dropout(dropout_rate),
            nn.Linear(last_channel, last_channel // 2),
            nn.ReLU(),
            nn.Dropout(dropout_rate * 0.5),
            nn.Linear(last_channel // 2, num_classes)
        )
        
        self._initialize_weights()
        

    def _initialize_weights(self):
        """初始化权重，提升训练稳定性"""
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)

    def forward(self, x, lengths=None):
        """
        前向传播：适配 (batch, 2048) 输入
        x: 输入张量 (batch_size, seq_len)
        lengths: 可选，序列长度（兼容原有训练流程）
        """
        batch_size, seq_len = x.size()

        # 步骤1：调整输入长度为2048（截断/补零）
        if seq_len != self.input_length:
            if seq_len > self.input_length:
                x = x[:, :self.input_length]
            else:
                pad_len = self.input_length - seq_len
                x = torch.cat([x, torch.zeros(batch_size, pad_len, device=x.device)], dim=1)

        # 步骤2：扩展通道维度 (batch, 2048) → (batch, 1, 2048)
        x = x.unsqueeze(1)

        # 步骤3：特征提取（深度可分离卷积）
        x = self.conv1(x)       # (batch, 32, 1024)
        x = self.conv2(x)       # (batch, 512, 256)
        x = self.conv3(x)       # (batch, 512, 256)
        x = self.conv4(x)       # (batch, 1024, 64)

        # 步骤4：全局特征+分类
        x = self.avgpool(x)
        x = x.view(batch_size, -1)   # (batch, 1024)
        logits = self.classifier(x)  # (batch, 2)

        # 兼容原有训练流程：返回 (logits, None)
        return logits, None
    

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoModel

class HeartBERT_ECG(nn.Module):
    """
    独立可调用的HeartBERT ECG分类模型（1D时序信号输入）
    和ResNet1D/UNet1D/MobileNetV1_ECG完全平级、可无缝替换
    输入格式：[batch_size, 1, 2500] 或 [batch_size, 2500] （自动兼容）
    输出格式：(logits, None)  完美适配现有训练代码
    可配置：冻结权重、dropout、分类数、输入长度
    """
    def __init__(self,
                 heartbert_model_path=None,  # resolved in __init__ via HEARTBERT_MODEL_PATH
                 in_channels=1,
                 num_classes=2,
                 input_length=2500,  # ✅ 修正为2500，和其他所有模型保持一致
                 dropout_rate=0.2,
                 freeze_heartbert=False,  # 小样本推荐设为True，防止过拟合
                 hidden_dim=768,
                 use_gradient_clip=True):
        super().__init__()
        self.input_length = input_length
        self.use_gradient_clip = use_gradient_clip
        self.max_bert_seq_len = 512  
        self.in_channels = in_channels
        self.dropout_rate = dropout_rate
        self.num_classes = num_classes

        if heartbert_model_path is None:
            heartbert_model_path = os.environ.get(
                "HEARTBERT_MODEL_PATH",
                os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "heartbert")),
            )

        # 1. 加载预训练HeartBERT模型（核心：纯模型，无Tokenizer）
        self.heartbert_backbone = AutoModel.from_pretrained(heartbert_model_path)
        
        # 2. 分层冻结HeartBERT权重（关键优化，避免小样本过拟合）
        if freeze_heartbert:
            # 冻结前6层，微调后6层，平衡特征提取和任务适配
            for i, layer in enumerate(self.heartbert_backbone.encoder.layer):
                if i < 6:
                    for param in layer.parameters():
                        param.requires_grad = False

        # 3. ECG时序信号 -> HeartBERT适配层 
        # 输入：[batch, 1, seq_len] -> 输出：[batch, seq_len, 768] （完全匹配Transformer输入格式）
        self.ecg_embedding = nn.Sequential(
            nn.Conv1d(in_channels, 128, kernel_size=5, stride=1, padding=2),  # 捕捉P波/ST段
            nn.BatchNorm1d(128),
            nn.ReLU(inplace=True),
            nn.Conv1d(128, 256, kernel_size=15, stride=1, padding=7),  # 捕捉QRS波群
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Conv1d(256, hidden_dim, kernel_size=1),  # 1x1卷积映射到BERT的768维
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace=True)
        )

        # 4. 多层特征融合层（融合浅层、中层、深层特征）
        self.layer_fusion = nn.Linear(hidden_dim * 3, hidden_dim)

        # 5. 全局池化层：把序列特征压缩为全局特征
        self.global_pool = nn.AdaptiveAvgPool1d(1)

        # 6. 分类头（和其他模型分类头结构完全一致，保证训练一致性）
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim//2),
            nn.LayerNorm(hidden_dim//2),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim//2, hidden_dim//2),
            nn.LayerNorm(hidden_dim//2),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim//2, num_classes)
        )

        # 初始化分类头权重
        self._init_weights()

    def _init_weights(self):
        """初始化分类层权重，和你的其他模型保持一致"""
        for m in self.classifier.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight, gain=0.8)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0.001)
            elif isinstance(m, nn.LayerNorm):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def process_ecg_input(self, ecg_signal):
        """ECG信号预处理：长度对齐+维度适配，和ResNet1D/UNet1D逻辑完全一致"""
        # ✅ 自动处理3维输入 (batch_size, 1, 2500)
        if ecg_signal.dim() == 3:
            ecg_signal = ecg_signal.squeeze(1)  # 变为 (batch_size, 2500)
        
        batch_size, seq_len = ecg_signal.size()
    
        # 长度对齐到BERT的最大序列长度512
        if seq_len > self.max_bert_seq_len:
            # 截断前512个点（ECG信号前半段信息更丰富）
            ecg_signal = ecg_signal[:, :self.max_bert_seq_len]
        elif seq_len < self.max_bert_seq_len:
            # 左右对称填充
            pad_left = (self.max_bert_seq_len - seq_len) // 2
            pad_right = self.max_bert_seq_len - seq_len - pad_left
            ecg_signal = F.pad(ecg_signal, (pad_left, pad_right))
        
        # ✅ 修正维度转换逻辑（Conv1d要求输入为 [batch, channels, length]）
        ecg_signal = ecg_signal.unsqueeze(1)  # [B, 1, 512]
        ecg_embed = self.ecg_embedding(ecg_signal)  # [B, 768, 512]
        ecg_embed = ecg_embed.permute(0, 2, 1)  # [B, 512, 768] （Transformer输入格式）
        
        return ecg_embed

    def forward(self, x):
        # ✅ 【最关键修复】自动处理DataLoader返回的3维输入格式
        if x.dim() == 3:
            x = x.squeeze(1)  # 从 (batch_size, 1, 2500) 转为 (batch_size, 2500)
        
        batch_size, original_seq_len = x.shape
        
        # 1. 预处理ECG输入，得到BERT嵌入特征
        ecg_embed = self.process_ecg_input(x)  # 输出形状: [B, 512, 768]
        aligned_seq_len = self.max_bert_seq_len  # 现在所有信号长度都是512
    
        # 2. 计算能量掩码（基于对齐后的信号，确保维度完全匹配）
        # 先对原始信号做同样的长度对齐
        if original_seq_len > self.max_bert_seq_len:
            x_aligned = x[:, :self.max_bert_seq_len]
        else:
            pad_left = (self.max_bert_seq_len - original_seq_len) // 2
            pad_right = self.max_bert_seq_len - original_seq_len - pad_left
            x_aligned = F.pad(x, (pad_left, pad_right))
        
        ecg_energy = torch.mean(torch.abs(x_aligned), dim=1, keepdim=True)  # [B, 1]
        ecg_energy = ecg_energy.expand(-1, aligned_seq_len)  # [B, 512]
        
        # 构建能量掩码；Roberta 需要 [B, seq_len] 的 long mask
        energy_threshold = 0.1 * torch.max(ecg_energy, dim=1, keepdim=True)[0]
        attention_mask = (ecg_energy > energy_threshold).to(
            dtype=torch.long, device=x.device
        )
       
        # 5. 输入HeartBERT主干网络提取特征
        heartbert_output = self.heartbert_backbone(
            inputs_embeds=ecg_embed,  
            attention_mask=attention_mask,  
            output_hidden_states=True 
        )

        # 6. 多层特征融合（提取浅层、中层、深层特征）
        hidden_states = heartbert_output.hidden_states
        # 按比例选择不同层次的特征，适配任意层数的BERT模型
        layer_indices = [
            max(1, len(hidden_states) // 4),    # 浅层特征（细节信息）
            max(1, len(hidden_states) // 2),    # 中层特征（语义信息）
            max(1, len(hidden_states) - 4)      # 深层特征（抽象信息）
        ]
    
        # 提取并池化各层特征
        pool_feats = []
        for idx in layer_indices:
            layer_feat = hidden_states[idx].transpose(1, 2)  # [B, 768, 512]
            pool_feat = self.global_pool(layer_feat).squeeze(-1)  # [B, 768]
            pool_feats.append(pool_feat)
    
        # 拼接并融合多层特征
        fused_feat = torch.cat(pool_feats, dim=1)  # [B, 768*3]
        fused_feat = self.layer_fusion(fused_feat)  # [B, 768]

        # 7. 分类预测
        logits = self.classifier(fused_feat)

        # 8. 梯度裁剪（训练阶段防止梯度爆炸）
        if self.use_gradient_clip and self.training:
            torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=5.0)

        # ✅ 返回格式和其他模型完全一致：(logits, None)
        return logits, None


class AdaptivePool1dSafe(nn.Module):
    """安全的自适应池化层，完全兼容MPS设备"""

    def __init__(self, output_size):
        super(AdaptivePool1dSafe, self).__init__()
        self.output_size = output_size

    def forward(self, x):
        input_size = x.size(2)

        # 如果输入尺寸已经是目标尺寸，直接返回
        if input_size == self.output_size:
            return x

        # 如果输入太小，进行填充
        if input_size < self.output_size:
            pad_size = self.output_size - input_size
            x = F.pad(x, (0, pad_size))
            return F.adaptive_avg_pool1d(x, self.output_size)

        # 计算最接近的能被output_size整除的尺寸
        if input_size % self.output_size != 0:
            # 找到最接近的能被output_size整除的尺寸
            new_size = (input_size // self.output_size) * self.output_size
            if new_size == 0:
                new_size = self.output_size
            # 使用平均池化调整尺寸
            kernel_size = input_size // new_size
            stride = kernel_size
            return F.avg_pool1d(x, kernel_size=kernel_size, stride=stride)
        else:
            return F.adaptive_avg_pool1d(x, self.output_size)


class ECGBatchNorm1d(nn.Module):
    """ECG专用的BatchNorm，更稳定"""

    def __init__(self, num_features):
        super(ECGBatchNorm1d, self).__init__()
        self.bn = nn.BatchNorm1d(num_features)

    def forward(self, x):
        # 如果batch_size=1，跳过BatchNorm
        if x.size(0) == 1:
            return x
        return self.bn(x)


class MultiHeadAttention(nn.Module):
    """多头注意力机制"""

    def __init__(self, hidden_dim, num_heads=8, dropout=0.1):
        super(MultiHeadAttention, self).__init__()
        assert hidden_dim % num_heads == 0

        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads

        self.q_linear = nn.Linear(hidden_dim, hidden_dim)
        self.k_linear = nn.Linear(hidden_dim, hidden_dim)
        self.v_linear = nn.Linear(hidden_dim, hidden_dim)
        self.out_linear = nn.Linear(hidden_dim, hidden_dim)

        self.dropout = nn.Dropout(dropout)
        self.layer_norm = nn.LayerNorm(hidden_dim)

    def forward(self, x, mask=None):
        batch_size, seq_len, hidden_dim = x.size()

        # 线性变换
        Q = self.q_linear(x)
        K = self.k_linear(x)
        V = self.v_linear(x)

        # 分割多头
        Q = Q.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        K = K.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        V = V.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)

        # 计算注意力分数
        scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.head_dim)

        # 应用mask
        if mask is not None:
            mask = mask.unsqueeze(1).unsqueeze(2)  # [batch, 1, 1, seq_len]
            scores = scores.masked_fill(~mask, -1e9)

        # 注意力权重
        attention_weights = F.softmax(scores, dim=-1)
        attention_weights = self.dropout(attention_weights)

        # 加权求和
        context = torch.matmul(attention_weights, V)

        # 合并多头
        context = context.transpose(1, 2).contiguous().view(batch_size, seq_len, hidden_dim)

        # 输出变换
        output = self.out_linear(context)
        output = self.dropout(output)

        # 残差连接和层归一化
        output = self.layer_norm(x + output)

        return output, attention_weights.mean(dim=1)  # 返回平均注意力权重


class RobustAttention(nn.Module):
    """稳健的注意力机制"""

    def __init__(self, hidden_dim, attention_dim=128, use_multi_head=False):
        super(RobustAttention, self).__init__()
        self.use_multi_head = use_multi_head

        if use_multi_head:
            self.attention = MultiHeadAttention(hidden_dim)
        else:
            self.attention_network = nn.Sequential(
                nn.Linear(hidden_dim, attention_dim),
                nn.Tanh(),
                nn.Dropout(0.1),
                nn.Linear(attention_dim, 1)
            )
            self.softmax = nn.Softmax(dim=1)

    def forward(self, gru_output, lengths=None):
        batch_size, seq_len, hidden_dim = gru_output.shape

        if self.use_multi_head:
            # 为多头注意力创建mask
            mask = None
            if lengths is not None:
                # 确保lengths在正确的设备上
                device = gru_output.device
                mask = torch.arange(seq_len, device=device).expand(batch_size, seq_len) < lengths.unsqueeze(1)

            attended_output, attention_weights = self.attention(gru_output, mask)
            context_vector = attended_output.mean(dim=1)  # 使用平均池化

        else:
            # 原始稳健注意力机制
            attention_scores = self.attention_network(gru_output).squeeze(-1)

            # 创建mask
            if lengths is not None:
                # 确保lengths在正确的设备上
                device = gru_output.device
                mask = torch.arange(seq_len, device=device).expand(batch_size, seq_len) < lengths.unsqueeze(1)
                attention_scores = attention_scores.masked_fill(~mask, -1e9)

            # 注意力权重
            attention_weights = self.softmax(attention_scores)

            # 加权求和
            context_vector = torch.bmm(attention_weights.unsqueeze(1), gru_output).squeeze(1)

        return context_vector, attention_weights


class HierarchicalAttention(nn.Module):
    """层次化注意力机制 - 结合时间和特征维度"""

    def __init__(self, hidden_dim, reduction_ratio=8):
        super(HierarchicalAttention, self).__init__()

        # 时间注意力
        self.temporal_attention = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // reduction_ratio),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim // reduction_ratio, 1),
            nn.Sigmoid()
        )

        # 特征注意力
        self.feature_attention = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // reduction_ratio),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim // reduction_ratio, hidden_dim),
            nn.Sigmoid()
        )

    def forward(self, x, lengths=None):
        batch_size, seq_len, hidden_dim = x.shape

        # 时间维度注意力
        temporal_weights = self.temporal_attention(x)  # [batch, seq_len, 1]

        # 特征维度注意力
        feature_weights = self.feature_attention(x.mean(dim=1))  # [batch, hidden_dim]
        feature_weights = feature_weights.unsqueeze(1)  # [batch, 1, hidden_dim]

        # 应用双重注意力
        attended = x * temporal_weights * feature_weights

        # 全局池化
        if lengths is not None:
            # 使用masked mean - 确保lengths在正确设备上
            device = x.device
            mask = torch.arange(seq_len, device=device).expand(batch_size, seq_len) < lengths.unsqueeze(1)
            mask = mask.unsqueeze(-1).float()
            context = (attended * mask).sum(dim=1) / lengths.unsqueeze(1).float()
        else:
            context = attended.mean(dim=1)

        return context, temporal_weights.squeeze(-1)


class AdaptiveAttention(nn.Module):
    """自适应注意力机制 - 自动选择最佳注意力类型"""

    def __init__(self, hidden_dim, attention_types=['robust', 'hierarchical']):
        super(AdaptiveAttention, self).__init__()

        self.attention_modules = nn.ModuleDict()
        self.attention_weights = nn.Parameter(torch.ones(len(attention_types)))

        if 'robust' in attention_types:
            self.attention_modules['robust'] = RobustAttention(hidden_dim)
        if 'hierarchical' in attention_types:
            self.attention_modules['hierarchical'] = HierarchicalAttention(hidden_dim)
        if 'multihead' in attention_types:
            self.attention_modules['multihead'] = RobustAttention(hidden_dim, use_multi_head=True)

    def forward(self, x, lengths=None):
        contexts = []
        attention_maps = []
        weights = F.softmax(self.attention_weights, dim=0)

        for i, (name, module) in enumerate(self.attention_modules.items()):
            context, attention = module(x, lengths)
            contexts.append(context * weights[i])
            attention_maps.append(attention)

        # 融合不同注意力的结果
        fused_context = torch.stack(contexts).sum(dim=0)
        # 使用第一个注意力图作为输出（或者可以融合注意力图）
        fused_attention = attention_maps[0]

        return fused_context, fused_attention


class MPSCompatibleCNN(nn.Module):
    """MPS兼容的CNN特征提取器"""

    def __init__(self, output_size=32):
        super(MPSCompatibleCNN, self).__init__()
        self.output_size = output_size

        # 设计CNN架构确保输出尺寸可被output_size整除
        self.conv_layers = nn.Sequential(
            # 第一层: 2500 -> 1250
            nn.Conv1d(1, 32, kernel_size=15, stride=2, padding=7),
            ECGBatchNorm1d(32),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),

            # 第二层: 1250 -> 625
            nn.Conv1d(32, 64, kernel_size=9, stride=2, padding=4),
            ECGBatchNorm1d(64),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),

            # 第三层: 625 -> 313
            nn.Conv1d(64, 128, kernel_size=7, stride=2, padding=3),
            ECGBatchNorm1d(128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),

            # 第四层: 313 -> 157
            nn.Conv1d(128, 256, kernel_size=5, stride=2, padding=2),
            ECGBatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),
        )

        # 使用安全的池化层
        self.pool = AdaptivePool1dSafe(output_size)

    def forward(self, x):
        features = self.conv_layers(x)
        pooled_features = self.pool(features)
        return pooled_features


class RobustCNNBiGRU(nn.Module):
    """稳健的CNN+Bi-GRU模型 - MPS兼容版本"""

    def __init__(self, num_classes=9, attention_type='robust'):
        super(RobustCNNBiGRU, self).__init__()

        # 使用MPS兼容的CNN
        self.cnn = MPSCompatibleCNN(output_size=32)

        # Bi-GRU时序建模
        self.gru = nn.GRU(
            input_size=256,
            hidden_size=128,
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=0.3
        )

        # 选择注意力机制
        if attention_type == 'robust':
            self.attention = RobustAttention(256)  # 双向GRU所以是128*2
        elif attention_type == 'hierarchical':
            self.attention = HierarchicalAttention(256)
        elif attention_type == 'multihead':
            self.attention = RobustAttention(256, use_multi_head=True)
        elif attention_type == 'adaptive':
            self.attention = AdaptiveAttention(256)
        else:
            self.attention = RobustAttention(256)

        # 分类器
        self.classifier = nn.Sequential(
            nn.Dropout(0.5),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(128, num_classes)
        )

        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)

    def forward(self, x, lengths=None):
        batch_size, seq_len = x.size()

        # 标准化输入长度 - 使用能被池化层整除的尺寸
        target_length = 2500  # 这个尺寸经过CNN后能被32整除
        if seq_len > target_length:
            x = x[:, :target_length]
        elif seq_len < target_length:
            x = F.pad(x, (0, target_length - seq_len))

        # CNN特征提取
        x = x.unsqueeze(1)
        cnn_features = self.cnn(x)  # [batch_size, 256, 32]

        # Bi-GRU处理
        cnn_features = cnn_features.transpose(1, 2)  # [batch_size, 32, 256]
        gru_output, _ = self.gru(cnn_features)  # [batch_size, 32, 256]

        # 注意力机制 - 确保lengths在正确设备上
        if lengths is not None:
            lengths = lengths.to(gru_output.device)
        context, attention_weights = self.attention(gru_output, lengths)

        # 分类
        logits = self.classifier(context)

        return logits, attention_weights


class WorkingECGModel(nn.Module):
    """能正常学习的ECG模型 - MPS兼容版本"""

    def __init__(self, num_classes=9, attention_type='hierarchical'):
        super(WorkingECGModel, self).__init__()

        # 使用MPS兼容的CNN
        self.cnn = MPSCompatibleCNN(output_size=32)

        # Bi-GRU处理时序特征
        self.gru = nn.GRU(
            input_size=256,
            hidden_size=64,
            num_layers=1,
            batch_first=True,
            bidirectional=True,
            dropout=0.1
        )

        # 选择注意力机制
        if attention_type == 'robust':
            self.attention = RobustAttention(128)
        elif attention_type == 'hierarchical':
            self.attention = HierarchicalAttention(128)
        elif attention_type == 'multihead':
            self.attention = RobustAttention(128, use_multi_head=True)
        elif attention_type == 'adaptive':
            self.attention = AdaptiveAttention(128)
        else:
            self.attention = HierarchicalAttention(128)

        # 分类器
        self.classifier = nn.Sequential(
            nn.Dropout(0.3),
            nn.Linear(128, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),

            nn.Dropout(0.3),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(inplace=True),

            nn.Dropout(0.2),
            nn.Linear(128, num_classes)
        )

        # 权重初始化
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)

    def forward(self, x, lengths=None):
        batch_size, seq_len = x.shape

        # 确保输入长度合适
        target_length = 2500
        if seq_len > target_length:
            x = x[:, :target_length]
        elif seq_len < target_length:
            x = F.pad(x, (0, target_length - seq_len))

        # CNN特征提取
        x = x.unsqueeze(1)
        cnn_features = self.cnn(x)  # [batch, 256, 32]

        # 准备GRU输入
        cnn_features = cnn_features.transpose(1, 2)  # [batch, 32, 256]

        # Bi-GRU处理
        gru_output, _ = self.gru(cnn_features)  # [batch, 32, 128]

        # 注意力机制 - 确保lengths在正确设备上
        if lengths is not None:
            lengths = lengths.to(gru_output.device)
        context, attention_weights = self.attention(gru_output, lengths)

        # 分类
        logits = self.classifier(context)

        return logits, attention_weights


class SimpleButEffectiveModel(nn.Module):
    """简单但有效的模型 - 确保能学习"""

    def __init__(self, num_classes=9):
        super(SimpleButEffectiveModel, self).__init__()

        # 使用MPS兼容的CNN
        self.cnn = MPSCompatibleCNN(output_size=32)

        # Bi-GRU
        self.gru = nn.GRU(
            input_size=256,
            hidden_size=64,
            num_layers=1,
            batch_first=True,
            bidirectional=True
        )

        # 使用稳健注意力机制
        self.attention = RobustAttention(128)

        # 分类器
        self.classifier = nn.Sequential(
            nn.Dropout(0.4),
            nn.Linear(128, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),

            nn.Dropout(0.3),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(inplace=True),

            nn.Dropout(0.2),
            nn.Linear(128, num_classes)
        )

        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)

    def forward(self, x, lengths=None):
        batch_size, seq_len = x.shape

        # 标准化输入长度
        target_length = 2500
        if seq_len > target_length:
            x = x[:, :target_length]
        elif seq_len < target_length:
            x = F.pad(x, (0, target_length - seq_len))

        # CNN特征
        x = x.unsqueeze(1)
        features = self.cnn(x)  # [batch, 256, 32]

        # GRU处理
        features = features.transpose(1, 2)  # [batch, 32, 256]
        gru_output, _ = self.gru(features)  # [batch, 32, 128]

        # 注意力机制 - 确保lengths在正确设备上
        if lengths is not None:
            lengths = lengths.to(gru_output.device)
        context, attention_weights = self.attention(gru_output, lengths)

        # 分类
        logits = self.classifier(context)

        return logits, attention_weights


class DebuggableECGModel(nn.Module):
    """可调试的ECG模型 - 包含梯度检查"""

    def __init__(self, num_classes=9):
        super(DebuggableECGModel, self).__init__()

        self.num_classes = num_classes

        # 非常简单的架构 - 使用固定池化避免MPS问题
        self.conv_layers = nn.Sequential(
            nn.Conv1d(1, 32, 15, stride=2, padding=7),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.MaxPool1d(3, stride=2, padding=1),

            nn.Conv1d(32, 64, 7, stride=2, padding=3),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(3, stride=2, padding=1),

            nn.Conv1d(64, 128, 5, stride=1, padding=2),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),  # 输出固定为1
        )

        # 简单的分类器
        self.classifier = nn.Sequential(
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, num_classes)
        )

        print(f"模型初始化: 输出维度 {num_classes}")

    def forward(self, x, lengths=None):
        # 输入检查
        if torch.isnan(x).any():
            print("警告: 输入包含NaN")

        batch_size = x.size(0)

        # 标准化输入
        x = x[:, :2500] if x.size(1) > 2500 else F.pad(x, (0, 2500 - x.size(1)))
        x = x.unsqueeze(1)

        # 特征提取
        features = self.conv_layers(x)
        features = features.squeeze(-1)

        # 分类
        logits = self.classifier(features)

        # 输出检查
        if torch.isnan(logits).any():
            print("警告: 输出包含NaN")

        return logits, None