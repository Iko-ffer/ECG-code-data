import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F
from sklearn.metrics import f1_score, accuracy_score, roc_auc_score, recall_score, precision_score, confusion_matrix
import time
import warnings
import matplotlib.pyplot as plt

warnings.filterwarnings('ignore')

# ==============================================================================
# ✅ 最简单、最稳定、最适合 ST-T 分类的损失函数
# ==============================================================================
class FocalLoss(nn.Module):
    def __init__(self, alpha=None, gamma=2.0):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma

    def forward(self, logits, targets):
        ce_loss = F.cross_entropy(logits, targets, weight=self.alpha, reduction='none')
        pt = torch.exp(-ce_loss)
        loss = (1 - pt) ** self.gamma * ce_loss
        return loss.mean()

# ==============================================================================
# ✅ 【ST-T 专用】超强涨点训练器
# ==============================================================================
class DebugTrainer:
    def __init__(self, model, device, model_name="debug_model"):
        self.model = model
        self.device = device
        self.model_name = model_name

        # 超参数 —— 专为 ST-T 信号优化
        self.lr = 1e-4
        self.weight_decay = 1e-5

        # 最佳指标
        self.best_accuracy = 0.0
        self.best_f1 = 0.0
        self.best_sensitivity = 0.0
        self.best_specificity = 0.0
        self.patience_counter = 0

        # 历史记录
        self.train_losses = []
        self.val_losses = []
        self.train_accuracies = []
        self.val_accuracies = []
        self.val_sensitivities = []
        self.val_specificities = []

        print(f"✅ ST-T 专用训练器初始化完成 | lr={self.lr}")

    def _compute_metrics(self, y_true, y_pred):
        return {
            'sensitivity': recall_score(y_true, y_pred, pos_label=1, zero_division=0),
            'specificity': recall_score(y_true, y_pred, pos_label=0, zero_division=0),
            'precision': precision_score(y_true, y_pred, pos_label=1, zero_division=0),
        }

    def train_epoch(self, dataloader):
        self.model.train()
        total_loss = 0.0
        all_preds = []
        all_targets = []

        for data, targets in dataloader:
            data = data.to(self.device)
            targets = targets.to(self.device)

            self.optimizer.zero_grad()
            outputs, _ = self.model(data)
            loss = self.criterion(outputs, targets)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            self.optimizer.step()

            total_loss += loss.item()
            preds = torch.argmax(outputs, dim=1)
            all_preds.extend(preds.cpu().numpy())
            all_targets.extend(targets.cpu().numpy())

        avg_loss = total_loss / len(dataloader)
        acc = accuracy_score(all_targets, all_preds)
        return avg_loss, acc

    def val_epoch(self, dataloader):
        self.model.eval()
        total_loss = 0.0
        all_preds = []
        all_targets = []

        with torch.no_grad():
            for data, targets in dataloader:
                data = data.to(self.device)
                targets = targets.to(self.device)
                outputs, _ = self.model(data)
                loss = self.criterion(outputs, targets)
                total_loss += loss.item()
                preds = torch.argmax(outputs, dim=1)
                all_preds.extend(preds.cpu().numpy())
                all_targets.extend(targets.cpu().numpy())

        avg_loss = total_loss / len(dataloader)
        acc = accuracy_score(all_targets, all_preds)
        f1 = f1_score(all_targets, all_preds, zero_division=0)
        metrics = self._compute_metrics(all_targets, all_preds)

        return avg_loss, acc, f1, metrics

    def train(self, train_loader, val_loader, epochs=80, patience=12):
        # --------------------------
        # 🔥 核心优化：类别平衡
        # --------------------------
        all_labels = []
        for _, y in train_loader:
            all_labels.extend(y.numpy())
        weights = np.array([1.0, 1.5])  # ST-T 任务：异常样本更重要
        weights = torch.tensor(weights, dtype=torch.float).to(self.device)

        # 损失函数
        self.criterion = FocalLoss(alpha=weights, gamma=1.5)

        # 优化器
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=self.lr,
            weight_decay=self.weight_decay
        )

        # 学习率调度
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=epochs)

        # 开始训练
        for epoch in range(epochs):
            print(f"\n======== Epoch {epoch+1}/{epochs} ========")
            train_loss, train_acc = self.train_epoch(train_loader)
            val_loss, val_acc, val_f1, metrics = self.val_epoch(val_loader)

            # 更新学习率
            self.scheduler.step()
            current_lr = self.optimizer.param_groups[0]['lr']

            # 记录
            self.train_losses.append(train_loss)
            self.val_losses.append(val_loss)
            self.train_accuracies.append(train_acc)
            self.val_accuracies.append(val_acc)
            self.val_sensitivities.append(metrics['sensitivity'])
            self.val_specificities.append(metrics['specificity'])

            # 打印
            print(f"Train Loss: {train_loss:.4f} | Acc: {train_acc:.4f}")
            print(f"Val   Loss: {val_loss:.4f} | Acc: {val_acc:.4f} | F1: {val_f1:.4f}")
            print(f"Sensitivity: {metrics['sensitivity']:.4f} | Specificity: {metrics['specificity']:.4f}")
            print(f"LR: {current_lr:.2e}")

            # 保存最优模型
            if val_acc > self.best_accuracy + 0.001:
                self.best_accuracy = val_acc
                self.best_f1 = val_f1
                self.best_sensitivity = metrics['sensitivity']
                self.best_specificity = metrics['specificity']
                self.patience_counter = 0

                torch.save({
                    'model_state_dict': self.model.state_dict(),
                    'best_acc': self.best_accuracy,
                }, f'best_{self.model_name}.pth')
                print(f"✅ 保存最佳模型 | Acc={val_acc:.4f}")
            else:
                self.patience_counter += 1

            # 早停
            if self.patience_counter >= patience:
                print(f"\n🛑 早停！")
                break

        # 加载最佳
        try:
            ckpt = torch.load(f'best_{self.model_name}.pth')
            self.model.load_state_dict(ckpt['model_state_dict'])
        except:
            pass

        print("\n" + "="*50)
        print("🏆 训练完成！最佳指标：")
        print(f"  Acc: {self.best_accuracy:.4f}")
        print(f"  F1:  {self.best_f1:.4f}")
        print(f"  Sen: {self.best_sensitivity:.4f}")
        print(f"  Spe: {self.best_specificity:.4f}")
        print("="*50)

    def evaluate(self, test_loader, device):
        self.model.eval()
        all_preds = []
        all_labels = []
        all_probs = []

        with torch.no_grad():
            for data, labels in test_loader:
                data = data.to(device)
                labels = labels.to(device)

                outputs, _ = self.model(data)
                probs = F.softmax(outputs, dim=1)[:, 1]
                preds = (probs > 0.5).long()

                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
                all_probs.extend(probs.cpu().numpy())

        acc = accuracy_score(all_labels, all_preds)
        f1 = f1_score(all_labels, all_preds, zero_division=0)
        auroc = roc_auc_score(all_labels, all_probs) if len(set(all_labels)) > 1 else 0.0
        sen = recall_score(all_labels, all_preds, zero_division=0)
        spe = recall_score(all_labels, all_preds, pos_label=0, zero_division=0)

        print("\n🔍 测试集混淆矩阵：")
        cm = confusion_matrix(all_labels, all_preds)
        print(cm)

        return {
            'accuracy': acc,
            'f1': f1,
            'auroc': auroc,
            'sensitivity': sen,
            'specificity': spe
        }

# ==============================================================================
# ✅ 兼容版训练器（不动）
# ==============================================================================
class WorkingTrainer:
    def __init__(self, model, device, model_name="working_model"):
        self.model = model
        self.device = device
        self.model_name = model_name
        self.optimizer = torch.optim.Adam(model.parameters(), lr=3e-4, weight_decay=1e-4)
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(self.optimizer, mode='max', factor=0.5, patience=10)
        self.criterion = nn.CrossEntropyLoss()
        self.best_accuracy = 0
        self.train_losses = []
        self.val_losses = []
        self.train_accuracies = []
        self.val_accuracies = []

    def train(self, train_loader, val_loader, epochs=100, patience=25):
        for epoch in range(epochs):
            self.model.train()
            total_loss = 0
            correct = 0
            total = 0
            for data, targets in train_loader:
                data, targets = data.to(self.device), targets.to(self.device)
                self.optimizer.zero_grad()
                outputs, _ = self.model(data)
                loss = self.criterion(outputs, targets)
                loss.backward()
                self.optimizer.step()
                total_loss += loss.item()
                _, pred = outputs.max(1)
                correct += pred.eq(targets).sum().item()
                total += targets.size(0)

            train_loss = total_loss / len(train_loader)
            train_acc = 100 * correct / total

            self.model.eval()
            val_loss = 0
            correct = 0
            total = 0
            with torch.no_grad():
                for data, targets in val_loader:
                    data, targets = data.to(self.device), targets.to(self.device)
                    outputs, _ = self.model(data)
                    val_loss += self.criterion(outputs, targets).item()
                    _, pred = outputs.max(1)
                    correct += pred.eq(targets).sum().item()
                    total += targets.size(0)

            val_acc = 100 * correct / total
            val_loss /= len(val_loader)
            self.scheduler.step(val_acc)

            if (epoch + 1) % 5 == 0:
                print(f"Epoch {epoch+1} | Train {train_loss:.4f} {train_acc:.2f}% | Val {val_loss:.4f} {val_acc:.2f}%")

            if val_acc > self.best_accuracy:
                self.best_accuracy = val_acc
                torch.save(self.model.state_dict(), f'best_{self.model_name}.pth')

        print(f"训练完成，最佳准确率：{self.best_accuracy:.2f}%")

    def evaluate(self, test_loader, device):
        self.model.eval()
        all_preds = []
        all_labels = []
        with torch.no_grad():
            for data, labels in test_loader:
                data = data.to(device)
                outputs, _ = self.model(data)
                preds = outputs.argmax(1)
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.numpy())

        return {
            'accuracy': accuracy_score(all_labels, all_preds),
            'f1': f1_score(all_labels, all_preds, zero_division=0),
        }