#!/usr/bin/env bash
# ls12ed eval quality gate: record AUROC and mark pass/fail for Exp3 eligibility.
#
# Usage:
#   source quality_gate.sh
#   record_quality_gate autocnn AF
#   quality_gate_passed autocnn AF && run_exp3 ...
#
set -euo pipefail

QUALITY_GATE_ROOT="${ECG_QUALITY_GATE_ROOT:-/root/autodl-tmp/exp1-3_logs/quality_gate}"
QUALITY_GATE_REPORT="${QUALITY_GATE_ROOT}/quality_report.tsv"
QUALITY_GATE_SUMMARY="${QUALITY_GATE_ROOT}/quality_summary.txt"
QUALITY_GATE_MIN_AUROC="${ECG_QUALITY_GATE_MIN_AUROC:-0.95}"
QUALITY_GATE_MIN_ACC="${ECG_QUALITY_GATE_MIN_ACC:-0.55}"
QUALITY_GATE_MIN_SPE="${ECG_QUALITY_GATE_MIN_SPE:-0.05}"
QUALITY_GATE_MIN_MODELS="${ECG_QUALITY_GATE_MIN_MODELS:-15}"
LS12ED_LOG_ROOT="${ECG_LS12ED_LOG_ROOT:-/root/autodl-tmp/exp1-3_logs/exp1_ls12ed}"
LS12ED_RESULT_ROOT="${ECG_LS12ED_RESULT_ROOT:-/root/autodl-tmp/exp1-3_results/exp1_ls12ed}"

quality_gate_init() {
  mkdir -p "${QUALITY_GATE_ROOT}"
  if [[ ! -f "${QUALITY_GATE_REPORT}" ]]; then
    printf "timestamp\tmodel\tdisease\tauroc\tmodel_count\tstatus\treason\n" > "${QUALITY_GATE_REPORT}"
  fi
}

QUALITY_GATE_PYTHON="${PYTHON:-/root/miniconda3/bin/python}"

extract_mean_auroc() {
  local eval_log="$1"
  [[ -f "${eval_log}" ]] || return 0
  "${QUALITY_GATE_PYTHON}" - "${eval_log}" <<'PY' 2>/dev/null || true
import re, sys
path = sys.argv[1]
try:
    text = open(path, "rb").read().decode("utf-8", errors="ignore")
except OSError:
    raise SystemExit
for line in text.splitlines():
    if "AUROC" not in line:
        continue
    if ("\u5e73\u5747" in line) or ("mean auroc" in line.lower()):
        m = re.search(r"(\d+\.\d+)", line)
        if m:
            print(m.group(1))
            break
PY
}

extract_report_means() {
  local report="$1"
  [[ -f "${report}" ]] || return 0
  "${QUALITY_GATE_PYTHON}" - "${report}" <<'PY' 2>/dev/null || true
import re, sys
path = sys.argv[1]
try:
    text = open(path, encoding="utf-8", errors="ignore").read()
except OSError:
    raise SystemExit
for line in text.splitlines():
    if "\u5e73\u5747" not in line:
        continue
    nums = re.findall(r"0\.\d+", line)
    if len(nums) >= 5:
        print(nums[0], nums[2], nums[4])
        break
PY
}

count_final_models() {
  local model_dir="$1"
  find "${model_dir}" -maxdepth 1 -name 'final_*' 2>/dev/null | wc -l | tr -d ' '
}

record_quality_gate() {
  local model="$1"
  local disease="$2"
  local eval_log="${LS12ED_LOG_ROOT}/${model}/${disease}/eval.log"
  local model_dir="${LS12ED_RESULT_ROOT}/${model}/${disease}"
  local report="${model_dir}/${disease}_evaluation_results/${disease}_evaluation_report.txt"
  local ts auroc mean_acc mean_spe model_count status reason means

  quality_gate_init
  ts="$(date '+%F %T')"
  auroc="$(extract_mean_auroc "${eval_log}")"
  means="$(extract_report_means "${report}")"
  if [[ -n "${means}" ]]; then
    mean_acc="$(echo "${means}" | awk '{print $1}')"
    mean_spe="$(echo "${means}" | awk '{print $3}')"
  else
    mean_acc=""
    mean_spe=""
  fi
  model_count="$(count_final_models "${model_dir}")"
  status="FAIL"
  reason=""

  if [[ ! -f "${eval_log}" ]]; then
    reason="missing_eval_log"
  elif [[ -z "${auroc}" ]]; then
    reason="missing_auroc"
  elif [[ "${model_count}" -lt "${QUALITY_GATE_MIN_MODELS}" ]]; then
    reason="models=${model_count}_need_${QUALITY_GATE_MIN_MODELS}"
  elif [[ -z "${mean_acc}" || -z "${mean_spe}" ]]; then
    reason="missing_report_means"
  elif ! awk -v a="${auroc}" -v t="${QUALITY_GATE_MIN_AUROC}" 'BEGIN { exit !(a+0 >= t+0) }'; then
    reason="auroc=${auroc}_below_${QUALITY_GATE_MIN_AUROC}"
  elif ! awk -v a="${mean_acc}" -v t="${QUALITY_GATE_MIN_ACC}" 'BEGIN { exit !(a+0 > t+0) }'; then
    reason="acc=${mean_acc}_below_${QUALITY_GATE_MIN_ACC}"
  elif ! awk -v s="${mean_spe}" -v t="${QUALITY_GATE_MIN_SPE}" 'BEGIN { exit !(s+0 >= t+0) }'; then
    reason="spe=${mean_spe}_below_${QUALITY_GATE_MIN_SPE}"
  else
    status="PASS"
    reason="metrics_ok"
  fi

  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "${ts}" "${model}" "${disease}" "${auroc:-NA}" "${model_count}" "${status}" "${reason}" \
    >> "${QUALITY_GATE_REPORT}"

  echo "[${ts}] quality_gate ${model}/${disease}: ${status} (auroc=${auroc:-NA}, acc=${mean_acc:-NA}, spe=${mean_spe:-NA}, models=${model_count}, ${reason})" \
    >> "${QUALITY_GATE_ROOT}/gate.log"

  refresh_quality_summary
  [[ "${status}" == "PASS" ]]
}

quality_gate_passed() {
  local model="$1"
  local disease="$2"
  local eval_log="${LS12ED_LOG_ROOT}/${model}/${disease}/eval.log"
  local model_dir="${LS12ED_RESULT_ROOT}/${model}/${disease}"
  local report="${model_dir}/${disease}_evaluation_results/${disease}_evaluation_report.txt"
  local auroc mean_acc mean_spe model_count means

  [[ -f "${eval_log}" ]] || return 1
  auroc="$(extract_mean_auroc "${eval_log}")"
  means="$(extract_report_means "${report}")"
  [[ -n "${means}" ]] || return 1
  mean_acc="$(echo "${means}" | awk '{print $1}')"
  mean_spe="$(echo "${means}" | awk '{print $3}')"
  model_count="$(count_final_models "${model_dir}")"
  [[ -n "${auroc}" ]] || return 1
  [[ "${model_count}" -ge "${QUALITY_GATE_MIN_MODELS}" ]] || return 1
  awk -v a="${auroc}" -v t="${QUALITY_GATE_MIN_AUROC}" 'BEGIN { exit !(a+0 >= t+0) }' || return 1
  awk -v a="${mean_acc}" -v t="${QUALITY_GATE_MIN_ACC}" 'BEGIN { exit !(a+0 > t+0) }' || return 1
  awk -v s="${mean_spe}" -v t="${QUALITY_GATE_MIN_SPE}" 'BEGIN { exit !(s+0 >= t+0) }'
}

refresh_quality_summary() {
  quality_gate_init
  {
    echo "ls12ed quality gate summary (AUROC >= ${QUALITY_GATE_MIN_AUROC}, ACC > ${QUALITY_GATE_MIN_ACC}, Spe >= ${QUALITY_GATE_MIN_SPE}, models >= ${QUALITY_GATE_MIN_MODELS})"
    echo "updated: $(date '+%F %T')"
    echo ""
    echo "=== PASS (eligible for Exp3) ==="
    awk -F'\t' 'NR>1 && $6=="PASS" {printf "  %s/%s  AUROC=%s  models=%s\n", $2, $3, $4, $5}' \
      "${QUALITY_GATE_REPORT}" | sort -u
    echo ""
    echo "=== FAIL (needs optimization + retrain before Exp3) ==="
    awk -F'\t' 'NR>1 && $6=="FAIL" {
      key=$2"/"$3
      if (!(key in seen) || $1 > latest[key]) { latest[key]=$1; line[key]=$0 }
      seen[key]=1
    }
    END {
      for (k in line) {
        split(line[k], f, "\t")
        printf "  %s/%s  AUROC=%s  models=%s  reason=%s  at=%s\n", f[2], f[3], f[4], f[5], f[7], f[1]
      }
    }' "${QUALITY_GATE_REPORT}" | sort
  } > "${QUALITY_GATE_SUMMARY}"
}

list_failed_jobs() {
  quality_gate_init
  awk -F'\t' 'NR>1 && $6=="FAIL" { print $2, $3 }' "${QUALITY_GATE_REPORT}" | sort -u
}
