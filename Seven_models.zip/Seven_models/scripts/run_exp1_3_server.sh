#!/usr/bin/env bash
# Train all 7 models x 5 diseases x 15 leads for exp1-3 on AutoDL.
#
# Usage:
#   ./run_exp1_3_server.sh exp1          # train on SPCS2018
#   ./run_exp1_3_server.sh exp1_ls12ed   # ls12ed internal (current phase)
#   ECG_DISEASES="LBBB PVC ST-T" ./run_exp1_3_server.sh exp1_ls12ed
#   ./run_exp1_3_server.sh exp3_eval     # reserved for cross-dataset evaluation
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/server_env.sh"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/models.sh"
CODE_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
WORK_ROOT="${ECG_WORK_ROOT:-/root/autodl-tmp}"
LOG_ROOT="${WORK_ROOT}/exp1-3_logs"

declare -A DATASET_BASE=(
  [exp1]="${WORK_ROOT}/SPCS2018"
  [exp2]="${WORK_ROOT}/ls12ed"
  [exp1_ls12ed]="${WORK_ROOT}/ls12ed"
  [exp1_ls12ed_eval]="${WORK_ROOT}/ls12ed"
)

DEFAULT_DISEASES=(AF LBBB RBBB PVC ST-T)

resolve_diseases() {
  if [[ -n "${ECG_DISEASES:-}" ]]; then
    # shellcheck disable=SC2206
    DISEASES=(${ECG_DISEASES})
  else
    DISEASES=("${DEFAULT_DISEASES[@]}")
  fi
}

run_eval() {
  local exp="$1"
  local model="$2"
  local disease="$3"
  local code_model
  code_model="$(model_code_dir "${model}")"
  local run_dir="${CODE_ROOT}/${code_model}/${disease}"
  local out_dir="${WORK_ROOT}/exp1-3_results/exp1_ls12ed/${model}/${disease}"
  local log_dir="${LOG_ROOT}/exp1_ls12ed/${model}/${disease}"

  if [[ ! -d "${run_dir}" || ! -f "${run_dir}/evaluate_and_visualize.py" ]]; then
    echo "skip eval missing dir: ${run_dir}" >&2
    return 0
  fi

  mkdir -p "${out_dir}" "${log_dir}"
  cd "${run_dir}"
  export ECG_DATASET_BASE="${DATASET_BASE[$exp]}"
  export ECG_MODEL_FOLDER="${out_dir}"
  export MPLBACKEND=Agg
  export PYTHONPATH="${CODE_ROOT}:${PYTHONPATH:-}"

  echo "[$(date '+%F %T')] eval ${exp} ${model}/${disease}"
  "${PYTHON}" evaluate_and_visualize.py > "${log_dir}/eval.log" 2>&1 || true
  bash "${SCRIPT_DIR}/collect_eval_results.sh" "${disease}" "${out_dir}"
  bash "${SCRIPT_DIR}/verify_server_artifacts.sh" --model "${model}" --disease "${disease}" || true
  echo "[$(date '+%F %T')] done eval ${exp} ${model}/${disease}"
  # shellcheck source=/dev/null
  source "${SCRIPT_DIR}/quality_gate.sh"
  record_quality_gate "${model}" "${disease}" || true
}

run_one() {
  local exp="$1"
  local model="$2"
  local disease="$3"
  local code_model
  code_model="$(model_code_dir "${model}")"
  local run_dir="${CODE_ROOT}/${code_model}/${disease}"
  local out_dir="${WORK_ROOT}/exp1-3_results/${exp}/${model}/${disease}"
  local log_dir="${LOG_ROOT}/${exp}/${model}/${disease}"

  if [[ ! -d "${run_dir}" ]]; then
    echo "skip missing dir: ${run_dir}" >&2
    return 0
  fi

  mkdir -p "${out_dir}" "${log_dir}"
  cd "${run_dir}"

  export ECG_DATASET_BASE="${DATASET_BASE[$exp]}"
  export ECG_MODEL_CHOICE="${MODEL_CHOICE[$model]}"
  export ECG_TRAINER_CHOICE=1
  export ECG_ATTENTION_CHOICE=4
  export MPLBACKEND=Agg
  export PYTHONPATH="${CODE_ROOT}:${PYTHONPATH:-}"

  echo "[$(date '+%F %T')] train ${exp} ${model}/${disease}"
  "${PYTHON}" main.py > "${log_dir}/train.log" 2>&1

  shopt -s nullglob
  for artifact in final_*.pth best_*.pth best_*.pkl *.png; do
    [[ -e "${artifact}" ]] && mv -f "${artifact}" "${out_dir}/"
  done
  shopt -u nullglob

  if [[ -f evaluate_and_visualize.py ]]; then
    echo "[$(date '+%F %T')] eval ${exp} ${model}/${disease}"
    export ECG_MODEL_FOLDER="${out_dir}"
    "${PYTHON}" evaluate_and_visualize.py > "${log_dir}/eval.log" 2>&1 || true
    bash "${SCRIPT_DIR}/collect_eval_results.sh" "${disease}" "${out_dir}"
    bash "${SCRIPT_DIR}/verify_server_artifacts.sh" --model "${model}" --disease "${disease}" || true
  fi

  echo "[$(date '+%F %T')] done ${exp} ${model}/${disease}"
  if [[ "${exp}" == "exp1_ls12ed" ]]; then
    # shellcheck source=/dev/null
    source "${SCRIPT_DIR}/quality_gate.sh"
    record_quality_gate "${model}" "${disease}" || true
  fi
}

main() {
  local mode="${1:-exp1}"
  local only_model="${2:-}"
  local only_disease="${3:-}"

  if [[ -z "${DATASET_BASE[$mode]:-}" ]]; then
    echo "unknown mode: ${mode}. use exp1, exp2, exp1_ls12ed, or exp1_ls12ed_eval." >&2
    exit 1
  fi

  mkdir -p "${LOG_ROOT}"
  resolve_diseases

  if [[ "${mode}" == "exp1_ls12ed_eval" ]]; then
    echo "eval-only diseases: ${DISEASES[*]}"
    for model in "${MODELS[@]}"; do
      [[ -n "${only_model}" && "${model}" != "${only_model}" ]] && continue
      for disease in "${DISEASES[@]}"; do
        [[ -n "${only_disease}" && "${disease}" != "${only_disease}" ]] && continue
        run_eval "${mode}" "${model}" "${disease}"
      done
    done
    return 0
  fi

  echo "training diseases: ${DISEASES[*]}"

  for model in "${MODELS[@]}"; do
    [[ -n "${only_model}" && "${model}" != "${only_model}" ]] && continue
    for disease in "${DISEASES[@]}"; do
      [[ -n "${only_disease}" && "${disease}" != "${only_disease}" ]] && continue
      run_one "${mode}" "${model}" "${disease}"
    done
  done
}

main "$@"
