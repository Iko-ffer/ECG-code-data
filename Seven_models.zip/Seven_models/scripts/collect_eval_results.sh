#!/usr/bin/env bash
# Collect evaluation artifacts into standard results folder and export per-lead JSON.
#
# Usage (from model/disease run dir after evaluate_and_visualize.py):
#   collect_eval_results.sh DISEASE /path/to/out_dir
#
set -euo pipefail

DISEASE="${1:?disease name required}"
OUT_DIR="${2:?output dir required}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CODE_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/server_env.sh"

STANDARD_DIR="${OUT_DIR}/${DISEASE}_evaluation_results"
mkdir -p "${STANDARD_DIR}"

shopt -s nullglob
for eval_dir in "${DISEASE}"_evaluation_results "${DISEASE}"_evaluation_results_*; do
  if [[ -d "${eval_dir}" ]]; then
    mv -f "${eval_dir}"/* "${STANDARD_DIR}/" 2>/dev/null || true
    rmdir "${eval_dir}" 2>/dev/null || rm -rf "${eval_dir}"
  fi
done
shopt -u nullglob

REPORT="${STANDARD_DIR}/${DISEASE}_evaluation_report.txt"
if [[ -f "${REPORT}" ]]; then
  "${PYTHON}" "${SCRIPT_DIR}/export_lead_metrics_json.py" "${REPORT}" \
    > "${STANDARD_DIR}/${DISEASE}_lead_metrics.json"
fi
