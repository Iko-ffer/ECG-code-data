#!/usr/bin/env bash
# Cross-dataset eval: SPCS2018(CPSC2018)-trained models -> ls12ed test set.
#
# Usage:
#   ./run_exp3_ls12ed_eval.sh
#   ./run_exp3_ls12ed_eval.sh autocnn ST-T
#   ECG_DISEASES="ST-T" ./run_exp3_ls12ed_eval.sh
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/server_env.sh"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/models.sh"

WORK_ROOT="${ECG_WORK_ROOT:-/root/autodl-tmp}"
CODE_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
LOG_ROOT="${WORK_ROOT}/exp1-3_logs/exp3_ls12ed"
OUT_ROOT="${WORK_ROOT}/exp1-3_results/exp3_ls12ed"
TRAIN_RESULT_ROOT="${WORK_ROOT}/exp1-3_results/exp1"
LS12ED_ROOT="${WORK_ROOT}/ls12ed"
MIN_MODELS="${ECG_MIN_MODELS:-15}"

DEFAULT_DISEASES=(AF LBBB RBBB PVC ST-T)

if [[ -n "${ECG_DISEASES:-}" ]]; then
  # shellcheck disable=SC2206
  DISEASES=(${ECG_DISEASES})
else
  DISEASES=("${DEFAULT_DISEASES[@]}")
fi

require_ls12ed() {
  local count
  count="$(find "${LS12ED_ROOT}" -type f 2>/dev/null | wc -l | tr -d ' ')"
  if [[ "${count}" -lt 10000 ]]; then
    echo "ls12ed not ready: ${count} files under ${LS12ED_ROOT}" >&2
    exit 1
  fi
}

run_cross_eval() {
  local model="$1"
  local disease="$2"
  local lock_file="${LOG_ROOT}/locks/${model}_${disease}.lock"
  mkdir -p "${LOG_ROOT}/locks"
  exec 200>"${lock_file}"
  if ! flock -n 200; then
    echo "[$(date '+%F %T')] skip ${model}/${disease}: already running"
    return 0
  fi

  local code_model
  code_model="$(model_code_dir "${model}")"
  local run_dir="${CODE_ROOT}/${code_model}/${disease}"
  local model_dir="${TRAIN_RESULT_ROOT}/${model}/${disease}"
  local out_dir="${OUT_ROOT}/${model}/${disease}"
  local log_dir="${LOG_ROOT}/${model}/${disease}"
  local model_count

  if [[ ! -d "${run_dir}" || ! -f "${run_dir}/evaluate_and_visualize.py" ]]; then
    echo "skip missing code dir: ${run_dir}" >&2
    return 0
  fi

  model_count="$(find "${model_dir}" -maxdepth 1 -name 'final_*' 2>/dev/null | wc -l | tr -d ' ')"
  if [[ "${model_count}" -lt "${MIN_MODELS}" ]]; then
    echo "[$(date '+%F %T')] skip ${model}/${disease}: only ${model_count} models (need ${MIN_MODELS})"
    return 0
  fi

  mkdir -p "${out_dir}" "${log_dir}"
  cd "${run_dir}"
  export ECG_DATASET_BASE="${LS12ED_ROOT}"
  export ECG_MODEL_FOLDER="${model_dir}"
  export MPLBACKEND=Agg
  export PYTHONPATH="${CODE_ROOT}:${PYTHONPATH:-}"

  echo "[$(date '+%F %T')] exp3 ls12ed eval ${model}/${disease} (models=${model_count})"
  "${PYTHON}" evaluate_and_visualize.py > "${log_dir}/eval.log" 2>&1 || true

  bash "${SCRIPT_DIR}/collect_eval_results.sh" "${disease}" "${out_dir}"
  bash "${SCRIPT_DIR}/verify_server_artifacts.sh" --scope exp3 --model "${model}" --disease "${disease}" || true
  echo "[$(date '+%F %T')] done exp3 ls12ed ${model}/${disease}"
}

main() {
  local only_model="${1:-}"
  local only_disease="${2:-}"

  require_ls12ed
  mkdir -p "${LOG_ROOT}" "${OUT_ROOT}"

  {
    echo "[$(date '+%F %T')] exp3 ls12ed cross-eval start (diseases: ${DISEASES[*]})"
    for model in "${MODELS[@]}"; do
      [[ -n "${only_model}" && "${model}" != "${only_model}" ]] && continue
      for disease in "${DISEASES[@]}"; do
        [[ -n "${only_disease}" && "${disease}" != "${only_disease}" ]] && continue
        run_cross_eval "${model}" "${disease}"
      done
    done
    echo "[$(date '+%F %T')] exp3 ls12ed cross-eval finished"
  } | tee -a "${LOG_ROOT}/master.log"
}

main "$@"
