#!/usr/bin/env bash
# ST-T full Exp1-3 pipeline on CPSC2018 (SPCS2018):
#   1) Train 7 models on SPCS2018 + in-domain eval (exp1)
#   2) Cross-domain eval on ls12ed (exp3_ls12ed)
#
# Usage:
#   ./run_stt_cpsc2018_pipeline.sh
#   ./run_stt_cpsc2018_pipeline.sh autocnn          # single model
#   ECG_STT_SKIP_TRAIN=1 ./run_stt_cpsc2018_pipeline.sh   # eval only
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/server_env.sh"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/models.sh"

WORK_ROOT="${ECG_WORK_ROOT:-/root/autodl-tmp}"
LOG_ROOT="${WORK_ROOT}/exp1-3_logs/stt_cpsc2018"
DISEASE="ST-T"
ONLY_MODEL="${1:-}"

mkdir -p "${LOG_ROOT}"

log() {
  echo "[$(date '+%F %T')] $*" | tee -a "${LOG_ROOT}/master.log"
}

train_models() {
  log "=== Phase 1: train + SPCS2018 eval (${DISEASE}) ==="
  for model in "${MODELS[@]}"; do
    [[ -n "${ONLY_MODEL}" && "${model}" != "${ONLY_MODEL}" ]] && continue
    log "train exp1 ${model}/${DISEASE}"
    ECG_DISEASES="${DISEASE}" bash "${SCRIPT_DIR}/run_exp1_3_server.sh" exp1 "${model}" "${DISEASE}" \
      >> "${LOG_ROOT}/${model}_train.log" 2>&1
    local n
    n="$(find "${WORK_ROOT}/exp1-3_results/exp1/${model}/${DISEASE}" -maxdepth 1 -name 'final_*' 2>/dev/null | wc -l | tr -d ' ')"
    log "done train ${model}/${DISEASE} final_models=${n}"
  done
}

cross_eval_ls12ed() {
  log "=== Phase 2: cross-domain eval on ls12ed (${DISEASE}) ==="
  if [[ -n "${ONLY_MODEL}" ]]; then
    ECG_DISEASES="${DISEASE}" bash "${SCRIPT_DIR}/run_exp3_ls12ed_eval.sh" "${ONLY_MODEL}" "${DISEASE}" \
      >> "${LOG_ROOT}/${ONLY_MODEL}_exp3_ls12ed.log" 2>&1
  else
    ECG_DISEASES="${DISEASE}" bash "${SCRIPT_DIR}/run_exp3_ls12ed_eval.sh" \
      >> "${LOG_ROOT}/exp3_ls12ed.log" 2>&1
  fi
  log "=== Phase 2 finished ==="
}

main() {
  log "ST-T CPSC2018 pipeline start (model=${ONLY_MODEL:-all})"
  if [[ "${ECG_STT_SKIP_TRAIN:-0}" != "1" ]]; then
    train_models
  else
    log "skip train (ECG_STT_SKIP_TRAIN=1)"
  fi
  cross_eval_ls12ed
  log "ST-T CPSC2018 pipeline finished"
}

main "$@"
