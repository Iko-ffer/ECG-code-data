#!/usr/bin/env bash
# AutoDL non-interactive SSH shells skip .bashrc; use conda python explicitly.
export PYTHON="${PYTHON:-/root/miniconda3/bin/python}"
if [[ ! -x "${PYTHON}" ]]; then
  echo "python not found: ${PYTHON}" >&2
  exit 1
fi
