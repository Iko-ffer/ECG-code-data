#!/usr/bin/env bash
# Shared model registry for Exp1-3 pipelines.
#
# unet_mobilenet -> UNet1DClassifier (choice 6)
# mobilenet      -> MobileNetV1_ECG  (choice 7), code reused from unet_mobilenet/

MODELS=(autocnn bigrucnn heartbert resnet unet_mobilenet mobilenet xgboost)

declare -A MODEL_CHOICE=(
  [autocnn]=8
  [bigrucnn]=8
  [resnet]=5
  [heartbert]=8
  [unet_mobilenet]=6
  [mobilenet]=7
  [xgboost]=8
)

declare -A MODEL_CODE_DIR=(
  [mobilenet]=unet_mobilenet
)

model_code_dir() {
  local model="$1"
  echo "${MODEL_CODE_DIR[$model]:-$model}"
}
