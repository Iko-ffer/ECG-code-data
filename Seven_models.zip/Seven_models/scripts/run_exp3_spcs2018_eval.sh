#!/usr/bin/env bash
# Cross-dataset eval: ls12ed-trained models -> SPCS2018 test set.
#
# Usage:
#   ./run_exp3_spcs2018_eval.sh
#   ./run_exp3_spcs2018_eval.sh autocnn LBBB
#   ECG_DISEASES="LBBB PVC ST-T" ./run_exp3_spcs2018_eval.sh
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/server_env.sh"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/quality_gate.sh"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/models.sh"

WORK_ROOT="${ECG_WORK_ROOT:-/root/autodl-tmp}"
CODE_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
LOG_ROOT="${WORK_ROOT}/exp1-3_logs/exp3_spcs2018"
OUT_ROOT="${WORK_ROOT}/exp1-3_results/exp3_spcs2018"
TRAIN_RESULT_ROOT="${WORK_ROOT}/exp1-3_results/exp1_ls12ed"
SPCS_ROOT="${WORK_ROOT}/SPCS2018"
MIN_MODELS="${ECG_MIN_MODELS:-15}"

DEFAULT_DISEASES=(AF LBBB RBBB PVC ST-T)

if [[ -n "${ECG_DISEASES:-}" ]]; then
  # shellcheck disable=SC2206
  DISEASES=(${ECG_DISEASES})
else
  DISEASES=("${DEFAULT_DISEASES[@]}")
fi

require_spcs2018() {
  local count
  count="$(find "${SPCS_ROOT}" -type f 2>/dev/null | wc -l | tr -d ' ')"
  if [[ "${count}" -lt 100000 ]]; then
    echo "SPCS2018 not ready: ${count} files under ${SPCS_ROOT}" >&2
    exit 1
  fi
}

run_cross_eval() {
  local model="$1"
  local disease="$2"
  local lock_file="${LOG_ROOT}/locks/${model}_${disease}.lock"
  mkdir -p "${LOG_ROOT}/locks"
  exec 200>"${lock_file}"
  if ! flock -n 200; then
    echo "[$(date '+%F %T')] skip ${model}/${disease}: already running"
    return 0
  fi

  local code_model
  code_model="$(model_code_dir "${model}")"
  local run_dir="${CODE_ROOT}/${code_model}/${disease}"
  local model_dir="${TRAIN_RESULT_ROOT}/${model}/${disease}"
  local out_dir="${OUT_ROOT}/${model}/${disease}"
  local log_dir="${LOG_ROOT}/${model}/${disease}"
  local model_count

  if [[ ! -d "${run_dir}" || ! -f "${run_dir}/evaluate_and_visualize.py" ]]; then
    echo "skip missing code dir: ${run_dir}" >&2
    return 0
  fi

  model_count="$(find "${model_dir}" -maxdepth 1 -name 'final_*' 2>/dev/null | wc -l | tr -d ' ')"
  if [[ "${model_count}" -lt "${MIN_MODELS}" ]]; then
    echo "[$(date '+%F %T')] skip ${model}/${disease}: only ${model_count} models (need ${MIN_MODELS})"
    return 0
  fi

  if [[ "${ECG_EXP3_FORCE:-0}" != "1" ]] && ! quality_gate_passed "${model}" "${disease}"; then
    echo "[$(date '+%F %T')] skip ${model}/${disease}: ls12ed quality gate not passed (need AUROC>=${ECG_QUALITY_GATE_MIN_AUROC:-0.95})"
    return 0
  fi
  if [[ "${ECG_EXP3_FORCE:-0}" == "1" ]]; then
    echo "[$(date '+%F %T')] exp3 force-run ${model}/${disease} (gate bypass)"
  fi

  mkdir -p "${out_dir}" "${log_dir}"
  cd "${run_dir}"
  export ECG_DATASET_BASE="${SPCS_ROOT}"
  export ECG_MODEL_FOLDER="${model_dir}"
  export MPLBACKEND=Agg
  export PYTHONPATH="${CODE_ROOT}:${PYTHONPATH:-}"

  echo "[$(date '+%F %T')] exp3 SPCS2018 eval ${model}/${disease} (models=${model_count})"
  "${PYTHON}" evaluate_and_visualize.py > "${log_dir}/eval.log" 2>&1 || true

  bash "${SCRIPT_DIR}/collect_eval_results.sh" "${disease}" "${out_dir}"
  bash "${SCRIPT_DIR}/verify_server_artifacts.sh" --scope exp3 --model "${model}" --disease "${disease}" || true
  echo "[$(date '+%F %T')] done exp3 ${model}/${disease}"
}

main() {
  local only_model="${1:-}"
  local only_disease="${2:-}"

  require_spcs2018
  mkdir -p "${LOG_ROOT}" "${OUT_ROOT}"

  {
    echo "[$(date '+%F %T')] exp3 SPCS2018 cross-eval start (diseases: ${DISEASES[*]})"
    for model in "${MODELS[@]}"; do
      [[ -n "${only_model}" && "${model}" != "${only_model}" ]] && continue
      for disease in "${DISEASES[@]}"; do
        [[ -n "${only_disease}" && "${disease}" != "${only_disease}" ]] && continue
        run_cross_eval "${model}" "${disease}"
      done
    done
    echo "[$(date '+%F %T')] exp3 SPCS2018 cross-eval finished"
  } | tee -a "${LOG_ROOT}/master.log"
}

main "$@"
