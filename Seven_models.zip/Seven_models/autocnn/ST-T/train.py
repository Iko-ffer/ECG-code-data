import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F
from sklearn.metrics import f1_score, accuracy_score, roc_auc_score, recall_score, confusion_matrix
import time
import warnings
from torch.optim.lr_scheduler import ReduceLROnPlateau

warnings.filterwarnings('ignore')

# ==============================================================================
# ✅ ST-T 专用损失函数：聚焦难分异常样本
# ==============================================================================
class STT_FocalLoss(nn.Module):
    def __init__(self, alpha=None, gamma=2.0):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma  # 提高gamma，更关注难分的ST-T异常

    def forward(self, logits, targets):
        ce_loss = F.cross_entropy(logits, targets, weight=self.alpha.to(logits.device), reduction="none")
        pt = torch.exp(-ce_loss)
        focal_loss = ((1 - pt) ** self.gamma) * ce_loss
        return focal_loss.mean()

# ==============================================================================
# ✅ ST-T 安全数据增强：不破坏波形形态
# ==============================================================================
def stt_safe_augment(signal):
    """仅做微小扰动，完全符合医学规范"""
    if np.random.rand() < 0.5:
        signal = signal * np.random.uniform(0.92, 1.08)  # 微小幅值缩放
    if np.random.rand() < 0.4:
        signal = signal + np.random.uniform(-0.04, 0.04)  # 基线微平移
    if np.random.rand() < 0.3:
        signal = signal + np.random.normal(0, 0.008, signal.shape)  # 轻微高斯噪声
    return signal

# ==============================================================================
# ✅ 最终优化版训练器（ST-T专属）
# ==============================================================================
class DebugTrainer:
    def __init__(self, model, device, model_name="debug_model"):
        self.model = model
        self.device = device
        self.model_name = model_name

        # 🔥 修复1：先不用类别权重，解决全预测1的问题
        self.criterion = nn.CrossEntropyLoss()  # 普通交叉熵，先跑通
        # 等模型能正常学习后，再慢慢加权重：[1.0, 1.5]

        # 🔥 修复2：学习率调整为1e-4，更稳定
        self.optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)

        # 🔥 修复3：初始化scheduler，或者直接注释掉不用
        self.scheduler = None  # 先不用调度器，避免报错

        # 指标记录
        self.best_accuracy = 0.0
        self.best_f1 = 0.0
        self.best_sensitivity = 0.0
        self.best_specificity = 0.0
        self.patience_counter = 0

        self.train_losses = []
        self.val_losses = []
        self.train_accuracies = []
        self.val_accuracies = []
        self.epoch_times = []

        print(f"✅ 极简训练器初始化完成")
        print(f"   学习率: 1e-4 | 损失函数: 普通交叉熵 | 设备: {device}")

    def _compute_metrics(self, y_true, y_pred):
        return {
            'sensitivity': recall_score(y_true, y_pred, pos_label=1, zero_division=0),
            'specificity': recall_score(y_true, y_pred, pos_label=0, zero_division=0),
        }

    def train_epoch_debug(self, dataloader, epoch):
        self.model.train()
        running_loss = 0.0
        all_preds = []
        all_targets = []
        start_time = time.time()

        for batch_idx, (data, targets) in enumerate(dataloader):
            data = data.to(self.device, non_blocking=True)
            targets = targets.to(self.device, non_blocking=True)

            self.optimizer.zero_grad()
            outputs, _ = self.model(data)
            loss = self.criterion(outputs, targets)

            if torch.isnan(loss):
                print(f"⚠️ Epoch {epoch}, Batch {batch_idx}: 损失为NaN，跳过")
                continue

            loss.backward()
            # 严格梯度裁剪，防止震荡
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=0.5)
            self.optimizer.step()

            running_loss += loss.item()
            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_targets.extend(targets.cpu().numpy())

            if batch_idx % 10 == 0:
                batch_acc = accuracy_score(targets.cpu().numpy(), preds.cpu().numpy())
                print(f"  Batch {batch_idx}: loss={loss.item():.4f}, acc={batch_acc:.3f}")

        epoch_time = time.time() - start_time
        epoch_loss = running_loss / len(dataloader)
        epoch_acc = accuracy_score(all_targets, all_preds)
        return epoch_loss, epoch_acc, epoch_time

    def validate_epoch_debug(self, dataloader):
        self.model.eval()
        running_loss = 0.0
        all_preds = []
        all_targets = []

        with torch.no_grad():
            for data, targets in dataloader:
                data = data.to(self.device, non_blocking=True)
                targets = targets.to(self.device, non_blocking=True)

                outputs, _ = self.model(data)
                loss = self.criterion(outputs, targets)

                running_loss += loss.item()
                preds = torch.argmax(outputs, dim=1)
                all_preds.extend(preds.cpu().numpy())
                all_targets.extend(targets.cpu().numpy())

        epoch_loss = running_loss / len(dataloader)
        epoch_acc = accuracy_score(all_targets, all_preds)
        epoch_f1 = f1_score(all_targets, all_preds, zero_division=0)
        metrics = self._compute_metrics(all_targets, all_preds)

        # 🔥 修复4：暂时不用自动阈值搜索，用固定0.5
        print(f"  预测分布: {dict(zip(*np.unique(all_preds, return_counts=True)))}")
        print(f"  灵敏度: {metrics['sensitivity']:.3f} | 特异性: {metrics['specificity']:.3f}")

        return epoch_loss, epoch_acc, epoch_f1, metrics

    def train(self, train_loader, val_loader, epochs=100, patience=15):
        self.model.train()
        print("\n🔍 开始极简训练...")
        patience_counter = 0

        for epoch in range(epochs):
            print(f'\n{"="*50}')
            print(f'Epoch [{epoch + 1}/{epochs}]')
            print(f'{"="*50}')

            train_loss, train_acc, epoch_time = self.train_epoch_debug(train_loader, epoch + 1)
            val_loss, val_acc, val_f1, metrics = self.validate_epoch_debug(val_loader)
            
            # 🔥 修复5：给scheduler加判断，只有存在才调用
            if self.scheduler is not None:
                self.scheduler.step(val_acc)

            # 记录历史
            self.train_losses.append(train_loss)
            self.val_losses.append(val_loss)
            self.train_accuracies.append(train_acc)
            self.val_accuracies.append(val_acc)
            self.epoch_times.append(epoch_time)

            # 打印进度
            print(f'\n📊 本轮结果:')
            print(f'  训练: 损失={train_loss:.4f}, 准确率={train_acc:.4f}')
            print(f'  验证: 损失={val_loss:.4f}, 准确率={val_acc:.4f}, F1={val_f1:.4f}')
            print(f'  时间: {epoch_time:.1f}s')

            # 保存最优模型
            if val_acc > self.best_accuracy + 0.001:
                self.best_accuracy = val_acc
                self.best_f1 = val_f1
                self.best_sensitivity = metrics['sensitivity']
                self.best_specificity = metrics['specificity']
                patience_counter = 0

                torch.save({
                    'model_state_dict': self.model.state_dict(),
                    'best_accuracy': self.best_accuracy,
                    'epoch': epoch
                }, f'best_{self.model_name}.pth')

                print(f"\n🎉 新最佳模型! 准确率={val_acc:.4f}")
            else:
                patience_counter += 1

            print(f"\n⏳ 耐心计数: {patience_counter}/{patience}")

            # 早停
            if patience_counter >= patience:
                print(f"\n🛑 早停于第 {epoch + 1} 轮")
                break

        # 加载最佳模型
        try:
            checkpoint = torch.load(f'best_{self.model_name}.pth')
            self.model.load_state_dict(checkpoint['model_state_dict'])
            print(f"\n✅ 加载最佳模型成功")
            print(f"   最佳准确率: {checkpoint['best_accuracy']:.4f}")
        except:
            print("\n❌ 加载最佳模型失败")

        total_time = sum(self.epoch_times)
        print(f"\n⏱️ 总训练时间: {total_time / 60:.1f}分钟")

    def evaluate(self, test_loader, device):
        self.model.eval()
        all_preds = []
        all_labels = []

        with torch.no_grad():
            for batch_idx, batch_data in enumerate(test_loader):
                batch = list(batch_data)
                valid_items = []
                for item in batch:
                    if isinstance(item, torch.Tensor):
                        valid_items.append(item)
                if len(valid_items) < 2:
                    continue
            
                signals, labels = valid_items[0], valid_items[1]
                signals = signals.to(device, non_blocking=True)
                labels = labels.to(device, non_blocking=True)
            
                if labels.dim() > 1:
                    labels = labels.squeeze(dim=1)
            
                model_output = self.model(signals.unsqueeze(1))
                outputs = model_output[0] if isinstance(model_output, tuple) else model_output
                preds = torch.argmax(outputs, dim=1)
            
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())

        if not all_labels:
            return {'accuracy':0.0,'f1':0.0,'auroc':0.0,'sensitivity':0.0,'specificity':0.0}

        accuracy = accuracy_score(all_labels, all_preds)
        f1 = f1_score(all_labels, all_preds, zero_division=0)
        sensitivity = recall_score(all_labels, all_preds, pos_label=1, zero_division=0)
        specificity = recall_score(all_labels, all_preds, pos_label=0, zero_division=0)

        print(f"\n🔍 测试集结果:")
        print("  混淆矩阵:")
        cm = confusion_matrix(all_labels, all_preds)
        print(f"    TN={cm[0,0]} | FP={cm[0,1]}")
        print(f"    FN={cm[1,0]} | TP={cm[1,1]}")
        print(f"  准确率: {accuracy:.4f}")
        print(f"  灵敏度: {sensitivity:.4f}")
        print(f"  特异性: {specificity:.4f}")

        return {
            'accuracy': accuracy,
            'f1': f1,
            'sensitivity': sensitivity,
            'specificity': specificity
        }
# ==============================================================================
# 兼容版训练器（保持不变）
# ==============================================================================
class WorkingTrainer:
    def __init__(self, model, device, model_name="working_model"):
        self.model = model
        self.device = device
        self.model_name = model_name
        self.optimizer = torch.optim.Adam(model.parameters(), lr=3e-4, weight_decay=1e-4)
        self.scheduler = ReduceLROnPlateau(self.optimizer, mode='max', factor=0.5, patience=10)
        self.criterion = nn.CrossEntropyLoss()
        self.best_accuracy = 0
        self.train_losses = []
        self.val_losses = []
        self.train_accuracies = []
        self.val_accuracies = []

    def train(self, train_loader, val_loader, epochs=100, patience=25):
        print("🚀 开始稳定训练...")
        for epoch in range(epochs):
            self.model.train()
            train_loss = 0.0
            train_correct = 0
            train_total = 0
            for data, targets in train_loader:
                data, targets = data.to(self.device), targets.to(self.device)
                self.optimizer.zero_grad()
                outputs, _ = self.model(data)
                loss = self.criterion(outputs, targets)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 5.0)
                self.optimizer.step()
                train_loss += loss.item()
                _, predicted = outputs.max(1)
                train_total += targets.size(0)
                train_correct += predicted.eq(targets).sum().item()

            train_acc = 100. * train_correct / train_total
            train_loss = train_loss / len(train_loader)
            self.model.eval()
            val_loss = 0.0
            val_correct = 0
            val_total = 0
            with torch.no_grad():
                for data, targets in val_loader:
                    data, targets = data.to(self.device), targets.to(self.device)
                    outputs, _ = self.model(data)
                    val_loss += self.criterion(outputs, targets).item()
                    _, predicted = outputs.max(1)
                    val_total += targets.size(0)
                    val_correct += predicted.eq(targets).sum().item()

            val_acc = 100. * val_correct / val_total
            val_loss /= len(val_loader)
            self.scheduler.step(val_acc)
            if (epoch + 1) % 5 == 0 or epoch == 0:
                print(f'Epoch [{epoch + 1}/{epochs}]')
                print(f'  训练: 损失={train_loss:.4f}, 准确率={train_acc:.2f}%')
                print(f'  验证: 损失={val_loss:.4f}, 准确率={val_acc:.2f}%')

            if val_acc > self.best_accuracy:
                self.best_accuracy = val_acc
                torch.save(self.model.state_dict(), f'best_{self.model_name}.pth')
        print(f"✅ 训练完成! 最佳验证准确率: {self.best_accuracy:.2f}%")

    def evaluate(self, test_loader, device):
        self.model.eval()
        all_preds = []
        all_labels = []
        all_probs = []
        with torch.no_grad():
            for batch_data in test_loader:
                if len(batch_data) >= 2:
                    signals, labels = batch_data[0], batch_data[1]
                else:
                    continue
                signals = signals.to(device)
                labels = labels.to(device)
                model_output = self.model(signals.unsqueeze(1))
                if isinstance(model_output, tuple):
                    outputs = model_output[0]
                else:
                    outputs = model_output
                probs = torch.nn.functional.softmax(outputs, dim=1)[:, 1]
                preds = (probs > 0.5).long()
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
                all_probs.extend(probs.cpu().numpy())

        if len(all_labels) == 0:
            return {'accuracy':0.0,'f1':0.0,'auroc':0.0,'sensitivity':0.0,'specificity':0.0}
        accuracy = accuracy_score(all_labels, all_preds)
        f1 = f1_score(all_labels, all_preds, zero_division=0)
        auroc = roc_auc_score(all_labels, all_probs) if len(set(all_labels)) > 1 else 0.0
        sensitivity = recall_score(all_labels, all_preds, zero_division=0)
        try:
            specificity = recall_score(all_labels, all_preds, pos_label=0, zero_division=0)
        except:
            specificity = 0.0
        return {
            'accuracy': accuracy,
            'f1': f1,
            'auroc': auroc,
            'sensitivity': sensitivity,
            'specificity': specificity
        }