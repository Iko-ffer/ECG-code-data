import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, recall_score, precision_score
import warnings
import os
import numpy as np
from scipy.io import loadmat
import sys
_CODE_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
if _CODE_ROOT not in sys.path:
    sys.path.insert(0, _CODE_ROOT)
from common.ecg_preprocess import prepare_ecg_signal, resolve_label_dir

# ===================== 导入模型（保持不变） =====================
from model import ECGAutoEncoderCNN, RobustCNNBiGRU, WorkingECGModel, SimpleButEffectiveModel, DebuggableECGModel, ResNet1D, UNet1DClassifier, MobileNetV1_ECG

# ===================== 通用数据集类（100%兼容训练脚本） =====================
class ECGFolderDataset(Dataset):
    """通用ECG切片数据集加载器"""
    def __init__(self, root_dir, lead_name, mode='test', transform=None):
        self.root_dir = root_dir
        self.lead_name = lead_name
        self.mode = mode
        self.transform = transform
        
        self.file_paths = []
        self.labels = []
        
        # 阳性样本（标签1）
        pos_dir = resolve_label_dir(root_dir, lead_name, mode, '1')
        if pos_dir:
            for f in os.listdir(pos_dir):
                if f.endswith('.mat'):
                    self.file_paths.append(os.path.join(pos_dir, f))
                    self.labels.append(1)
        
        # 阴性样本（标签0）
        neg_dir = resolve_label_dir(root_dir, lead_name, mode, '0')
        if neg_dir:
            for f in os.listdir(neg_dir):
                if f.endswith('.mat'):
                    self.file_paths.append(os.path.join(neg_dir, f))
                    self.labels.append(0)
        
        self.labels = np.array(self.labels, dtype=np.int64)

    def __len__(self):
        return len(self.file_paths)

    def __getitem__(self, idx):
        mat_data = loadmat(self.file_paths[idx])
        signal = prepare_ecg_signal(mat_data['signal'])
        
        signal_tensor = torch.from_numpy(signal)
        label_tensor = torch.tensor(self.labels[idx], dtype=torch.long)
        
        return signal_tensor, label_tensor

def collate_fn(batch):
    signals = torch.stack([item[0] for item in batch])
    labels = torch.stack([item[1] for item in batch])
    return signals, labels

warnings.filterwarnings('ignore')

# ===================== 全局配置（唯一需要修改的部分） =====================
# 疾病名称（必须与训练时完全一致：LBBB/RBBB/AF/PVC/ST-T等）
DISEASE_NAME = "AF"  
# 数据集根目录（结构：root/导联/train|val|test/0|1/*.mat）
DATASET_ROOT = os.path.join(os.environ.get("ECG_DATASET_BASE", "/root/autodl-tmp/SPCS2018"), DISEASE_NAME)
# 模型保存文件夹（包含所有导联的训练好的模型）
MODEL_FOLDER = os.environ.get("ECG_MODEL_FOLDER", os.path.join("/root/autodl-tmp/exp1-3_results/exp1", os.path.basename(os.getcwd())))
# 输出结果文件夹（自动创建）
OUTPUT_FOLDER = f"{DISEASE_NAME}_evaluation_results"
# 评估批次大小
BATCH_SIZE = 8
# 计算设备
DEVICE = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

# 15个标准虚拟导联（固定不变）
LEAD_PAIRS = [
    'V1-V2', 'V2-V3', 'V3-V4', 'V4-V5', 'V5-V6',
    'V1-V3', 'V2-V4', 'V3-V5', 'V4-V6', 'V1-V4',
    'V2-V5', 'V3-V6', 'V1-V5', 'V1-V6', 'V2-V6'
]

# 创建输出文件夹
os.makedirs(OUTPUT_FOLDER, exist_ok=True)
print(f"{'='*60}")
print(f"通用ECG心律失常评估系统")
print(f"{'='*60}")
print(f"使用设备: {DEVICE}")
print(f"评估疾病: {DISEASE_NAME}")
print(f"数据集路径: {DATASET_ROOT}")
print(f"模型路径: {MODEL_FOLDER}")
print(f"输出路径: {OUTPUT_FOLDER}")
print(f"{'='*60}\n")

# ====================== 通用模型加载函数 =====================
def load_trained_model(model_path):
    """自动识别并加载任意训练好的ECG模型"""
    checkpoint = torch.load(model_path, map_location=DEVICE)
    config = checkpoint.get('model_config', {})
    model_type = config.get('model_type', 'ResNet1D')  # 默认ResNet1D
    attention_type = config.get('attention_type', 'adaptive')

    # 自动初始化对应模型（二分类通用）
    if model_type == "RobustCNNBiGRU":
        model = RobustCNNBiGRU(num_classes=2, attention_type=attention_type)
    elif model_type == "WorkingECGModel":
        model = WorkingECGModel(num_classes=2, attention_type=attention_type)
    elif model_type == "SimpleButEffectiveModel":
        model = SimpleButEffectiveModel(num_classes=2)
    elif model_type == "DebuggableECGModel":
        model = DebuggableECGModel(num_classes=2)
    elif model_type == "ResNet1D":
        model = ResNet1D(input_channels=1, num_classes=2, segment_length=2500, dropout_rate=0.2)
    elif model_type == "UNet1DClassifier":
        model = UNet1DClassifier(input_channels=1, input_length=2500, num_classes=2, base_filters=16, dropout_rate=0.3)
    elif model_type == "MobileNetV1_ECG":
        model = MobileNetV1_ECG(input_length=2048, in_channels=1, scale=1.0, num_classes=2, dropout_rate=0.3)
    elif model_type == "ECGAutoEncoderCNN":
                model = ECGAutoEncoderCNN(
                    input_channels=1,
                    num_classes=2,
                    input_length=2500,
                    latent_dim=256,  
                    dropout_rate=0.2
             )
    else:
        raise ValueError(f"不支持的模型类型: {model_type}")

    # 加载权重（严格匹配）
    model.load_state_dict(checkpoint['model_state_dict'], strict=True)
    model.to(DEVICE)
    model.eval()
    print(f"✅ 加载模型成功: {model_type} | 注意力机制: {attention_type}")
    return model

# ====================== 通用单导联评估函数 =====================
def evaluate_lead(model, test_loader, lead_name):
    """评估单个导联的所有性能指标"""
    all_preds = []
    all_labels = []
    all_probs = []

    with torch.no_grad():
        for signals, labels in test_loader:
            signals = signals.to(DEVICE)
            labels = labels.to(DEVICE)

            # 兼容所有模型返回格式（单值/元组）
            output = model(signals)
            logits = output[0] if isinstance(output, (list, tuple)) else output
            
            # 计算概率和预测
            probs = F.softmax(logits, dim=1)[:, 1]
            preds = (probs > 0.5).long()

            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
            all_probs.extend(probs.cpu().numpy())

    # 计算通用指标
    total_samples = len(all_labels)
    positive_samples = sum(all_labels)
    negative_samples = total_samples - positive_samples
    
    accuracy = accuracy_score(all_labels, all_preds)
    f1 = f1_score(all_labels, all_preds, zero_division=0)
    auroc = roc_auc_score(all_labels, all_probs) if len(set(all_labels)) > 1 else 0.0
    sensitivity = recall_score(all_labels, all_preds, zero_division=0)  # 阳性检出率
    specificity = recall_score(all_labels, all_preds, pos_label=0, zero_division=0)  # 阴性正确率

    metrics = {
        'lead_name': lead_name,
        'accuracy': accuracy,
        'f1': f1,
        'auroc': auroc,
        'sensitivity': sensitivity,
        'specificity': specificity,
        'total_samples': total_samples,
        'positive_samples': positive_samples,
        'negative_samples': negative_samples
    }

    # 打印评估结果
    print(f"\n✅ 导联 {lead_name} 评估完成:")
    print(f"  测试样本总数: {total_samples}")
    print(f"  阳性样本({DISEASE_NAME}): {positive_samples} | 阴性样本(正常): {negative_samples}")
    print(f"  准确率(ACC): {accuracy:.4f} | F1分数: {f1:.4f} | AUC-ROC: {auroc:.4f}")
    print(f"  灵敏度(阳性检出率): {sensitivity:.4f} | 特异性(阴性正确率): {specificity:.4f}")
    
    return metrics

# ====================== 通用多导联指标对比图 =====================
def plot_metrics_comparison(lead_metrics):
    """生成所有导联的5项核心指标对比图"""
    os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
    plt.rcParams['font.sans-serif'] = ['DejaVu Sans'] 
    plt.rcParams['axes.unicode_minus'] = False
    
    # 按AUROC降序排序
    lead_metrics_sorted = sorted(lead_metrics, key=lambda x: x['auroc'], reverse=True)
    lead_names = [m['lead_name'] for m in lead_metrics_sorted]
    accuracies = [m['accuracy'] for m in lead_metrics_sorted]
    f1_scores = [m['f1'] for m in lead_metrics_sorted]
    aurocs = [m['auroc'] for m in lead_metrics_sorted]
    sensitivities = [m['sensitivity'] for m in lead_metrics_sorted]
    specificities = [m['specificity'] for m in lead_metrics_sorted]
    
    # 渐变色系（15个导联）
    colors = [
        "#5A005A", "#6A3D9A", "#5C54A0", "#4A6FA5", "#3D7D9A",
        "#338F91", "#2AA198", "#36B37E", "#4CC466", "#66CC52",
        "#99D84A", "#B8DE40", "#D4E638", "#EDE030", "#F9E732"
    ][:len(lead_names)]
    
    # 创建2x3子图
    fig, axes = plt.subplots(2, 3, figsize=(22, 12))
    fig.suptitle(
        f'{DISEASE_NAME} Virtual Lead Performance Comparison', 
        fontsize=18, fontweight='bold', y=0.98
    )

    # 1. 准确率对比
    ax = axes[0,0]
    bars = ax.bar(lead_names, accuracies, color=colors, edgecolor='black', linewidth=0.5)
    ax.set_title('ACCURACY', fontsize=14, fontweight='bold')
    ax.set_ylabel('Accuracy', fontsize=12)
    ax.set_ylim(0, 1.05)
    ax.tick_params(axis='x', rotation=45, labelsize=10)
    ax.grid(axis='y', linestyle='--', alpha=0.7)
    for bar, v in zip(bars, accuracies):
        ax.text(
            bar.get_x()+bar.get_width()/2, bar.get_height()+0.01, 
            f'{v:.3f}', ha='center', va='bottom', fontsize=9, fontweight='bold'
        )

    # 2. F1分数对比
    ax = axes[0,1]
    bars = ax.bar(lead_names, f1_scores, color=colors, edgecolor='black', linewidth=0.5)
    ax.set_title('F1 SCORE', fontsize=14, fontweight='bold')
    ax.set_ylabel('F1 Score', fontsize=12)
    ax.set_ylim(0, 1.05)
    ax.tick_params(axis='x', rotation=45, labelsize=10)
    ax.grid(axis='y', linestyle='--', alpha=0.7)
    for bar, v in zip(bars, f1_scores):
        ax.text(
            bar.get_x()+bar.get_width()/2, bar.get_height()+0.01, 
            f'{v:.3f}', ha='center', va='bottom', fontsize=9, fontweight='bold'
        )

    # 3. AUROC对比
    ax = axes[0,2]
    bars = ax.bar(lead_names, aurocs, color=colors, edgecolor='black', linewidth=0.5)
    ax.set_title('AUROC', fontsize=14, fontweight='bold')
    ax.set_ylabel('AUROC', fontsize=12)
    ax.set_ylim(0, 1.05)
    ax.tick_params(axis='x', rotation=45, labelsize=10)
    ax.grid(axis='y', linestyle='--', alpha=0.7)
    for bar, v in zip(bars, aurocs):
        ax.text(
            bar.get_x()+bar.get_width()/2, bar.get_height()+0.01, 
            f'{v:.3f}', ha='center', va='bottom', fontsize=9, fontweight='bold'
        )

    # 4. 灵敏度对比
    ax = axes[1,0]
    bars = ax.bar(lead_names, sensitivities, color=colors, edgecolor='black', linewidth=0.5)
    ax.set_title('SENSITIVITY (Positive Detection Rate)', fontsize=14, fontweight='bold')
    ax.set_ylabel('Sensitivity', fontsize=12)
    ax.set_ylim(0, 1.05)
    ax.tick_params(axis='x', rotation=45, labelsize=10)
    ax.grid(axis='y', linestyle='--', alpha=0.7)
    for bar, v in zip(bars, sensitivities):
        ax.text(
            bar.get_x()+bar.get_width()/2, bar.get_height()+0.01, 
            f'{v:.3f}', ha='center', va='bottom', fontsize=9, fontweight='bold'
        )

    # 5. 特异性对比
    ax = axes[1,1]
    bars = ax.bar(lead_names, specificities, color=colors, edgecolor='black', linewidth=0.5)
    ax.set_title('SPECIFICITY (Negative Accuracy)', fontsize=14, fontweight='bold')
    ax.set_ylabel('Specificity', fontsize=12)
    ax.set_ylim(0, 1.05)
    ax.tick_params(axis='x', rotation=45, labelsize=10)
    ax.grid(axis='y', linestyle='--', alpha=0.7)
    for bar, v in zip(bars, specificities):
        ax.text(
            bar.get_x()+bar.get_width()/2, bar.get_height()+0.01, 
            f'{v:.3f}', ha='center', va='bottom', fontsize=9, fontweight='bold'
        )

    # 6. 导联性能排名
    ax_rank = axes[1,2]
    ax_rank.axis('off')
    rank_text = f"🏆 {DISEASE_NAME} Virtual Lead Performance Ranking (by AUROC)\n"
    rank_text += "="*55 + "\n"
    for i, m in enumerate(lead_metrics_sorted, 1):
        rank_text += (
            f"{i:2d}. {m['lead_name']:6} | "
            f"ACC: {m['accuracy']:.3f} | "
            f"F1: {m['f1']:.3f} | "
            f"AUROC: {m['auroc']:.3f}\n"
        )
    
    ax_rank.text(
        0.02, 0.98, rank_text, transform=ax_rank.transAxes,
        fontsize=10, verticalalignment='top', horizontalalignment='left', 
        family='monospace', linespacing=1.2
    )

    # 调整布局并保存
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    save_path = os.path.join(OUTPUT_FOLDER, f'{DISEASE_NAME}_lead_metrics_comparison.png')
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()  # 关闭图形释放内存
    print(f"\n📊 指标对比图已保存至: {save_path}")

# ====================== 通用评估报告生成 =====================
def save_evaluation_report(lead_metrics):
    """生成详细的文本评估报告"""
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    report_path = os.path.join(OUTPUT_FOLDER, f'{DISEASE_NAME}_evaluation_report.txt')
    
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("="*80 + "\n")
        f.write(f"ECG {DISEASE_NAME} 检测多导联评估报告\n")
        f.write("="*80 + "\n")
        f.write(f"评估时间: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"计算设备: {DEVICE}\n")
        f.write(f"批次大小: {BATCH_SIZE}\n")
        f.write(f"评估导联数: {len(lead_metrics)}/15\n")
        f.write(f"数据集路径: {DATASET_ROOT}\n")
        f.write(f"模型路径: {MODEL_FOLDER}\n")
        f.write("\n" + "="*80 + "\n")
        f.write("各导联详细性能指标\n")
        f.write("="*80 + "\n")
        f.write(
            f"{'导联名称':<10} {'总样本':<8} {'阳性样本':<10} {'阴性样本':<10} "
            f"{'准确率':<10} {'F1分数':<10} {'AUROC':<10} {'灵敏度':<10} {'特异性':<10}\n"
        )
        f.write("-"*80 + "\n")
        
        # 按AUROC降序写入
        for metrics in sorted(lead_metrics, key=lambda x: x['auroc'], reverse=True):
            f.write(
                f"{metrics['lead_name']:<10} "
                f"{metrics['total_samples']:<8} "
                f"{metrics['positive_samples']:<10} "
                f"{metrics['negative_samples']:<10} "
                f"{metrics['accuracy']:.4f}{'':<6} "
                f"{metrics['f1']:.4f}{'':<6} "
                f"{metrics['auroc']:.4f}{'':<6} "
                f"{metrics['sensitivity']:.4f}{'':<6} "
                f"{metrics['specificity']:.4f}\n"
            )
        
        # 计算平均性能
        avg_metrics = {
            'accuracy': np.mean([m['accuracy'] for m in lead_metrics]),
            'f1': np.mean([m['f1'] for m in lead_metrics]),
            'auroc': np.mean([m['auroc'] for m in lead_metrics]),
            'sensitivity': np.mean([m['sensitivity'] for m in lead_metrics]),
            'specificity': np.mean([m['specificity'] for m in lead_metrics])
        }
        
        f.write("-"*80 + "\n")
        f.write(
            f"{'平均性能':<10} "
            f"{'-':<8} "
            f"{'-':<10} "
            f"{'-':<10} "
            f"{avg_metrics['accuracy']:.4f}{'':<6} "
            f"{avg_metrics['f1']:.4f}{'':<6} "
            f"{avg_metrics['auroc']:.4f}{'':<6} "
            f"{avg_metrics['sensitivity']:.4f}{'':<6} "
            f"{avg_metrics['specificity']:.4f}\n"
        )
        
        # 最佳导联总结
        best_auroc = max(lead_metrics, key=lambda x: x['auroc'])
        best_specificity = max(lead_metrics, key=lambda x: x['specificity'])
        best_sensitivity = max(lead_metrics, key=lambda x: x['sensitivity'])
        
        f.write("\n" + "="*80 + "\n")
        f.write("最佳导联总结\n")
        f.write("="*80 + "\n")
        f.write(f"最佳综合性能(AUROC): {best_auroc['lead_name']} ({best_auroc['auroc']:.4f})\n")
        f.write(f"最高特异性(阴性正确率): {best_specificity['lead_name']} ({best_specificity['specificity']:.4f})\n")
        f.write(f"最高灵敏度(阳性检出率): {best_sensitivity['lead_name']} ({best_sensitivity['sensitivity']:.4f})\n")
    
    print(f"📝 详细评估报告已保存至: {report_path}")

# ====================== 主函数 =====================
def main():
    # 查找所有模型文件
    model_files = [
        f for f in os.listdir(MODEL_FOLDER) 
        if f.startswith(f'final_{DISEASE_NAME}') and f.endswith('.pth')
    ]
    
    if not model_files:
        print(f"❌ 错误: 在 {MODEL_FOLDER} 中未找到模型文件!")
        print(f"   请确保模型文件名以 'final_{DISEASE_NAME}' 开头")
        return

    print(f"🔍 找到 {len(model_files)} 个训练好的模型\n")

    # 建立导联-模型映射
    lead_model_map = {}
    for f in model_files:
        for lead in LEAD_PAIRS:
            if lead in f:
                lead_model_map[lead] = os.path.join(MODEL_FOLDER, f)
                break

    # 逐个评估导联
    all_metrics = []
    for lead in LEAD_PAIRS:
        if lead not in lead_model_map:
            print(f"⚠️  跳过导联 {lead} (无对应模型)")
            continue

        print(f"\n{'='*40}")
        print(f"正在评估导联: {lead}")
        print(f"{'='*40}")
        
        # 加载模型
        try:
            model = load_trained_model(lead_model_map[lead])
        except Exception as e:
            print(f"❌ 加载模型失败: {e}")
            continue
        
        # 加载测试集
        try:
            test_ds = ECGFolderDataset(DATASET_ROOT, lead, mode='test')
            if len(test_ds) == 0:
                print(f"⚠️  导联 {lead} 无测试数据，跳过")
                continue
            
            test_loader = DataLoader(
                test_ds, 
                batch_size=BATCH_SIZE, 
                shuffle=False, 
                collate_fn=collate_fn, 
                num_workers=0  # Windows下建议设为0避免多进程问题
            )
        except Exception as e:
            print(f"❌ 加载测试集失败: {e}")
            continue

        # 执行评估
        try:
            metrics = evaluate_lead(model, test_loader, lead)
            all_metrics.append(metrics)
        except Exception as e:
            print(f"❌ 评估失败: {e}")
            continue

    if not all_metrics:
        print("\n❌ 无有效评估结果!")
        return

    # 生成可视化和报告
    print(f"\n{'='*60}")
    print("正在生成评估结果...")
    print(f"{'='*60}")
    
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    plot_metrics_comparison(all_metrics)
    save_evaluation_report(all_metrics)

    # 打印最终总结
    avg_auroc = np.mean([m['auroc'] for m in all_metrics])
    best_lead = max(all_metrics, key=lambda x: x['auroc'])
    
    print(f"\n🎉 {DISEASE_NAME} 多导联评估完成!")
    print(f"📊 平均AUROC: {avg_auroc:.4f}")
    print(f"🏆 最佳导联: {best_lead['lead_name']} (AUROC: {best_lead['auroc']:.4f})")
    print(f"📁 所有结果已保存至: {OUTPUT_FOLDER}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⏹️ 用户中断程序")
    except Exception as e:
        print(f"\n❌ 程序执行出错: {e}")
        import traceback
        traceback.print_exc()
    finally:
        torch.cuda.empty_cache()
        print("\n🧹 GPU内存已释放")