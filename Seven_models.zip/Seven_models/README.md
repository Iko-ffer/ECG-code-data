# Exp1–3 Seven ECG Classification Models

This package contains the source code for the seven classifiers used in Exp1–3.

## Models

| Paper name | Code directory | Entry | Notes |
|---|---|---|---|
| AutoCNN | `autocnn/` | `{DISEASE}/main.py` | ECGAutoEncoderCNN |
| BiGRU-CNN | `bigrucnn/` | `{DISEASE}/main.py` | |
| HeartBERT | `heartbert/` | `{DISEASE}/main.py` | Needs pretrained weights (not included; see below) |
| ResNet | `resnet/` | `{DISEASE}/main.py` | ResNet1D |
| U-Net+MobileNet | `unet_mobilenet/` | `{DISEASE}/main.py` | `ECG_MODEL_CHOICE=6` |
| MobileNet | `unet_mobilenet/` | `{DISEASE}/main.py` | Same folder; `ECG_MODEL_CHOICE=7` |
| XGBoost | `xgboost/` | `{DISEASE}/main.py` | Per-lead XGBoost |

Diseases: `AF`, `LBBB`, `RBBB`, `PVC`, `ST-T`.

## Shared utilities

- `common/ecg_preprocess.py` — signal loading / lead path resolution
- `common/ecg_eval_utils.py` — metrics / checkpoint selection
- `common/ecg_model_loader.py` — checkpoint loading
- `scripts/` — server orchestration helpers

## Data layout (expected)

```
{DATASET}/{DISEASE}/{V1-V2|...}/{train|test}/{0|1}/*.mat
```

Set `ECG_DATASET_BASE` to the dataset root (e.g. SPCS2018 or ls12ed).

## HeartBERT pretrained weights

`pytorch_model.bin` (~319 MB) is **not** included. Place it under `heartbert/` before training HeartBERT, or set `HEARTBERT_MODEL_PATH`.

## Train / val / test split

- Fixed hold-out: train folder 80% / test folder 20% (patient-level, seed=42)
- Within train: 80/20 train/val for early stopping
- Effective ratio ≈ **train:val:test = 64:16:20**
- **No k-fold cross-validation**

## License / citation

Use according to your project / paper policy.
