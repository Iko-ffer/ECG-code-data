"""Shared ECG preprocessing for training and evaluation."""

from __future__ import annotations

import os

import numpy as np


def normalize_lead_name(lead_name: str) -> str:
    return "-".join(part.upper() for part in lead_name.split("-"))


def resolve_label_dir(root_dir: str, lead_name: str, mode: str, label: str) -> str | None:
    """Resolve train/test label directory, supporting V1-V2 and v1-v2 layouts."""
    candidates = [
        os.path.join(root_dir, lead_name, mode, label),
        os.path.join(root_dir, normalize_lead_name(lead_name), mode, label),
        os.path.join(root_dir, lead_name.lower(), mode, label),
    ]
    seen = set()
    for path in candidates:
        if path in seen:
            continue
        seen.add(path)
        if os.path.isdir(path):
            return path
    return None


def zscore_per_sample(signal: np.ndarray) -> np.ndarray:
    """Sample-wise Z-score normalization along the time axis."""
    signal = np.asarray(signal, dtype=np.float32)
    signal_mean = np.mean(signal, axis=1, keepdims=True)
    signal_std = np.std(signal, axis=1, keepdims=True)
    signal_std = np.where(signal_std < 1e-8, 1e-8, signal_std)
    return (signal - signal_mean) / signal_std


def prepare_ecg_signal(signal: np.ndarray) -> np.ndarray:
    """Ensure shape (1, seq_len) and apply sample-wise Z-score normalization."""
    signal = np.asarray(signal, dtype=np.float32)
    if signal.ndim == 1:
        signal = signal.reshape(1, -1)
    elif signal.shape[0] != 1:
        signal = signal.T
    return zscore_per_sample(signal)
