"""Load trained Exp1-3 ECG classifiers from checkpoint files."""
from __future__ import annotations

import importlib.util
import os
import pickle
import sys
from typing import Any

import torch

MODEL_TYPE_ALIASES = {
    "BiGRU": "BiGRU_ECG",
    "bigru_ecg": "BiGRU_ECG",
    "BIGRU_ECG": "BiGRU_ECG",
    "PureBiGRU_ECG": "BiGRU_ECG",
    "AutoEncoderCNN": "ECGAutoEncoderCNN",
    "HeartBERT": "HeartBERT_ECG",
    "UNet1D": "UNet1DClassifier",
    "MobileNetV1": "MobileNetV1_ECG",
    "MobileNet_ECG": "MobileNetV1_ECG",
}


def normalize_model_type(model_type: str) -> str:
    key = (model_type or "").strip()
    return MODEL_TYPE_ALIASES.get(key, key)


def _load_model_module(model_dir: str):
    model_path = os.path.join(model_dir, "model.py")
    if not os.path.isfile(model_path):
        raise FileNotFoundError(f"model.py not found: {model_path}")
    module_tag = model_path.replace(os.sep, "_").replace(".", "_")
    spec = importlib.util.spec_from_file_location(f"ecg_model_module_{module_tag}", model_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot import model module from {model_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def build_classifier(model_module, model_type: str, attention_type: str, code_root: str):
    model_type = normalize_model_type(model_type)
    if model_type == "RobustCNNBiGRU":
        return model_module.RobustCNNBiGRU(num_classes=2, attention_type=attention_type)
    if model_type == "WorkingECGModel":
        return model_module.WorkingECGModel(num_classes=2, attention_type=attention_type)
    if model_type == "SimpleButEffectiveModel":
        return model_module.SimpleButEffectiveModel(num_classes=2)
    if model_type == "DebuggableECGModel":
        return model_module.DebuggableECGModel(num_classes=2)
    if model_type == "ResNet1D":
        return model_module.ResNet1D(
            input_channels=1,
            num_classes=2,
            segment_length=2500,
            dropout_rate=0.2,
        )
    if model_type == "UNet1DClassifier":
        return model_module.UNet1DClassifier(
            input_channels=1,
            input_length=2500,
            num_classes=2,
            base_filters=16,
            dropout_rate=0.3,
        )
    if model_type == "MobileNetV1_ECG":
        return model_module.MobileNetV1_ECG(
            input_length=2048,
            in_channels=1,
            scale=1.0,
            num_classes=2,
            dropout_rate=0.3,
        )
    if model_type == "ECGAutoEncoderCNN":
        return model_module.ECGAutoEncoderCNN(
            input_channels=1,
            num_classes=2,
            input_length=2500,
            latent_dim=256,
            dropout_rate=0.2,
        )
    if model_type == "HeartBERT_ECG":
        heartbert_path = os.environ.get(
            "HEARTBERT_MODEL_PATH",
            os.path.join(code_root, "heartbert"),
        )
        return model_module.HeartBERT_ECG(
            heartbert_model_path=heartbert_path,
            input_length=2500,
            num_classes=2,
            dropout_rate=0.3,
            freeze_heartbert=True,
        )
    if model_type == "BiGRU_ECG":
        return model_module.BiGRU_ECG(
            num_classes=2,
            input_length=2000,
            num_gru_layers=2,
            dropout_rate=0.2,
        )
    raise ValueError(f"unsupported model_type: {model_type}")


def load_classifier_checkpoint(
    checkpoint_path: str,
    model_dir: str,
    code_root: str,
    device: torch.device,
) -> tuple[Any, dict]:
    checkpoint = torch.load(checkpoint_path, map_location=device)
    config = checkpoint.get("model_config", {})
    model_type = normalize_model_type(config.get("model_type", "ResNet1D"))
    attention_type = config.get("attention_type", "adaptive")

    if model_type == "XGBoost":
        booster = pickle.loads(checkpoint["model_state_dict"])
        return booster, checkpoint

    model_module = _load_model_module(model_dir)
    model = build_classifier(model_module, model_type, attention_type, code_root)
    model.load_state_dict(checkpoint["model_state_dict"], strict=True)
    model.to(device)
    model.eval()
    return model, checkpoint
