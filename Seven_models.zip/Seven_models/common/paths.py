"""Shared path helpers for server and local runs."""

from __future__ import annotations

import os

CODE_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def default_heartbert_path() -> str:
    return os.environ.get(
        "HEARTBERT_MODEL_PATH",
        os.path.join(CODE_ROOT, "heartbert"),
    )
