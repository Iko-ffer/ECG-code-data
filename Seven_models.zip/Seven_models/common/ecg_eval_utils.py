"""Shared evaluation helpers for multi-lead ECG classifiers."""
from __future__ import annotations

import os
import re
from typing import Iterable

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)


def model_forward_logits(model, signals: torch.Tensor) -> torch.Tensor:
    output = model(signals)
    return output[0] if isinstance(output, (list, tuple)) else output


def collect_probs_labels(
    model,
    loader,
    device: torch.device,
) -> tuple[np.ndarray, np.ndarray]:
    model.eval()
    probs: list[float] = []
    labels: list[int] = []
    with torch.no_grad():
        for signals, batch_labels in loader:
            signals = signals.to(device)
            logits = model_forward_logits(model, signals)
            batch_probs = F.softmax(logits, dim=1)[:, 1].cpu().numpy()
            probs.extend(batch_probs.tolist())
            labels.extend(batch_labels.numpy().tolist())
    return np.asarray(probs, dtype=np.float64), np.asarray(labels, dtype=np.int64)


def youden_threshold(labels: np.ndarray, probs: np.ndarray, default: float = 0.5) -> float:
    if len(np.unique(labels)) < 2:
        return default
    fpr, tpr, thresholds = roc_curve(labels, probs)
    if len(thresholds) == 0:
        return default
    idx = int(np.argmax(tpr - fpr))
    threshold = float(thresholds[idx])
    if np.isfinite(threshold):
        return threshold
    return default


def compute_metrics(
    labels: np.ndarray,
    probs: np.ndarray,
    threshold: float = 0.5,
) -> dict[str, float]:
    preds = (probs >= threshold).astype(np.int64)
    return {
        "accuracy": float(accuracy_score(labels, preds)),
        "f1": float(f1_score(labels, preds, zero_division=0)),
        "auroc": float(roc_auc_score(labels, probs)) if len(np.unique(labels)) > 1 else 0.0,
        "sensitivity": float(recall_score(labels, preds, zero_division=0)),
        "specificity": float(recall_score(labels, preds, pos_label=0, zero_division=0)),
        "threshold": float(threshold),
    }


def is_collapsed_metrics(metrics: dict[str, float], tol: float = 1e-6) -> bool:
    acc = metrics.get("accuracy", 0.0)
    spe = metrics.get("specificity", 0.0)
    sen = metrics.get("sensitivity", 0.0)
    if abs(acc - 0.5) <= tol and abs(sen - 1.0) <= tol and spe <= tol:
        return True
    if abs(acc - 0.5) <= tol and abs(spe - 1.0) <= tol and sen <= tol:
        return True
    return False


def pick_best_checkpoint_per_lead(
    model_folder: str,
    disease_name: str,
    lead_pairs: Iterable[str],
) -> dict[str, str]:
    """Keep newest checkpoint when duplicate final_* exist for the same lead."""
    prefix = f"final_{disease_name}"
    lead_map: dict[str, tuple[float, str]] = {}

    if not os.path.isdir(model_folder):
        return {}

    for fname in os.listdir(model_folder):
        if not (fname.startswith(prefix) and fname.endswith(".pth")):
            continue
        matched_lead = None
        for lead in lead_pairs:
            if lead in fname:
                matched_lead = lead
                break
        if matched_lead is None:
            continue
        path = os.path.join(model_folder, fname)
        mtime = os.path.getmtime(path)
        prev = lead_map.get(matched_lead)
        if prev is None or mtime >= prev[0]:
            lead_map[matched_lead] = (mtime, path)

    return {lead: path for lead, (_, path) in lead_map.items()}


def parse_report_means(report_path: str) -> dict[str, float | None]:
    """Parse mean ACC/AUROC/Spe from evaluation report average row."""
    result: dict[str, float | None] = {"accuracy": None, "auroc": None, "specificity": None}
    if not os.path.isfile(report_path):
        return result
    text = open(report_path, encoding="utf-8", errors="ignore").read()
    for line in text.splitlines():
        if "??" not in line:
            continue
        nums = re.findall(r"0\.\d+", line)
        if len(nums) >= 5:
            result["accuracy"] = float(nums[0])
            result["auroc"] = float(nums[2])
            result["specificity"] = float(nums[4])
            break
    return result
